/*******************************************************************************
 *
 * Copyright (c) by 
 *
 * Author:  C. Sperr
 *
 *------------------------------------------------------------------------------
 *
 * Description: graphic protocoll function     EXPERT-N simulation result
 *
 *------------------------------------------------------------------------------
 *
 * $Revision: 8 $
 *
 * $History: xplot.c $
 * 
 * *****************  Version 8  *****************
 * User: Christian Bauer Date: 10.06.04   Time: 11:46
 * Updated in $/Projekte/ExpertN/ExpertN/System
 * Output of simulation object in info window
 * 
 * *****************  Version 7  *****************
 * User: Christian Bauer Date: 29.02.04   Time: 12:03
 * Updated in $/Projekte/ExpertN/ExpertN/System
 * 
 * *****************  Version 6  *****************
 * User: Christian Bauer Date: 29.12.01   Time: 15:39
 * Updated in $/Projekte/ExpertN.3.0/ExpertN/System
 * "windows.h" includiert.
 * 
 * *****************  Version 5  *****************
 * User: Christian Bauer Date: 29.12.01   Time: 11:56
 * Updated in $/Projekte/ExpertN.3.0/ExpertN/System
 * Zur Stabilisierung des Codes Methoden Prototypen Definition in Header
 * Files verschoben statt �ber extern Declarationen festgelegt.
 * 
 * *****************  Version 3  *****************
 * User: Christian Bauer Date: 14.12.01   Time: 18:21
 * Updated in $/Projekte/ExpertN/ExpertN/System
 * Global constants renamed.
 * 
 *   20.11.95
 *
*******************************************************************************/

#include <windows.h>
#include <math.h>
#include "expert.h"
#include "graphs.h"
#include "defines.h"
#include "language.h"
#include "expbasic.h"
#include "plottype.h"
#include "plotlist.h"
#include "project.h"
#include "infowin.h"
#include "xmemory.h"

/* xmeasure.c */ 
extern int XGetNoOfNitroMeasurePoints(void);
extern int XGetNoOfH2OMeasurePoints(void);
extern int XGetNoOfNitroMeasureLayers(void);  //?? Differences ???
extern int XGetNoOfH2OMeasureLayers(void);


double GrXmin[MAXPLOTS];
double GrXmax[MAXPLOTS];
double GrXdiv[MAXPLOTS];
int    GrXdec[MAXPLOTS];
double GrYmin[MAXPLOTS];
double GrYmax[MAXPLOTS];
double GrYdiv[MAXPLOTS];
int    GrYdec[MAXPLOTS];    


extern float   fTimeAktEvDt;
extern float   fSickerWDt;
extern float   fRunOffDt;
extern float   fDrainWDt;


extern  double     PlotDZ1Ymin;
extern  double     PlotDZ1Ymax;
extern  double     PlotDZ1YDiv;
extern  int        PlotDZ1YDec;

extern  double     PlotDZ1Xmin;
extern  double     PlotDZ1Xmax;
extern  double     PlotDZ1XDiv;
extern  int        PlotDZ1XDec;

extern  double     PlDZ1Xmin;
extern  double     PlDZ1Xmax;
extern  double     PlDZ1Xdiv;
extern  int        PlDZ1Xdec;



extern  double     PlotDT1Xmin;
extern  double     PlotDT1Xmax;
extern  double     PlotDT1XDiv;
extern  int        PlotDT1XDec;

extern  double     PlotDT1Ymin;
extern  double     PlotDT1Ymax;
extern  double     PlotDT1YDiv;
extern  int        PlotDT1YDec;

/*---*/
extern  double     PlotDZ2Ymin;
extern  double     PlotDZ2Ymax;
extern  double     PlotDZ2YDiv;
extern  int        PlotDZ2YDec;

extern  double     PlotDZ2Xmin;
extern  double     PlotDZ2Xmax;
extern  double     PlotDZ2XDiv;
extern  int        PlotDZ2XDec;

extern  double     PlDZ2Xmin;   /// for dummy graphics
extern  double     PlDZ2Xmax;
extern  double     PlDZ2Xdiv;
extern  int        PlDZ2Xdec;



extern  double     PlotDT2Xmin;
extern  double     PlotDT2Xmax;
extern  double     PlotDT2XDiv;
extern  int        PlotDT2XDec;

extern  double     PlotDT2Ymin;
extern  double     PlotDT2Ymax;
extern  double     PlotDT2YDiv;
extern  int        PlotDT2YDec;


/*-----< GLOBAL.C >-------------------*/                    
// simulation process info dialog
extern HWND       hCtrlDlg;           
// data arrays for simulation results
extern  float far *   afMeasH2O_1;
extern  float far *   afMeasH2O_2;
extern  float far *   afMeasH2O_3;
extern  float far *   afMeasH2O_4;
extern  float far *   afMeasH2O_5;
extern  float far *   afMeasH2OSim_1;
extern  float far *   afMeasH2OSim_2;
extern  float far *   afMeasH2OSim_3;
extern  float far *   afMeasH2OSim_4;
extern  float far *   afMeasH2OSim_5;

extern  float far *   afMeasNO3_1;
extern  float far *   afMeasNO3_2;
extern  float far *   afMeasNO3_3;
extern  float far *   afMeasNO3_4;
extern  float far *   afMeasNO3_5;
extern  float far *   afMeasNO3Sim_1;
extern  float far *   afMeasNO3Sim_2;
extern  float far *   afMeasNO3Sim_3;
extern  float far *   afMeasNO3Sim_4;
extern  float far *   afMeasNO3Sim_5;


extern  float far *   afMeasNH4_1;
extern  float far *   afMeasNH4Sim_1;


extern float  far * fa1Hyd;
extern float  far * fa2Hyd;
extern float  far * fa3Hyd;
extern float  far * fa4Hyd;
extern float  far * fa5Hyd;
extern float  far * fa6Hyd;
extern float  far * fa1LogHyd;
extern float  far * fa2LogHyd;
extern float  far * fa3LogHyd;
extern float  far * fa4LogHyd;
extern float  far * fa5LogHyd;
extern float  far * fa6LogHyd;

extern float  far * afThetaTest;
extern double far  * afdblThetaTest;

extern float  far * fa1HydLeit;
extern float  far * fa2HydLeit;
extern float  far * fa3HydLeit;
extern float  far * fa4HydLeit;
extern float  far * fa5HydLeit;
extern float  far * fa6HydLeit;
extern float  far * fa1LogHydLeit;
extern float  far * fa2LogHydLeit;
extern float  far * fa3LogHydLeit;
extern float  far * fa4LogHydLeit;
extern float  far * fa5LogHydLeit;
extern float  far * fa6LogHydLeit;

extern double far  * fa1DWC;
extern double far  * fa2DWC;
extern double far  * fa3DWC;
extern double far  * fa4DWC;
extern double far  * fa5DWC;
extern double far  * fa6DWC;


// graphic - plot parameter: plot.c

extern float  far  * afDummyDZ1;
extern float  far  * afDummyDZ2;


extern  float  far  * afDummy11DT;
extern  float  far  * afDummy12DT;
extern  float  far  * afDummy13DT;
extern  float  far  * afDummy14DT;
extern  float  far  * afDummy15DT;
extern  float  far  * afDummy16DT;

extern  float  far  * afDummy21DT;
extern  float  far  * afDummy22DT;
extern  float  far  * afDummy23DT;
extern  float  far  * afDummy24DT;
extern  float  far  * afDummy25DT;
extern  float  far  * afDummy26DT;

extern float far *   afNitroDZ;    //MaxS 
extern float far *   afOldNitroDZ;    //MaxS
extern float far *   afANitroDZ;   // MaxS


extern float far *   afNitro1DT;
extern float far *   afNitro2DT;
extern float far *   afNitro3DT;
extern float far *   afNitro4DT;
extern float far *   afNitro5DT;
extern float far *   afNitro6DT;
extern float far *   afNitro7DT;
extern float far *   afNitro8DT;
extern float far *   afNitro9DT;
extern float far *   afNitro10DT;
extern float far *   afNitro11DT;
extern float far *   afNitro12DT;
extern float far *   afNitro13DT;
extern float far *   afNitro14DT;
extern float far *   afNitro15DT;
extern float far *   afNitro16DT;


// plant simulation data 
extern  float far * afDevStage; 
extern  float far * afLai;
extern  float far * afTillers; 
extern  float far * afLeafWeight; 
extern  float far * afGrainWeight; 
extern  float far * afStemWeight; 
extern  float far * afObVegWeight; 
extern  float far * afRootWeight; 
extern  float far * afRootLengthDensity; 
extern  float far * afNullRootLengthDensity; 

// plant measurement data 
extern  float far * afMeasDevStage; 
extern  float far * afMeasLAI; 
extern  float far * afMeasOBiomass; 
extern  float far * afMeasGBiomass; 
extern  float far * afMeasOBiomassN; 
extern  float far * afMeasTillers; 
extern  float far * afMeasConcN; 


extern  float far * afActNUptake; 
extern  float far * afCritNConc; 
extern  float far * afNConc; 

extern  float far * afActTr; 
extern  float far * afCumActTr; 

extern float   far  * afTiefe;
extern float   far  * afTheta;
extern float   far  * afTemp;
extern float   far  * afOldTemp;
extern float   far  * afOldTheta;
extern float   far  * afResTemp;
extern float   far  * afResTheta;

extern float   far  * afTimeAktEv;
extern float   far  * afkumPotEv;
extern float   far  * afkumAktEv;
extern float   far  * afSickerW;
extern float   far  * afRunoff;
extern float   far  * afKumSickerW;
extern float   far  * afKumRunoff;
extern float   far  * afKumDrainW;
extern float   far  * afNiederSchl;
extern float   far  * afkumRegen;  

extern float   far  * afTime0Temp;
extern float   far  * afTime1Temp;
extern float   far  * afTime2Temp;
extern float   far  * afTime3Temp;

extern float   far  * afTime0Theta;
extern float   far  * afTime1Theta;
extern float   far  * afTime2Theta;
extern float   far  * afTime3Theta;
extern float   far  * afTime;

extern float   far * afH2OET1;
extern float   far * afH2OET2;
extern float   far * afH2OET3;
extern float   far * afH2OET4;
extern float   far * afH2OET5;
extern float   far * afH2OET6;

extern float   far * afH2OBal1;
extern float   far * afH2OBal2;
extern float   far * afH2OBal3;
extern float   far * afH2OBal4;

extern float   far * afH2OPot1;
extern float   far * afH2OPot2;
extern float   far * afH2OPot3;
extern float   far * afH2OPot4;

extern float   far * afH2OFlux1;
extern float   far * afH2OFlux2;
extern float   far * afH2OFlux3;
extern float   far * afH2OFlux4;

extern float   far * afH2OCond1;
extern float   far * afH2OCond2;
extern float   far * afH2OCond3;
extern float   far * afH2OCond4;

extern float   far * afNitroBal1;
extern float   far * afNitroBal2;
extern float   far * afNitroBal3;
extern float   far * afNitroBal4;
extern float   far * afNitroBal5;
extern float   far * afNitroBal6;

extern float   far * afNitroGas1;
extern float   far * afNitroGas2;
extern float   far * afNitroGas3;
extern float   far * afNitroGas4;
extern float   far * afNitroGas5;

extern float   far * afNitroCumGas1;
extern float   far * afNitroCumGas2;
extern float   far * afNitroCumGas3;
extern float   far * afNitroCumGas4;
extern float   far * afNitroCumGas5;

extern float   far * afNitroPools1;
extern float   far * afNitroPools2;
extern float   far * afNitroPools3;
extern float   far * afNitroPools4;
extern float   far * afNitroPools5;
extern float   far * afNitroPools6;

extern float   far * afNitroCN1;
extern float   far * afNitroCN2;
extern float   far * afNitroCN3;

extern float   far * afNitroMiner1;
extern float   far * afNitroMiner2;
extern float   far * afNitroMiner3;
extern float   far * afNitroMiner4;
extern float   far * afNitroMiner5;
extern float   far * afNitroMiner6;

extern float   far * afTempIce1;
extern float   far * afTempIce2;
extern float   far * afTempIce3;
extern float   far * afTempIce4;

extern float   far *   afPlant1;
extern float   far *   afPlant2;
extern float   far *   afPlant3;
extern float   far *   afPlant4;
extern float   far *   afPlant5;
extern float   far *   afPlant6;
extern float   far *   afPlant7;
extern float   far *   afPlant8;
extern float   far *   afPlant9;
extern float   far *   afPlant10;
extern float   far *   afPlant11;
extern float   far *   afPlant12;


extern float   fTimeEnd;
extern unsigned short   dTimeCount;
extern long    ldTcount;
extern long    ldoldTcount;
extern short    colour;
                         
//-------------
extern COLORREF GraphCol[];

/*------------< Measure.c   >------------*/
int GetNoOfNitroMeasurePoints(void);
int GetNoOfH2OMeasurePoints(void);

/*-----------< date - expression for egraphic.c >------------*/
int XGetSimulDate(LPSTR lpDate,int iValue);                                    


/******************************************************************************************
 *   void XSetInitInfoDlg(void)
 *
 *   Author :  C. Sperr   
 *   Date   : 22.11.95
 *************************************************************************
 */                                
void XSetInitInfoDlg(void)     
{
  PSIMOBJECT pSimObj = getProjectRoot()->pCurrentSimObj;
  char       szParcelName[50];

  memset( szParcelName, 0x00, sizeof(szParcelName) );

  if( pSimObj->szTeilSName != NULL )
  {
    if( strlen(pSimObj->szTeilSName) > 0 )
    {
      strncpy( szParcelName, pSimObj->szTeilSName, sizeof(szParcelName)-1 );
    }
  }
  if( szParcelName[0] == 0x00 )
  {
    if( pSimObj->szSchlagName != NULL )
    {
      if( strlen(pSimObj->szSchlagName) > 0 )
      {
        strncpy( szParcelName, pSimObj->szSchlagName, sizeof(szParcelName)-1 );
      }
    }
  }
  if( szParcelName[0] == 0x00 )
  {
    if( pSimObj->szFarmName != NULL )
    {
      if( strlen(pSimObj->szFarmName) > 0 )
      {
        strncpy( szParcelName, pSimObj->szFarmName, sizeof(szParcelName)-1 );
      }
    }
  }
  SetDlgItemText(hCtrlDlg,ID_CTRL_DLG1A,szParcelName);
  SetDlgItemText(hCtrlDlg,ID_CTRL_DLG2A,"");
}
/* 
 *****************************************************************************************
 */ 

/*******************************************************************************************
 *  initialize plot parameter  use global variables
 *  C.Sperr     17.01.94   
 */                    
int XinitPlotParam(void)
{
  int iRet = 0;
 //---------- set time base parameter       dummy graphics    1
  PlotDT1Xmin = 0.0;
  PlotDT1Xmax = 150.0;                 
  PlotDT1XDiv = 5.0;
  PlotDT1XDec = 0;
  
  PlotDT1Ymin = 0.0;
  PlotDT1Ymax = 1.0;                 
  PlotDT1YDiv = 5.0;
  PlotDT1YDec = 1;


//---------- set depth based parameter  
  PlotDZ1Xmin = 0.0;
  PlotDZ1Xmax = 1.0;                 
  PlotDZ1XDiv = 5.0;
  PlotDZ1XDec = 1;

  PlDZ1Xmin   = 0.0;
  PlDZ1Xmax   = 1.0;
  PlDZ1Xdiv   = 4.0;
  PlDZ1Xdec   = 1;


  
  PlotDZ1Ymin = -1000.0;
  PlotDZ1Ymax = 0.0;                 
  PlotDZ1YDiv = 5.0;
  PlotDZ1YDec = 0;
//---------- set time base parameter       dummy graphics    2
  PlotDT2Xmin = 0.0;
  PlotDT2Xmax = 150.0;                 
  PlotDT2XDiv = 5.0;
  PlotDT2XDec = 1;
  
  PlotDT2Ymin = 0.0;
  PlotDT2Ymax = 1.0;                 
  PlotDT2YDiv = 5.0;
  PlotDT2YDec = 1;


//---------- set depth based parameter     dummy graphics    2
  PlotDZ2Xmin = 0.0;
  PlotDZ2Xmax = 1.0;                 
  PlotDZ2XDiv = 5.0;
  PlotDZ2XDec = 1;

  PlDZ2Xmin   = 0.0;
  PlDZ2Xmax   = 1.0;
  PlDZ2Xdiv   = 4.0;
  PlDZ2Xdec   = 2;


  
  PlotDZ2Ymin = -1000.0;
  PlotDZ2Ymax = 0.0;                 
  PlotDZ2YDiv = 5.0;
  PlotDZ2YDec = 1;         
  
  
 return iRet;
 }
/*
 *  initialize plot parameter   
 */  

/*******************************************************************************************
 *  adjust plot parameter  to simulation specific orders use global variables
 *  C.Sperr     17.01.94   
 */                            
int XadjustPlotParamChange(void)
{
  PGRAPHIC  pGr = GetGraphicPoi();
  return 0;
}                    
 
/*******************************************************************************************
 *  int adjustPlotParam(void)  :  
 *  ------------------------
 *  adjust plot parameter  to simulation specific orders use global variables
 *  Author : C.Sperr     
 *  Date   : 17.01.94   
 */                    
int XadjustPlotParam(void)
{ 
   int iRet=0;    
  int     iIncr;
  double  dDepth,dProfileDepth=0.0;
  PSPROFILE		pSo=NULL;
  PTIME			pTi=NULL;
  PSLAYER		pSL=NULL;
////////////////////////////////////
  pSo = GetSoilPoi();
  pTi = GetTimePoi();
  ////////////////////////////////////
   //-----------  new scale ---------------------------------------------
  PlotDZ1Xmin = 0.0;
  PlotDZ1Xmax = 0.6;
  PlotDZ1XDiv = 3.0;
  PlotDZ1XDec = 1;
/*---*/
  PlDZ1Xmin = 0.0;
  PlDZ1Xmax = 1.0;
  PlDZ1Xdiv = 4.0;
  PlDZ1Xdec = 2;
/*---*/                 
  /// calculate profile depth  
  for (pSL=pSo->pSLayer->pNext;pSL->pNext!=NULL;pSL=pSL->pNext) dProfileDepth += pSL->fThickness;
  /////////////////////////////////////////////////////////////////////////////////////////////
  
  PlotDZ1Ymin = -1.0 * dProfileDepth;
  for(iIncr = 0,dDepth = 0.0;dDepth < dProfileDepth;dDepth += 100.0,iIncr++);
  PlotDZ1Ymin = -1.0 * dDepth;
  PlotDZ1Ymax = 0.0;
  PlotDZ1YDiv = (double)iIncr / 2.0;
  PlotDZ1YDec = 0;
/*---*/
  PlotDT1Xmin = 0.0;
  PlotDT1Xmax = pTi->pSimTime->iSimDuration;
  PlotDT1XDiv = 5.0;
  PlotDT1XDec = 1;
/*---*/
  PlotDZ2Xmin = 0.0;
  PlotDZ2Xmax = 0.6;
  PlotDZ2XDiv = 3.0;
  PlotDZ2XDec = 1;

  PlDZ2Xmin = 0.0;
  PlDZ2Xmax = 1.0;
  PlDZ2Xdiv = 4.0;
  PlDZ2Xdec = 2;
/*---*/
  PlotDZ2Ymin = -1.0 * dProfileDepth;
  for(iIncr = 0,dDepth = 0.0;dDepth < dProfileDepth;dDepth += 100.0,iIncr++);
  PlotDZ2Ymin = -1.0 * dDepth;
  PlotDZ2Ymax = 0.0;
  PlotDZ2YDiv = (double)iIncr/2.0;
  PlotDZ2YDec = 1;
/*---*/
  PlotDT2Xmin = 0.0;
  PlotDT2Xmax = pTi->pSimTime->iSimDuration;
  PlotDT2XDiv = 5.0;
  PlotDT2XDec = 1;
/*---*/
 /*-------------------------------------------------------------------------*/
 /*-------------------------------------------------------------------------*/
  {
   LPPLOTPAR  lpPPS;

	for (lpPPS = getRootPPS(); lpPPS!=NULL;lpPPS = lpPPS->lpNext)
	{	
	// time dependant graphs get new simulation parameter
		if(lpPPS->bXTimeScale){
	        lpPPS->dXmin = PlotDT1Xmin;
			lpPPS->dXmax = PlotDT1Xmax;
			lpPPS->iXdiv = (int)PlotDT1XDiv;
			lpPPS->iXdec= (int) PlotDT1XDec;
  // depth dependant graphs get new simulation parameter
		}else if(lpPPS->bYDepthScale){
           lpPPS->dYmin = PlotDZ1Ymin;
           lpPPS->dYmax = PlotDZ1Ymax;
           lpPPS->iYdiv = (int)PlotDZ1YDiv;
           lpPPS->iYdec = PlotDZ1YDec;

     	}
	} /// for all plottype structures 
  }
  /*-------------------------------------------------------------------------*/


  return iRet;
   
}                    

/***************************************************************************************
 *
 *  initialize nitrogen content array  with starting values                             
 *
 *  Author  C.Sperr      30.03.94
 ***************************************************************************************
 */
int XinitNitroPlot(void)
{short int idummy;
 PSPROFILE	pSo=NULL;
 PCHEMISTRY	pCh=NULL;                      
 PCLAYER   pCL=NULL;
/////////////////////////////////////
 pSo = GetSoilPoi();
 pCh = GetChemistryPoi();
/////////////////////////////////////
      for(idummy=0,pCL=pCh->pCLayer;
         ((pCL->pNext!=NULL)&&(idummy<pSo->iLayers));
           pCL=pCL->pNext,idummy++)
        {
            afANitroDZ[idummy]    = pCL->fNO3N;
        } // for idummy
     
      afANitroDZ[0]    = afANitroDZ[1];
return 0;

}
      // ------------------------------

/***************************************************************************************
 *  void XinitDepthArray(void)
 *
 * Author  : C. Sperr
 * Date    : 21.11.95
 ***************************************************************************************
 */
void XinitDepthArray(void)
      {short int idummy;
       float     sum;
       PSPROFILE	pSo = NULL;
       PSLAYER 		pSL = NULL;
       /////////////////////
       pSo = GetSoilPoi();
       /////////////////////
       for(idummy=0,sum=(float)0.0,pSL = pSo->pSLayer;
           ((idummy< pSo->iLayers)&&(pSL!=NULL));
           pSL=pSL->pNext,idummy++)
       { sum +=  (float)pSL->fThickness;
         afTiefe[idummy] = (float) -1.0 * sum;
       } // for idummy
 }
      // ------------------------------

/***************************************************************************************
 *  int XinitThetaPlot(void)
 *
 * Author  : C. Sperr
 * Date    : 21.11.95
 ***************************************************************************************
 */
int XinitThetaPlot(void)
{ int           idummy; 
  PSPROFILE		pSo=NULL;
  PWATER		pWa=NULL;
  PWLAYER		pWL=NULL;
  /////////////////////////////
  pSo = GetSoilPoi();
  pWa = GetWaterPoi();
  ////////////////////////////
       
       for(idummy=0,pWL = pWa->pWLayer;((idummy < pSo->iLayers)&&(pWL!=NULL));
            							pWL=pWL->pNext,idummy++)
       { 
             afTheta[idummy]      = pWL->fContInit * (float) 100;    // Vol %
             afOldTheta[idummy]   = afTheta[idummy]; 
             afResTheta[idummy]   = pWL->fContAct;
       } // for idummy
      return 0;
      }
      // ------------------------------

                       
/***************************************************************************************
 *  int XinitTempPlot(void )
 *
 *  Author :   C.Sperr  /  21.11.95
 */
int XinitTempPlot(void)
{ int idummy;
  float     sum;
       PSPROFILE	pSo=NULL;
       PHEAT		pHe=NULL;
       PHLAYER   	pHL =NULL;
       
       pSo = GetSoilPoi();
       pHe = GetHeatPoi();
       ////////////////////////////////////
        
  /******************************  
  *   Temperature of all layers 
  */    
       afTemp[0]   = pHe->pHLayer->pNext->fSoilTemp;
       for(idummy=1,sum=(float)0.0,pHL = pHe->pHLayer->pNext;
                           ((idummy<pSo->iLayers)&&(pHL!=NULL));
           					pHL=pHL->pNext,idummy++)
       {
         afTemp[idummy] = afResTemp[idummy]= pHL->fSoilTemp;
         afOldTemp[idummy] = afResTemp[idummy];
    
       } // for idummy
      
    return 0;
 }
// ------------------------------

/******************************************************************************************/
//  calculate ExpertN  date from julian day
/******************************************************************************************/
int XGetSimulDate(LPSTR lpDate,int iValue)
{ 
 int  iRet=0;                 
 int  iYear; 
 PTIME	pTi=NULL;
 //////////////////////////////
 pTi = GetTimePoi();
 ////////////////////////////// 
    /*
     *  !!! global time variables !!!!
     */                                    
        iYear  = (short int)(pTi->pSimTime->lStartDate % 100);
       /***
        */ 
        DaysToDate(iYear, ((int) pTi->pSimTime->iStartJulianDay + iValue),lpDate);
       /*
        ***/ 
 return iRet;
}

/******************************************************************************************
 *  dialoge in Vordergrund   void DialogsInFront(void)
 *
 *  C. Sperr 
 *  20.05.94
 *****************************************************************************************
 */
void XDialogsInFront(void)
{    
/* plotlist.c */
 LPPLOTPAR lpPP=NULL; 
 int       iDummy;
// activate all dialogs in succession of creation 
 for (lpPP=getRootPPS(),iDummy=0;((lpPP != NULL)&&(iDummy<MAX_PLOTPAR_MEMBER));
        lpPP= lpPP->lpNext,iDummy++) 
 {
		SetFocus(lpPP->hChild);                                          
 } 
//  last dialog to aktualize : systeminfo
  if(hCtrlDlg   != 0)              SetFocus(hCtrlDlg);

return;	
} 
  


/*************************************************************************************
 * procedure         :   ClosePlotWindows(void)                                       
 * function          :   close all existing windows  ********************************
 * operating system  : DOS/WINDOWS                                                  
 *  (C) 1993      AGE/cs                          29.03.93      version 0.1         
 *************************************************************************************/
int XClosePlotWindows(void) 
{ 
 LPPLOTPAR lpPP=NULL; 
 int iDummy;	
 /**************************************************************************************  
  *
  *     close all existing windows    
  */                              
   /*  Simulation control info 
    */
   if(hCtrlDlg)             { DestroyWindow(hCtrlDlg);         hCtrlDlg = 0;  }

 // close all plot windows ------------------------------------------------ 
 for (lpPP=getRootPPS(),iDummy=0;((lpPP != NULL)&&(iDummy<MAX_PLOTPAR_MEMBER));
      lpPP= lpPP->lpNext,iDummy++) {
          DestroyWindow(lpPP->hChild);                                          
	      SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPP->iIDMenu,USER_PLOT_LPARAM);
 		}
 
      return 0;
 }
/**********************  close all existing plot windows  *********************************/ 
//---------------------------------------------------------------------------------------------
// <<<<<<<<<<<<< redraw only curves in dialogs if existent >>>>>>>>>>>>>>>>>>>>
//---------------------------------------------------------------------------------------------
/***********************************************************************************************
 * name         : redrawCurves(void)                                        
 * function     :  redraw only curves in dialogs 
 *
 * author       : Sperr Chr.                         
 * date         : 29.08.93  
 *
 *----------------------------------------------------------------------------------------------    
 * changed     date         name                change report
 *
 *
 ***********************************************************************************************
 */

int  XredrawCurves(void)
{
 
 LPPLOTPAR lpPP=NULL; 
 int iDummy;	
	 // activate all dialogs in succession of creation 
 for (lpPP=getRootPPS(),iDummy=0;((lpPP != NULL)&&(iDummy<MAX_PLOTPAR_MEMBER));
      lpPP= lpPP->lpNext,iDummy++) {
            InvalidateRect(lpPP->hChild, NULL,FALSE);                                          
		}
 

    return 0;
}

/***********************************************************************************************
 * name         : redrawDialogs(void)                                        
 * function     : redraw graphic areas of all dialogs                        
 *
 * author       : Sperr Chr.                         
 * date         : 29.03.93      
 *
 *----------------------------------------------------------------------------------------------    
 ***********************************************************************************************
 */

int  XredrawDialogs(void)

{  LPPLOTPAR lpPP=NULL; 
  int iDummy;			
// activate all dialogs in succession of creation 
 for (lpPP=getRootPPS(),iDummy=0;((lpPP != NULL)&&(iDummy<MAX_PLOTPAR_MEMBER));
      lpPP= lpPP->lpNext,iDummy++) { 
             InvalidateRect(lpPP->hChild, NULL,TRUE);                                          
		}
 // redraw statuswindow    ID = 1111    see expert.c  createwindow                                                           
	  // 9.12.97 : whats that ???
//    SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_COMMAND,1111,0);
   return 0;
}

/****************************************************************************************
 *  Function :  void DrawAll(int iNr, LPHGRAPH lphGraph, RECT Rect)
 *  
 *              dependant on graphic - marker draw     coordinate system   
 *                                                 and related curves
 *              the output device is assigned by  hGraph.hDC
 *              (supported :  printer : if(lphGraph->bPrinter)
 *                                      else : screen       )  
 *              
 *  Author :  C. Sperr 
 *  Date   :  26.01.94
 *
 */
void XDrawAll(int iNr, LPHGRAPH lphGraph, RECT Rect)
{
  HGRAPH hGraph;
  static short color = 1;
  int     iMax;                 
  PSPROFILE   pSo=NULL;
  
  pSo = GetSoilPoi();       


  hGraph.hDC      = lphGraph->hDC;
  hGraph.bPrinter = lphGraph->bPrinter;
   switch (iNr)
  {
             
    case PLOTH2OET:
        GraphOpen(lphGraph,(LPRECT)&Rect,1,
               (LPSTR)G_H2OET_SS_TXT,
               (LPSTR)G_H2OET_XA_TXT,
               (LPSTR)G_H2OET_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
               GrXmin[PLOTH2OET],GrXmax[PLOTH2OET],GrXdiv[PLOTH2OET],GrXdec[PLOTH2OET],
               GrYmin[PLOTH2OET],GrYmax[PLOTH2OET],GrYdiv[PLOTH2OET],GrYdec[PLOTH2OET]);


        //colour rot
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                            (float far *)afH2OET1, // Feld mit Y-Werten
                            (int)dTimeCount,         // Anzahl
                            GraphCol[0],             // Farbe
                            PS_SOLID);               // Linientyp


        //colour gruen;
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afH2OET2,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[1],               // Farbe
                          PS_SOLID);                 // Linientyp

        //colour blau
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afH2OET3,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[2],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  gelb
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afH2OET4,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[3],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  hellblau
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afH2OET5,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[4],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour violet
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afH2OET6,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[5],               // Farbe
                          PS_SOLID);                 // Linientyp

 
        break;

    case PLOTH2OBAL:
        GraphOpen(lphGraph,(LPRECT)&Rect,1,
               (LPSTR)G_H2OBAL_SS_TXT,
               (LPSTR)G_H2OBAL_XA_TXT,
               (LPSTR)G_H2OBAL_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
               GrXmin[PLOTH2OBAL],GrXmax[PLOTH2OBAL],GrXdiv[PLOTH2OBAL],GrXdec[PLOTH2OBAL],
               GrYmin[PLOTH2OBAL],GrYmax[PLOTH2OBAL],GrYdiv[PLOTH2OBAL],GrYdec[PLOTH2OBAL]);


        //colour rot
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                            (float far *)afH2OBal1, // Feld mit Y-Werten
                            (int)dTimeCount,         // Anzahl
                            GraphCol[0],             // Farbe
                            PS_SOLID);               // Linientyp


        //colour gruen;
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afH2OBal2,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[1],               // Farbe
                          PS_SOLID);                 // Linientyp

        //colour blau
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afH2OBal3,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[2],               // Farbe
                          PS_SOLID);                 // Linientyp
                                                
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afH2OET5,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[3],               // Farbe
                          PS_SOLID);                 // Linientyp
                                                
       //colour  gelb
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afH2OBal4,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[4],               // Farbe
                          PS_SOLID);                 // Linientyp

        //Drained water out of Profile
            GraphFltLine(hGraph,(float far *)afTime    , // Feld mit X-Werten
                          (float far *)afKumDrainW, // Feld mit Y-Werten
                          (int)dTimeCount ,           // Anzahl
                          GraphCol[5],         // Farbe
                          PS_SOLID);           // Linientyp
 
        break;

    case PLOTH2OPOT:
        GraphOpen(lphGraph,(LPRECT)&Rect,1,
               (LPSTR)G_H2O_POT_SS_TXT,
               (LPSTR)G_H2O_POT_XA_TXT,
               (LPSTR)G_H2O_POT_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
               GrXmin[PLOTH2OPOT],GrXmax[PLOTH2OPOT],GrXdiv[PLOTH2OPOT],GrXdec[PLOTH2OPOT],
               GrYmin[PLOTH2OPOT],GrYmax[PLOTH2OPOT],GrYdiv[PLOTH2OPOT],GrYdec[PLOTH2OPOT]);


        //colour rot
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                            (float far *)afH2OPot1, // Feld mit Y-Werten
                            (int)dTimeCount,         // Anzahl
                            GraphCol[0],             // Farbe
                            PS_SOLID);               // Linientyp


        //colour gruen;
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afH2OPot2,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[1],               // Farbe
                          PS_SOLID);                 // Linientyp

        //colour blau
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afH2OPot3,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[2],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  gelb
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afH2OPot4,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[3],               // Farbe
                          PS_SOLID);                 // Linientyp

        break;

    case PLOTH2OFLUX:
        GraphOpen(lphGraph,(LPRECT)&Rect,1,
               (LPSTR)G_H2O_FLUX_SS_TXT,
               (LPSTR)G_H2O_FLUX_XA_TXT,
               (LPSTR)G_H2O_FLUX_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
               GrXmin[PLOTH2OFLUX],GrXmax[PLOTH2OFLUX],GrXdiv[PLOTH2OFLUX],GrXdec[PLOTH2OFLUX],
               GrYmin[PLOTH2OFLUX],GrYmax[PLOTH2OFLUX],GrYdiv[PLOTH2OFLUX],GrYdec[PLOTH2OFLUX]);


        //colour rot
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                            (float far *)afH2OFlux1, // Feld mit Y-Werten
                            (int)dTimeCount,         // Anzahl
                            GraphCol[0],             // Farbe
                            PS_SOLID);               // Linientyp


        //colour gruen;
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afH2OFlux2,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[1],               // Farbe
                          PS_SOLID);                 // Linientyp

        //colour blau
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afH2OFlux3,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[2],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  gelb
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afH2OFlux4,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[3],               // Farbe
                          PS_SOLID);                 // Linientyp

        break;

    case PLOTH2OCOND:
        GraphOpen(lphGraph,(LPRECT)&Rect,1,
               (LPSTR)G_H2O_COND_SS_TXT,
               (LPSTR)G_H2O_COND_XA_TXT,
               (LPSTR)G_H2O_COND_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
               GrXmin[PLOTH2OCOND],GrXmax[PLOTH2OCOND],GrXdiv[PLOTH2OCOND],GrXdec[PLOTH2OCOND],
               GrYmin[PLOTH2OCOND],GrYmax[PLOTH2OCOND],GrYdiv[PLOTH2OCOND],GrYdec[PLOTH2OCOND]);


        //colour rot
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                            (float far *)afH2OCond1, // Feld mit Y-Werten
                            (int)dTimeCount,         // Anzahl
                            GraphCol[0],             // Farbe
                            PS_SOLID);               // Linientyp


        //colour gruen;
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afH2OCond2,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[1],               // Farbe
                          PS_SOLID);                 // Linientyp

        //colour blau
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afH2OCond3,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[2],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  gelb
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afH2OCond4,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[3],               // Farbe
                          PS_SOLID);                 // Linientyp

        break;

    case PLOTTEMP_ICE:
        GraphOpen(lphGraph,(LPRECT)&Rect,1,
               (LPSTR)G_TEMP_ICE_SS_TXT,
               (LPSTR)G_TEMP_ICE_XA_TXT,
               (LPSTR)G_TEMP_ICE_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
               GrXmin[PLOTTEMP_ICE],GrXmax[PLOTTEMP_ICE],GrXdiv[PLOTTEMP_ICE],GrXdec[PLOTTEMP_ICE],
               GrYmin[PLOTTEMP_ICE],GrYmax[PLOTTEMP_ICE],GrYdiv[PLOTTEMP_ICE],GrYdec[PLOTTEMP_ICE]);


        //colour rot
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                            (float far *)afTempIce1, // Feld mit Y-Werten
                            (int)dTimeCount,         // Anzahl
                            GraphCol[0],             // Farbe
                            PS_SOLID);               // Linientyp


        //colour gruen;
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afTempIce2,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[1],               // Farbe
                          PS_SOLID);                 // Linientyp

        //colour blau
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afTempIce3,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[2],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  gelb
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afTempIce4,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[3],               // Farbe
                          PS_SOLID);                 // Linientyp
        break;


    case PLOTNITROCUMGAS:
        GraphOpen(lphGraph,(LPRECT)&Rect,1,
               (LPSTR)G_NITROCUMGAS_SS_TXT,
               (LPSTR)G_NITROCUMGAS_XA_TXT,
               (LPSTR)G_NITROCUMGAS_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
               GrXmin[PLOTNITROCUMGAS],GrXmax[PLOTNITROCUMGAS],GrXdiv[PLOTNITROCUMGAS],GrXdec[PLOTNITROCUMGAS],
               GrYmin[PLOTNITROCUMGAS],GrYmax[PLOTNITROCUMGAS],GrYdiv[PLOTNITROCUMGAS],GrYdec[PLOTNITROCUMGAS]);


        //colour rot
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                            (float far *)afNitroCumGas1, // Feld mit Y-Werten
                            (int)dTimeCount,         // Anzahl
                            GraphCol[0],             // Farbe
                            PS_SOLID);               // Linientyp


        //colour gruen;
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afNitroCumGas2,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[1],               // Farbe
                          PS_SOLID);                 // Linientyp

        //colour blau
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afNitroCumGas3,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[2],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  gelb
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afNitroCumGas4,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[3],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  hellblau
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afNitroCumGas5,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[4],               // Farbe
                          PS_SOLID);                 // Linientyp

        break;


    case PLOTNITROGAS:
        GraphOpen(lphGraph,(LPRECT)&Rect,1,
               (LPSTR)G_NITROGAS_SS_TXT,
               (LPSTR)G_NITROGAS_XA_TXT,
               (LPSTR)G_NITROGAS_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
               GrXmin[PLOTNITROGAS],GrXmax[PLOTNITROGAS],GrXdiv[PLOTNITROGAS],GrXdec[PLOTNITROGAS],
               GrYmin[PLOTNITROGAS],GrYmax[PLOTNITROGAS],GrYdiv[PLOTNITROGAS],GrYdec[PLOTNITROGAS]);


        //colour rot
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                            (float far *)afNitroGas1, // Feld mit Y-Werten
                            (int)dTimeCount,         // Anzahl
                            GraphCol[0],             // Farbe
                            PS_SOLID);               // Linientyp


        //colour gruen;
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afNitroGas2,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[1],               // Farbe
                          PS_SOLID);                 // Linientyp

        //colour blau
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afNitroGas3,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[2],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  gelb
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afNitroGas4,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[3],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  hellblau
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afNitroGas5,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[4],               // Farbe
                          PS_SOLID);                 // Linientyp
        break;

    case PLOTNITROPOOLS:
        GraphOpen(lphGraph,(LPRECT)&Rect,1,
               (LPSTR)G_NITROPOOLS_SS_TXT,
               (LPSTR)G_NITROPOOLS_XA_TXT,
               (LPSTR)G_NITROPOOLS_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
               GrXmin[PLOTNITROPOOLS],GrXmax[PLOTNITROPOOLS],GrXdiv[PLOTNITROPOOLS],GrXdec[PLOTNITROPOOLS],
               GrYmin[PLOTNITROPOOLS],GrYmax[PLOTNITROPOOLS],GrYdiv[PLOTNITROPOOLS],GrYdec[PLOTNITROPOOLS]);


        //colour rot
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                            (float far *)afNitroPools1, // Feld mit Y-Werten
                            (int)dTimeCount,         // Anzahl
                            GraphCol[0],             // Farbe
                            PS_SOLID);               // Linientyp


        //colour gruen;
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afNitroPools2,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[1],               // Farbe
                          PS_SOLID);                 // Linientyp

        //colour blau
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afNitroPools3,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[2],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  gelb
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afNitroPools4,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[3],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  hellblau
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afNitroPools5,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[4],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour violet
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afNitroPools6,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[5],               // Farbe
                          PS_SOLID);                 // Linientyp

 
        break;


    case PLOTNITROCN:
        GraphOpen(lphGraph,(LPRECT)&Rect,1,
               (LPSTR)G_NITROCN_SS_TXT,
               (LPSTR)G_NITROCN_XA_TXT,
               (LPSTR)G_NITROCN_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
               GrXmin[PLOTNITROCN],GrXmax[PLOTNITROCN],GrXdiv[PLOTNITROCN],GrXdec[PLOTNITROCN],
               GrYmin[PLOTNITROCN],GrYmax[PLOTNITROCN],GrYdiv[PLOTNITROCN],GrYdec[PLOTNITROCN]);


        //colour rot
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                            (float far *)afNitroCN1, // Feld mit Y-Werten
                            (int)dTimeCount,         // Anzahl
                            GraphCol[0],             // Farbe
                            PS_SOLID);               // Linientyp


        //colour gruen;
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afNitroCN2,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[1],               // Farbe
                          PS_SOLID);                 // Linientyp

        //colour blau
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afNitroCN3,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[2],               // Farbe
                          PS_SOLID);                 // Linientyp

        break;

    case PLOTNITROMINER:
        GraphOpen(lphGraph,(LPRECT)&Rect,1,
               (LPSTR)G_NITROMINER_SS_TXT,
               (LPSTR)G_NITROMINER_XA_TXT,
               (LPSTR)G_NITROMINER_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
               GrXmin[PLOTNITROMINER],GrXmax[PLOTNITROMINER],GrXdiv[PLOTNITROMINER],GrXdec[PLOTNITROMINER],
               GrYmin[PLOTNITROMINER],GrYmax[PLOTNITROMINER],GrYdiv[PLOTNITROMINER],GrYdec[PLOTNITROMINER]);


        //colour rot
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                            (float far *)afNitroMiner1, // Feld mit Y-Werten
                            (int)dTimeCount,         // Anzahl
                            GraphCol[0],             // Farbe
                            PS_SOLID);               // Linientyp


        //colour gruen;
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afNitroMiner2,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[1],               // Farbe
                          PS_SOLID);                 // Linientyp

        //colour blau
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afNitroMiner3,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[2],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  gelb
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afNitroMiner4,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[3],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  hellblau
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afNitroMiner5,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[4],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour violet
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afNitroMiner6,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[5],               // Farbe
                          PS_SOLID);                 // Linientyp

 
        break;

    case PLOTROOTLENGTHDT:
        GraphOpen(lphGraph,(LPRECT)&Rect,1,
               (LPSTR)G_ROOTLENGTHDT_SS_TXT,
               (LPSTR)G_ROOTLENGTHDT_XA_TXT,
               (LPSTR)G_ROOTLENGTHDT_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
               GrXmin[PLOTROOTLENGTHDT],GrXmax[PLOTROOTLENGTHDT],GrXdiv[PLOTROOTLENGTHDT],GrXdec[PLOTROOTLENGTHDT],
               GrYmin[PLOTROOTLENGTHDT],GrYmax[PLOTROOTLENGTHDT],GrYdiv[PLOTROOTLENGTHDT],GrYdec[PLOTROOTLENGTHDT]);


        //colour rot
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                            (float far *)afPlant3, // Feld mit Y-Werten
                            (int)dTimeCount,         // Anzahl
                            GraphCol[0],             // Farbe
                            PS_SOLID);               // Linientyp


        //colour gruen;
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afPlant4,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[1],               // Farbe
                          PS_SOLID);                 // Linientyp

        //colour blau
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afPlant5,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[2],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  gelb
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afPlant6,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[3],               // Farbe
                          PS_SOLID);                 // Linientyp

        break;


    case PLOTMEASH2O:
    
 
        GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
                  (LPSTR)G_MEASH2O_SS_TXT,
                  (LPSTR)G_MEASH2O_XA_TXT,
                  (LPSTR)G_MEASH2O_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
                  GrXmin[PLOTMEASH2O],GrXmax[PLOTMEASH2O],GrXdiv[PLOTMEASH2O],GrXdec[PLOTMEASH2O],
                  GrYmin[PLOTMEASH2O],GrYmax[PLOTMEASH2O],GrYdiv[PLOTMEASH2O],GrYdec[PLOTMEASH2O]);
                                  
      
      iMax = min(3, XGetNoOfH2OMeasureLayers());
      if (iMax >=1)   {
       GraphFltLine(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasH2OSim_1, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[0],         // Farbe
                            PS_SOLID);           // Linientyp  
       XGraphMeasPoints(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasH2O_1, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[0],         // Farbe
                            PS_SOLID);           // Linientyp  
       XWriteMeasDifference(hGraph,(float far *)afTime,   //  time base data 
                            (float far *)afMeasH2O_1, // measurement data array
                            (float far *)afMeasH2OSim_1,     //  simulation data         
                            (int)1,                // digits 
                            (int)dTimeCount);            // actual simulation day counter
                            
        }
                                
      if (iMax >=2){
       GraphFltLine(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasH2OSim_2, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[1],         // Farbe
                            PS_SOLID);           // Linientyp  
       XGraphMeasPoints(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasH2O_2, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[1],         // Farbe
                            PS_SOLID);           // Linientyp  
       XWriteMeasDifference(hGraph,(float far *)afTime,   //  time base data 
                            (float far *)afMeasH2O_2, // measurement data array
                            (float far *)afMeasH2OSim_2,     //  simulation data 
                            (int)1,                // digits 
                            (int)dTimeCount);            // actual simulation day counter

       }              
      if (iMax >=3){
       GraphFltLine(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasH2OSim_3, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[2],         // Farbe
                            PS_SOLID);           // Linientyp  
       XGraphMeasPoints(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasH2O_3, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[2],         // Farbe
                            PS_SOLID);           // Linientyp  
       XWriteMeasDifference(hGraph,(float far *)afTime,   //  time base data 
                            (float far *)afMeasH2O_3, // measurement data array
                            (float far *)afMeasH2OSim_3,     //  simulation data 
                            (int)1,                // digits 
                            (int)dTimeCount);            // actual simulation day counter
                            
       }                     
      if (iMax >=4){
       GraphFltLine(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasH2OSim_4, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[3],         // Farbe
                            PS_SOLID);           // Linientyp  
       XGraphMeasPoints(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasH2O_4, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[3],         // Farbe
                            PS_SOLID);           // Linientyp  
       XWriteMeasDifference(hGraph,(float far *)afTime,   //  time base data 
                            (float far *)afMeasH2O_4, // measurement data array
                            (float far *)afMeasH2OSim_4,     //  simulation data 
                            (int)1,                // digits 
                            (int)dTimeCount);            // actual simulation day counter
                            
       }                     
      if (iMax >= 5){
        GraphFltLine(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasH2OSim_5, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[4],         // Farbe
                            PS_SOLID);           // Linientyp  
       XGraphMeasPoints(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasH2O_5, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[4],         // Farbe
                            PS_SOLID);           // Linientyp  
       XWriteMeasDifference(hGraph,(float far *)afTime,   //  time base data 
                            (float far *)afMeasH2O_5, // measurement data array
                            (float far *)afMeasH2OSim_5,     //  simulation data 
                            (int)1,                // digits 
                            (int)dTimeCount);            // actual simulation day counter
                            
       }                     
        break;

          
    case PLOTMEASNO3:

        iMax = XGetNoOfNitroMeasureLayers();
        /*******/
        iMax = 3;
        /*******/
        GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
                  (LPSTR)G_MEASNO3_SS_TXT,
                  (LPSTR)G_MEASNO3_XA_TXT,
                  (LPSTR)G_MEASNO3_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
                  GrXmin[PLOTMEASNO3],GrXmax[PLOTMEASNO3],GrXdiv[PLOTMEASNO3],GrXdec[PLOTMEASNO3],
                  GrYmin[PLOTMEASNO3],GrYmax[PLOTMEASNO3],GrYdiv[PLOTMEASNO3],GrYdec[PLOTMEASNO3]);
                                  
       if (iMax >=1)   {
       GraphFltLine(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasNH4Sim_1, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[3],         // Farbe
                            PS_SOLID);           // Linientyp  
       XGraphMeasPoints(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasNH4_1, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[3],         // Farbe
                            PS_SOLID);           // Linientyp  
       XWriteMeasDifference(hGraph,(float far *)afTime,   //  time base data 
                            (float far *)afMeasNH4_1, // measurement data array
                            (float far *)afMeasNH4Sim_1,     //  simulation data 
                            (int)0,                // digits 
                            (int)dTimeCount);            // actual simulation day counter
  
       }
       if (iMax >=1)   {
       GraphFltLine(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasNO3Sim_1, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[0],         // Farbe
                            PS_SOLID);           // Linientyp  
       XGraphMeasPoints(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasNO3_1, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[0],         // Farbe
                            PS_SOLID);           // Linientyp  
       XWriteMeasDifference(hGraph,(float far *)afTime,   //  time base data 
                            (float far *)afMeasNO3_1, // measurement data array
                            (float far *)afMeasNO3Sim_1,     //  simulation data 
                            (int)0,                // digits 
                            (int)dTimeCount);            // actual simulation day counter

       }
       if (iMax >=2)   {
       GraphFltLine(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasNO3Sim_2, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[1],         // Farbe
                            PS_SOLID);           // Linientyp  
       XGraphMeasPoints(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasNO3_2, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[1],         // Farbe
                            PS_SOLID);           // Linientyp  
       }
       if (iMax >=3)   {
       GraphFltLine(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasNO3Sim_3, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[2],         // Farbe
                            PS_SOLID);           // Linientyp  
       XGraphMeasPoints(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasNO3_3, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[2],         // Farbe
                            PS_SOLID);           // Linientyp  
       }
       if (iMax >=4)   {
       GraphFltLine(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasNO3Sim_4, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[3],         // Farbe
                            PS_SOLID);           // Linientyp  
       XGraphMeasPoints(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasNO3_4, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[3],         // Farbe
                            PS_SOLID);           // Linientyp  
       }
       if (iMax >=5)   {
       GraphFltLine(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasNO3Sim_5, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[4],         // Farbe
                            PS_SOLID);           // Linientyp  
       XGraphMeasPoints(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasNO3_5, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[4],         // Farbe
                            PS_SOLID);           // Linientyp  
       }               
 
        break;


    case PLOTROOTLENGTH:
        GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
                  (LPSTR)G_ROOTLENGTH_SS_TXT,
                  (LPSTR)G_ROOTLENGTH_XA_TXT,
                  (LPSTR)G_ROOTLENGTH_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
                  GrXmin[PLOTROOTLENGTH],GrXmax[PLOTROOTLENGTH],GrXdiv[PLOTROOTLENGTH],GrXdec[PLOTROOTLENGTH],
                  GrYmin[PLOTROOTLENGTH],GrYmax[PLOTROOTLENGTH],GrYdiv[PLOTROOTLENGTH],GrYdec[PLOTROOTLENGTH]);

       GraphFltLine(hGraph,(float far *)afNullRootLengthDensity, // Feld mit X-Werten
                            (float far *)afTiefe, // Feld mit Y-Werten
                            (int) pSo->iLayers-1,      // Anzahl
                            WHITE_CURVE, // GraphCol[0],         // Farbe
                            PS_SOLID);           // Linientyp
       
      GraphFltLine(hGraph,(float far *)afRootLengthDensity, // Feld mit X-Werten
                            (float far *)afTiefe, // Feld mit Y-Werten
                            (int) pSo->iLayers-1,      // Anzahl
                            GraphCol[0],         // Farbe
                            PS_SOLID);           // Linientyp
 
        break;

    case PLOTDEVSTAGE:
       
        GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
                  (LPSTR)G_DEVSTAGE_SS_TXT,
                  (LPSTR)G_DEVSTAGE_XA_TXT,
                  (LPSTR)G_DEVSTAGE_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
                  GrXmin[PLOTDEVSTAGE],GrXmax[PLOTDEVSTAGE],GrXdiv[PLOTDEVSTAGE],GrXdec[PLOTDEVSTAGE],
                  GrYmin[PLOTDEVSTAGE],GrYmax[PLOTDEVSTAGE],GrYdiv[PLOTDEVSTAGE],GrYdec[PLOTDEVSTAGE]);
                                  
                                  
       GraphFltLine(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afDevStage, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[0],         // Farbe
                            PS_SOLID);           // Linientyp  
       XGraphMeasPoints(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasDevStage, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[0],         // Farbe
                            PS_SOLID);           // Linientyp  

       XWriteMeasDifference(hGraph,(float far *)afTime,   //  time base data 
                            (float far *)afMeasDevStage, // measurement data array
                            (float far *)afDevStage,     //  simulation data 
                            (int)0,                // digits 
                            (int)dTimeCount);            // actual simulation day counter

 
        break;

    case PLOTLAI:
        GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
                  (LPSTR)G_LAI_SS_TXT,
                  (LPSTR)G_LAI_XA_TXT,
                  (LPSTR)G_LAI_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
                  GrXmin[PLOTLAI],GrXmax[PLOTLAI],GrXdiv[PLOTLAI],GrXdec[PLOTLAI],
                  GrYmin[PLOTLAI],GrYmax[PLOTLAI],GrYdiv[PLOTLAI],GrYdec[PLOTLAI]);
                                  
                                  
       GraphFltLine(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afLai, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[0],         // Farbe
                            PS_SOLID);           // Linientyp
       XGraphMeasPoints(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasLAI, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[0],         // Farbe
                            PS_SOLID);           // Linientyp  
       XWriteMeasDifference(hGraph,(float far *)afTime,   //  time base data 
                            (float far *)afMeasLAI, // measurement data array
                            (float far *)afLai,     //  simulation data 
                            (int)1,                // digits 
                            (int)dTimeCount);            // actual simulation day counter
 
        break;

 
    case PLOTBIOMASS:
        GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
                  (LPSTR)G_BIOMASS_SS_TXT,
                  (LPSTR)G_BIOMASS_XA_TXT,
                  (LPSTR)G_BIOMASS_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
                  GrXmin[PLOTBIOMASS],GrXmax[PLOTBIOMASS],GrXdiv[PLOTBIOMASS],GrXdec[PLOTBIOMASS],
                  GrYmin[PLOTBIOMASS],GrYmax[PLOTBIOMASS],GrYdiv[PLOTBIOMASS],GrYdec[PLOTBIOMASS]);
                                  
                                  
        //colour = rot
         GraphFltLine(hGraph,(float far *)afTime,    // Feld mit X-Werten
                            (float far *)afGrainWeight, // Feld mit Y-Werten
                            (int)dTimeCount ,           // Anzahl
                            GraphCol[0],         // Farbe
                            PS_SOLID);           // Linientyp
        XGraphMeasPoints(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasGBiomass, // Feld mit Y-Werten
                            (int)dTimeCount ,           // Anzahl
                            GraphCol[0],                // Farbe
                            PS_SOLID);                  // Linientyp  

       XWriteMeasDifference(hGraph,(float far *)afTime,   //  time base data 
                            (float far *)afMeasGBiomass, // measurement data array
                            (float far *)afGrainWeight,  //  simulation data 
                            (int)1,                      // digits 
                            (int)dTimeCount);            // actual simulation day counter

    
         //colour = green
         GraphFltLine(hGraph,(float far *)afTime,    // Feld mit X-Werten
                            (float far *)afLeafWeight, // Feld mit Y-Werten
                            (int)dTimeCount ,           // Anzahl
                            GraphCol[1],         // Farbe
                            PS_SOLID);           // Linientyp
        //colour = blue
        GraphFltLine(hGraph,(float far *)afTime,    // Feld mit X-Werten
                            (float far *)afStemWeight, // Feld mit Y-Werten
                            (int)dTimeCount ,           // Anzahl
                            GraphCol[2],         // Farbe
                            PS_SOLID);           // Linientyp
       //colour = yellow
          GraphFltLine(hGraph,(float far *)afTime,    // Feld mit X-Werten
                            (float far *)afRootWeight, // Feld mit Y-Werten
                            (int)dTimeCount ,           // Anzahl
                            GraphCol[3],         // Farbe
                            PS_SOLID);           // Linientyp
    
        //colour = lightblue
        GraphFltLine(hGraph,(float far *)afTime,    // Feld mit X-Werten
                            (float far *)afObVegWeight, // Feld mit Y-Werten
                            (int)dTimeCount ,           // Anzahl
                            GraphCol[4],         // Farbe
                            PS_SOLID);           // Linientyp

        //colour = lightblue
        XGraphMeasPoints(hGraph,(float far *)afTime,    // Feld mit X-Werten
                            (float far *)afMeasOBiomass, // Feld mit Y-Werten
                            (int)dTimeCount ,           // Anzahl
                            GraphCol[4],         // Farbe
                            PS_SOLID);           // Linientyp
       XWriteMeasDifference(hGraph,(float far *)afTime,   //  time base data 
                            (float far *)afMeasOBiomass, // measurement data array
                            (float far *)afObVegWeight,     //  simulation data 
                            (int)1,                // digits 
                            (int)dTimeCount);            // actual simulation day counter


        break;
    case PLOTTILLERS:
        GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
                  (LPSTR)G_TILLERS_SS_TXT,
                  (LPSTR)G_TILLERS_XA_TXT,
                  (LPSTR)G_TILLERS_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
                  GrXmin[PLOTTILLERS],GrXmax[PLOTTILLERS],GrXdiv[PLOTTILLERS],GrXdec[PLOTTILLERS],
                  GrYmin[PLOTTILLERS],GrYmax[PLOTTILLERS],GrYdiv[PLOTTILLERS],GrYdec[PLOTTILLERS]);
                                  
                                  
       GraphFltLine(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afTillers, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[0],         // Farbe
                            PS_SOLID);           // Linientyp
       XGraphMeasPoints(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afMeasTillers, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[0],         // Farbe
                            PS_SOLID);           // Linientyp
       XWriteMeasDifference(hGraph,(float far *)afTime,   //  time base data 
                            (float far *)afMeasTillers, // measurement data array
                            (float far *)afTillers,     //  simulation data 
                            (int)0,                // digits 
                            (int)dTimeCount);            // actual simulation day counter
                            
        break;                                    
        
    case PLOTTRANSP:
        GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
                  (LPSTR)G_TRANSP_SS_TXT,
                  (LPSTR)G_TRANSP_XA_TXT,
                  (LPSTR)G_TRANSP_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
                  GrXmin[PLOTTRANSP],GrXmax[PLOTTRANSP],GrXdiv[PLOTTRANSP],GrXdec[PLOTTRANSP],
                  GrYmin[PLOTTRANSP],GrYmax[PLOTTRANSP],GrYdiv[PLOTTRANSP],GrYdec[PLOTTRANSP]);
                                  
                                  
       GraphFltLine(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afActTr, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[0],         // Farbe
                            PS_SOLID);           // Linientyp

       GraphFltLine(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afPlant7, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[1],         // Farbe
                            PS_SOLID);           // Linientyp
 
 
        break;
    case PLOTNUPTAKE:
        GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
                  (LPSTR)G_NUPTAKE_SS_TXT,
                  (LPSTR)G_NUPTAKE_XA_TXT,
                  (LPSTR)G_NUPTAKE_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
                  GrXmin[PLOTNUPTAKE],GrXmax[PLOTNUPTAKE],GrXdiv[PLOTNUPTAKE],GrXdec[PLOTNUPTAKE],
                  GrYmin[PLOTNUPTAKE],GrYmax[PLOTNUPTAKE],GrYdiv[PLOTNUPTAKE],GrYdec[PLOTNUPTAKE]);
                                  
                                  
       GraphFltLine(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afActNUptake, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[0],         // Farbe
                            PS_SOLID);           // Linientyp
       GraphFltLine(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afPlant8, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[1],         // Farbe
                            PS_SOLID);           // Linientyp
 
       XGraphMeasPoints(hGraph,(float far *)afTime,    // Feld mit X-Werten
                            (float far *)afMeasOBiomassN, // Feld mit Y-Werten
                            (int)dTimeCount ,           // Anzahl
                            GraphCol[0],         // Farbe
                            PS_SOLID);           // Linientyp
       XWriteMeasDifference(hGraph,(float far *)afTime,   //  time base data 
                            (float far *)afMeasOBiomassN, // measurement data array
                            (float far *)afActNUptake,     //  simulation data 
                            (int)0,                // digits 
                            (int)dTimeCount);            // actual simulation day counter          
                           

       break;
    case PLOTNCONC:
        GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
                  (LPSTR)G_NCONC_SS_TXT,
                  (LPSTR)G_NCONC_XA_TXT,
                  (LPSTR)G_NCONC_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
                  GrXmin[PLOTNCONC],GrXmax[PLOTNCONC],GrXdiv[PLOTNCONC],GrXdec[PLOTNCONC],
                  GrYmin[PLOTNCONC],GrYmax[PLOTNCONC],GrYdiv[PLOTNCONC],GrYdec[PLOTNCONC]);
                                  
                                  
 
       GraphFltLine(hGraph,(float far *)afTime, // Feld mit X-Werten
                            (float far *)afNConc, // Feld mit Y-Werten
                            (int)dTimeCount ,      // Anzahl
                            GraphCol[1],         // Farbe
                            PS_SOLID);           // Linientyp
                            
       XGraphMeasPoints(hGraph,(float far *)afTime,    // Feld mit X-Werten
                            (float far *)afMeasConcN, // Feld mit Y-Werten
                            (int)dTimeCount ,           // Anzahl
                            GraphCol[1],         // Farbe
                            PS_SOLID);           // Linientyp
       XWriteMeasDifference(hGraph,(float far *)afTime,   //  time base data 
                            (float far *)afMeasConcN, // measurement data array
                            (float far *)afNConc,     //  simulation data 
                            (int)2,                // digits 
                            (int)dTimeCount);            // actual simulation day counter
                            
 
        break;
 
  
    case PLOTNITRODZ:
        GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
                  (LPSTR)G_NO3DZ_SS_TXT,
                  (LPSTR)G_NO3DZ_XA_TXT,
                  (LPSTR)G_NO3DZ_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
                  GrXmin[PLOTNITRODZ],GrXmax[PLOTNITRODZ],GrXdiv[PLOTNITRODZ],GrXdec[PLOTNITRODZ],
                  GrYmin[PLOTNITRODZ],GrYmax[PLOTNITRODZ],GrYdiv[PLOTNITRODZ],GrYdec[PLOTNITRODZ]);
                                  
    
       GraphFltLine(hGraph,(float far *)afANitroDZ, // Feld mit X-Werten
                            (float far *)afTiefe, // Feld mit Y-Werten
                            (int) pSo->iLayers-1,      // Anzahl
                            GraphCol[0],         // Farbe
                            PS_SOLID);           // Linientyp
 
    
       GraphFltLine(hGraph,(float far *)afOldNitroDZ, // Feld mit X-Werten
                            (float far *)afTiefe, // Feld mit Y-Werten
                            (int) pSo->iLayers-1,      // Anzahl
                            WHITE_CURVE,         // Farbe
                            PS_SOLID);           // Linientyp

        //------------------------------                                               
    
       GraphFltLine(hGraph,(float far *)afNitroDZ, // Feld mit X-Werten
                            (float far *)afTiefe, // Feld mit Y-Werten
                            (int) pSo->iLayers-1,           // Anzahl
                            GraphCol[1],         // Farbe
                            PS_SOLID);           // Linientyp
        break;

    case PLOTNITRODT:
        GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
                  (LPSTR)G_NO3DT_SS_TXT,
                  (LPSTR)G_NO3DT_XA_TXT,
                  (LPSTR)G_NO3DT_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
                  GrXmin[PLOTNITRODT],GrXmax[PLOTNITRODT],GrXdiv[PLOTNITRODT],GrXdec[PLOTNITRODT],
                  GrYmin[PLOTNITRODT],GrYmax[PLOTNITRODT],GrYdiv[PLOTNITRODT],GrYdec[PLOTNITRODT]);

        //colour = Rot ;
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                            (float far *)afNitro1DT, // Feld mit Y-Werten
                            (int)dTimeCount ,        // Anzahl
                            GraphCol[0],             // Farbe
                            PS_SOLID);               // Linientyp

        //colour = 1;  gruen
        GraphFltLine(hGraph,(float far *)afTime,    // Feld mit X-Werten
                            (float far *)afNitro2DT,// Feld mit Y-Werten
                            (int)dTimeCount ,       // Anzahl
                            GraphCol[1],            // Farbe
                            PS_SOLID);              // Linientyp

        //colour = blau;
        GraphFltLine(hGraph,(float far *)afTime,    // Feld mit X-Werten
                            (float far *)afNitro3DT,// Feld mit Y-Werten
                            (int)dTimeCount ,       // Anzahl
                            GraphCol[2],            // Farbe
                            PS_SOLID);              // Linientyp

        //colour = violet;
        GraphFltLine(hGraph,(float far *)afTime,    // Feld mit X-Werten
                            (float far *)afNitro9DT,// Feld mit Y-Werten
                            (int)dTimeCount ,       // Anzahl
                            GraphCol[3],            // Farbe
                            PS_SOLID);              // Linientyp

       /************************  cs 31.03.94
        */
        //colour = gelb;
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                            (float far *)afNitro10DT,// Feld mit Y-Werten
                            (int)dTimeCount ,        // Anzahl
                            GraphCol[4],            // Farbe
                            PS_SOLID);              // Linientyp
        
        /*
        *************************
        */
        
        break;


    case PLOTNITROTR:
        GraphOpen(lphGraph,(LPRECT)(&Rect),TRUE,
                  (LPSTR)G_NO3TRANS_SS_TXT,
                  (LPSTR)G_NO3TRANS_XA_TXT,
                  (LPSTR)G_NO3TRANS_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
                  GrXmin[PLOTNITROTR],GrXmax[PLOTNITROTR],GrXdiv[PLOTNITROTR],GrXdec[PLOTNITROTR],
                  GrYmin[PLOTNITROTR],GrYmax[PLOTNITROTR],GrYdiv[PLOTNITROTR],GrYdec[PLOTNITROTR]);

        //colour rot
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                            (float far *)afNitro11DT, // Feld mit Y-Werten
                            (int)dTimeCount,         // Anzahl
                            GraphCol[0],             // Farbe
                            PS_SOLID);               // Linientyp


        //colour gruen;
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afNitro12DT,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[1],               // Farbe
                          PS_SOLID);                 // Linientyp

        //colour blau
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afNitro13DT,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[2],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  hellblau
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afNitro14DT,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[3],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  dklblau
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afNitro15DT,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[4],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour violett
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afNitro16DT,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[5],               // Farbe
                          PS_SOLID);                 // Linientyp
        break;


       case PLOTNITROBAL:
        GraphOpen(lphGraph,(LPRECT)(&Rect),TRUE,
                  (LPSTR)G_NBALANCE_SS_TXT,
                  (LPSTR)G_NBALANCE_XA_TXT,
                  (LPSTR)G_NBALANCE_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
                  GrXmin[PLOTNITROBAL],GrXmax[PLOTNITROBAL],GrXdiv[PLOTNITROBAL],GrXdec[PLOTNITROBAL],
                  GrYmin[PLOTNITROBAL],GrYmax[PLOTNITROBAL],GrYdiv[PLOTNITROBAL],GrYdec[PLOTNITROBAL]);

        //colour rot
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                            (float far *)afNitroBal1, // Feld mit Y-Werten
                            (int)dTimeCount,         // Anzahl
                            GraphCol[0],             // Farbe
                            PS_SOLID);               // Linientyp


        //colour gruen;
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afNitroBal2,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[1],               // Farbe
                          PS_SOLID);                 // Linientyp

        //colour blau
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afNitroBal3,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[2],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  gelb
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afNitroBal4,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[3],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  hellblau
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afNitroBal5,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[4],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour violet

       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afNitroBal6,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[5],               // Farbe
                          PS_SOLID);                 // Linientyp

 
        break;

       case PLOTNITROCUM:
        GraphOpen(lphGraph,(LPRECT)(&Rect),TRUE,
                  (LPSTR)NITRO_CUM_TXT,
                  (LPSTR)G_NBALANCE_XA_TXT,
                  (LPSTR)G_NBALANCE_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
                  GrXmin[PLOTNITROCUM],GrXmax[PLOTNITROCUM],GrXdiv[PLOTNITROCUM],GrXdec[PLOTNITROCUM],
                  GrYmin[PLOTNITROCUM],GrYmax[PLOTNITROCUM],GrYdiv[PLOTNITROCUM],GrYdec[PLOTNITROCUM]);
        //colour = 0 rot     Auswaschung
        GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                            (float far *)afNitro4DT,  // Feld mit Y-Werten
                            (int)dTimeCount ,         // Anzahl
                            GraphCol[0],              // Farbe
                            PS_SOLID);                // Linientyp


        //colour = 1;  Gruen  Mineralisierung
        GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                            (float far *)afNitro5DT,  // Feld mit Y-Werten
                            (int)dTimeCount ,         // Anzahl
                            GraphCol[1],              // Farbe
                            PS_SOLID);                // Linientyp

        //colour = 2;  dklBlau Denitrifizierung
        GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                            (float far *)afNitro6DT,  // Feld mit Y-Werten
                            (int)dTimeCount ,         // Anzahl
                            GraphCol[2],              // Farbe
                            PS_SOLID);                // Linientyp


        //colour = 3;  hellblau Nitrifizierung
        GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                            (float far *)afNitro7DT,  // Feld mit Y-Werten
                            (int)dTimeCount ,         // Anzahl
                            GraphCol[3],              // Farbe
                            PS_SOLID);                // Linientyp

        //colour = 4;  violett Immobilisierung
        GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                            (float far *)afNitro8DT,  // Feld mit Y-Werten
                            (int)dTimeCount ,         // Anzahl
                            GraphCol[4],              // Farbe
                            PS_SOLID);                // Linientyp
        break;



   case PLOTDUMMYDZ1:      
           GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
                  (LPSTR)G_DUMMYDZ1_SS_TXT,
                  (LPSTR)G_DUMMYDZ1_XA_TXT,
                  (LPSTR)G_DUMMYDZ1_YA_TXT,
                  PC_BLACK,PC_BLUE,PC_BLACK,
                  GrXmin[PLOTDUMMYDZ1],GrXmax[PLOTDUMMYDZ1],GrXdiv[PLOTDUMMYDZ1],GrXdec[PLOTDUMMYDZ1],
                  GrYmin[PLOTDUMMYDZ1],GrYmax[PLOTDUMMYDZ1],GrYdiv[PLOTDUMMYDZ1],GrYdec[PLOTDUMMYDZ1]);


        //  Ringschieben---------------
        if ((colour >= 14)||(colour <1 )) colour = 1;
        //------------------------------
                          
                          
        GraphFltLine(hGraph,(float far *)afDummyDZ1, // Feld mit X-Werten
                            (float far *)afTiefe,   // Feld mit Y-Werten
                            (int) pSo->iLayers-1,               // Anzahl
                            GraphCol[colour++],     // Farbe
                            PS_SOLID);              // Linientyp

        break;



    case PLOTDUMMYDT1:
        GraphOpen(lphGraph,(LPRECT)&Rect,1,
               (LPSTR)G_DUMMYDT1_SS_TXT,
               (LPSTR)G_DUMMYDT1_XA_TXT,
               (LPSTR)G_DUMMYDT1_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
               GrXmin[PLOTDUMMYDT1],GrXmax[PLOTDUMMYDT1],GrXdiv[PLOTDUMMYDT1],GrXdec[PLOTDUMMYDT1],
               GrYmin[PLOTDUMMYDT1],GrYmax[PLOTDUMMYDT1],GrYdiv[PLOTDUMMYDT1],GrYdec[PLOTDUMMYDT1]);


        //colour rot
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                            (float far *)afDummy11DT, // Feld mit Y-Werten
                            (int)dTimeCount,         // Anzahl
                            GraphCol[0],             // Farbe
                            PS_SOLID);               // Linientyp


        //colour gruen;
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afDummy12DT,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[1],               // Farbe
                          PS_SOLID);                 // Linientyp

        //colour blau
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afDummy13DT,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[2],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  gelb
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afDummy14DT,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[3],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  hellblau
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afDummy15DT,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[4],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour violet
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afDummy16DT,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[5],               // Farbe
                          PS_SOLID);                 // Linientyp

 
        break;
 
   case PLOTDUMMYDZ2:
        GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
                  (LPSTR)G_DUMMYDZ2_SS_TXT,
                  (LPSTR)G_DUMMYDZ2_XA_TXT,
                  (LPSTR)G_DUMMYDZ2_YA_TXT,
                  PC_BLACK,PC_BLUE,PC_BLACK,
                  GrXmin[PLOTDUMMYDZ2],GrXmax[PLOTDUMMYDZ2],GrXdiv[PLOTDUMMYDZ2],GrXdec[PLOTDUMMYDZ2],
                  GrYmin[PLOTDUMMYDZ2],GrYmax[PLOTDUMMYDZ2],GrYdiv[PLOTDUMMYDZ2],GrYdec[PLOTDUMMYDZ2]);


        //  Ringschieben---------------
        if ((colour >= 14)||(colour <1 )) colour = 1;
        //------------------------------

        GraphFltLine(hGraph,(float far *)afDummyDZ2, // Feld mit X-Werten
                            (float far *)afTiefe,   // Feld mit Y-Werten
                            (int) pSo->iLayers-1,               // Anzahl
                            GraphCol[colour++],     // Farbe
                            PS_SOLID);              // Linientyp

        break;



    case PLOTDUMMYDT2:
        GraphOpen(lphGraph,(LPRECT)&Rect,1,
               (LPSTR)G_DUMMYDT2_SS_TXT,
               (LPSTR)G_DUMMYDT2_XA_TXT,
               (LPSTR)G_DUMMYDT2_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
               GrXmin[PLOTDUMMYDT2],GrXmax[PLOTDUMMYDT2],GrXdiv[PLOTDUMMYDT2],GrXdec[PLOTDUMMYDT2],
               GrYmin[PLOTDUMMYDT2],GrYmax[PLOTDUMMYDT2],GrYdiv[PLOTDUMMYDT2],GrYdec[PLOTDUMMYDT2]);


        //colour rot
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                            (float far *)afDummy21DT, // Feld mit Y-Werten
                            (int)dTimeCount,         // Anzahl

                            GraphCol[0],             // Farbe
                            PS_SOLID);               // Linientyp


        //colour gruen;
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afDummy22DT,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[1],               // Farbe
                          PS_SOLID);                 // Linientyp

        //colour blau
        GraphFltLine(hGraph,(float far *)afTime,     // Feld mit X-Werten
                          (float far *)afDummy23DT,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[2],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  gelb
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afDummy24DT,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[3],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour  hellblau
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afDummy25DT,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[4],               // Farbe
                          PS_SOLID);                 // Linientyp

       //colour violet
       GraphFltLine(hGraph,(float far *)afTime,      // Feld mit X-Werten
                          (float far *)afDummy26DT,   // Feld mit Y-Werten
                          (int)dTimeCount ,          // Anzahl
                          GraphCol[5],               // Farbe
                          PS_SOLID);                 // Linientyp

 
        break;

      case  PLOT22:
             GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
                       (LPSTR)G_H2ODT_SS_TXT,
                       (LPSTR)G_H2ODT_XA_TXT,
                       (LPSTR)G_H2ODT_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
                       GrXmin[PLOT22],GrXmax[PLOT22],GrXdiv[PLOT22],GrXdec[PLOT22],
                       GrYmin[PLOT22],GrYmax[PLOT22],GrYdiv[PLOT22],GrYdec[PLOT22]);


                //colour = 0;
             GraphFltLine(hGraph,(float far *)afTime,    // Feld mit X-Werten
                          (float far *)afTime0Theta, // Feld mit Y-Werten
                          (int)dTimeCount ,           // Anzahl
                          GraphCol[0],         // Farbe
                          PS_SOLID);           // Linientyp
             GraphFltLine(hGraph,(float far *)afTime,    // Feld mit X-Werten
                          (float far *)afTime1Theta, // Feld mit Y-Werten
                          (int)dTimeCount ,           // Anzahl
                          GraphCol[1],         // Farbe
                          PS_SOLID);           // Linientyp
             GraphFltLine(hGraph,(float far *)afTime,    // Feld mit X-Werten
                          (float far *)afTime2Theta, // Feld mit Y-Werten
                          (int)dTimeCount ,           // Anzahl
                          GraphCol[2],         // Farbe
                          PS_SOLID);           // Linientyp

             GraphFltLine(hGraph,(float far *)afTime,    // Feld mit X-Werten
                          (float far *)afTime3Theta, // Feld mit Y-Werten
                          (int)dTimeCount ,           // Anzahl
                          GraphCol[3],         // Farbe
                          PS_SOLID);           // Linientyp



      break;

      case  PLOT33:

           GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
               (LPSTR)G_POTENTIAL_SS_TXT,
               (LPSTR)G_POTENTIAL_XA_TXT,
               (LPSTR)G_POTENTIAL_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
               GrXmin[PLOT33],GrXmax[PLOT33],GrXdiv[PLOT33],GrXdec[PLOT33],
               GrYmin[PLOT33],GrYmax[PLOT33],GrYdiv[PLOT33],GrYdec[PLOT33]);


          // Hutson and Cass
           GraphFltLine(hGraph,(float far *)fa1Hyd, // Feld mit X-Werten
                          (float far *)afThetaTest, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[0],         // Farbe                    red
                          PS_SOLID);           // Linientyp
           //  LeachN - Hutson & Wagenet
           GraphFltLine(hGraph,(float far *)fa2Hyd, // Feld mit X-Werten
                          (float far *)afThetaTest, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[1],         // Farbe                    green
                          PS_SOLID);           // Linientyp


           //  Brooks and Corey
            GraphFltLine(hGraph,(float far *)fa3Hyd,// Feld mit X-Werten
                          (float far *)afThetaTest, // Feld mit Y-Werten
                          (int) 100,                // Anzahl
                          GraphCol[2],              // Farbe                     blue
                          PS_SOLID);                // Linientyp
           // Clapp and Hornberger
            GraphFltLine(hGraph,(float far *)fa4Hyd,// Feld mit X-Werten
                          (float far *)afThetaTest, // Feld mit Y-Werten
                          (int) 100,                // Anzahl
                          GraphCol[3],              // Farbe                     yellow
                          PS_SOLID);                // Linientyp
          // modified Hutson
           GraphFltLine(hGraph,(float far *)fa5Hyd, // Feld mit X-Werten
                          (float far *)afThetaTest, // Feld mit Y-Werten
                          (int) 100,                // Anzahl
                          GraphCol[4],              // Farbe                     light blue
                          PS_SOLID);                // Linientyp
          // van Genuchten
           GraphFltLine(hGraph,(float far *)fa6Hyd, // Feld mit X-Werten
                          (float far *)afThetaTest, // Feld mit Y-Werten
                          (int) 100,                // Anzahl
                          GraphCol[5],              // Farbe                     violet
                          PS_SOLID);                // Linientyp

   
      break;

      case  PLOT44:


               GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
                       (LPSTR)G_CONDUCTIVITY_SS_TXT,
                       (LPSTR)G_CONDUCTIVITY_XA_TXT,
                       (LPSTR)G_CONDUCTIVITY_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
                        GrXmin[PLOT44],GrXmax[PLOT44],GrXdiv[PLOT44],GrXdec[PLOT44],
                        GrYmin[PLOT44],GrYmax[PLOT44],GrYdiv[PLOT44],GrYdec[PLOT44]);



               // Hutson and Cass
               GraphFltLine(hGraph,(float far *)fa1HydLeit, // Feld mit X-Werten
                            (float far *)afThetaTest, // Feld mit Y-Werten
                            (int) 100,           // Anzahl
                            GraphCol[0],         // Farbe                       rot
                            PS_SOLID);           // Linientyp


             // LeachN   Hutson and Wagenet
               GraphFltLine(hGraph,(float far *)fa2HydLeit, // Feld mit X-Werten
                          (float far *)afThetaTest, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[1],         // Farbe                          gr�n
                          PS_SOLID);           // Linientyp


               //  Brooks and Corey
               GraphFltLine(hGraph,(float far *)fa3HydLeit, // Feld mit X-Werten
                            (float far *)afThetaTest, // Feld mit Y-Werten
                            (int) 100,           // Anzahl
                            GraphCol[2],         // Farbe                         blau
                            PS_SOLID);           // Linientyp

              //  Clapp and Hornberger
               GraphFltLine(hGraph,(float far *)fa4HydLeit, // Feld mit X-Werten
                          (float far *)afThetaTest, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[3],         // Farbe                          gelb
                          PS_SOLID);           // Linientyp

              // modified Hutson
               GraphFltLine(hGraph,(float far *)fa5HydLeit, // Feld mit X-Werten
                          (float far *)afThetaTest, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[4],         // Farbe                          hellblau
                          PS_SOLID);           // Linientyp

               // van Genuchten
               GraphFltLine(hGraph,(float far *)fa6HydLeit, // Feld mit X-Werten
                          (float far *)afThetaTest, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[5],         // Farbe                          violett
                          PS_SOLID);           // Linientyp


    
           break;

       case  PLOT55:

            GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
               (LPSTR)PRECIPIT_TXT,
               (LPSTR)G_H2OBAL_XA_TXT,
               (LPSTR)G_H2OBAL_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
               GrXmin[PLOT55],GrXmax[PLOT55],GrXdiv[PLOT55],GrXdec[PLOT55],
               GrYmin[PLOT55],GrYmax[PLOT55],GrYdiv[PLOT55],GrYdec[PLOT55]);
            //Niederschl�ge
            GraphFltLine(hGraph,(float far *)afTime    , // Feld mit X-Werten
                          (float far *)afNiederSchl, // Feld mit Y-Werten
                          (int)dTimeCount ,           // Anzahl
                          GraphCol[0],         // Farbe
                          PS_SOLID);           // Linientyp

          //Lufttemp
            GraphFltLine(hGraph,(float far *)afTime    , // Feld mit X-Werten
                          (float far *)afTime0Temp, // Feld mit Y-Werten
                          (int)dTimeCount ,           // Anzahl
                          GraphCol[1],         // Farbe
                          PS_SOLID);           // Linientyp
     

            break;
      case  PLOT66:


           GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
                    (LPSTR)G_H2OINFIL_SS_TXT,
                    (LPSTR)G_H2OINFIL_XA_TXT,
                    (LPSTR)G_H2OINFIL_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
                    GrXmin[PLOT66],GrXmax[PLOT66],GrXdiv[PLOT66],GrXdec[PLOT66],
                    GrYmin[PLOT66],GrYmax[PLOT66],GrYdiv[PLOT66],GrYdec[PLOT66]);

            //SickerWasser
            GraphFltLine(hGraph,(float far *)afTime, // Feld mit X-Werten
                              (float far *)afSickerW, // Feld mit Y-Werten
                              (int)dTimeCount ,           // Anzahl
                              GraphCol[0],         // Farbe
                              PS_SOLID);           // Linientyp

           //Oberflaechenabfluss
            GraphFltLine(hGraph,(float far *)afTime    , // Feld mit X-Werten
                          (float far *)afRunoff, // Feld mit Y-Werten
                          (int)dTimeCount ,           // Anzahl
                          GraphCol[1],         // Farbe
                          PS_SOLID);           // Linientyp
       

      break;
      case  PLOT77:
           GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
                    (LPSTR)G_H2OCUMBAL_SS_TXT,
                    (LPSTR)G_H2OCUMBAL_XA_TXT,
                    (LPSTR)G_H2OCUMBAL_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
                   GrXmin[PLOT77],GrXmax[PLOT77],GrXdiv[PLOT77],GrXdec[PLOT77],
                   GrYmin[PLOT77],GrYmax[PLOT77],GrYdiv[PLOT77],GrYdec[PLOT77]);


              //kumulative Niederschl�ge
            GraphFltLine(hGraph,(float far *)afTime    , // Feld mit X-Werten
                          (float far *)afkumRegen, // Feld mit Y-Werten
                          (int)dTimeCount ,           // Anzahl
                          GraphCol[0],         // Farbe
                          PS_SOLID);           // Linientyp

            //Evaporation
            GraphFltLine(hGraph,(float far *)afTime    , // Feld mit X-Werten
                          (float far *)afkumAktEv, // Feld mit Y-Werten
                          (int)dTimeCount ,           // Anzahl
                          GraphCol[1],         // Farbe
                          PS_SOLID);           // Linientyp

            //Transpiration
            GraphFltLine(hGraph,(float far *)afTime    , // Feld mit X-Werten
                          (float far *)afCumActTr, // Feld mit Y-Werten
                          (int)dTimeCount ,           // Anzahl
                          GraphCol[2],         // Farbe
                          PS_SOLID);           // Linientyp

           //Runoff
            GraphFltLine(hGraph,(float far *)afTime    , // Feld mit X-Werten
                          (float far *)afKumRunoff, // Feld mit Y-Werten
                          (int)dTimeCount ,           // Anzahl
                          GraphCol[3],         // Farbe
                          PS_SOLID);           // Linientyp

          //Infiltration
            GraphFltLine(hGraph,(float far *)afTime    , // Feld mit X-Werten
                          (float far *)afKumSickerW, // Feld mit Y-Werten
                          (int)dTimeCount ,           // Anzahl
                          GraphCol[4],         // Farbe
                          PS_SOLID);           // Linientyp
     
         //Drained water out of Profile
            GraphFltLine(hGraph,(float far *)afTime    , // Feld mit X-Werten
                          (float far *)afKumDrainW, // Feld mit Y-Werten
                          (int)dTimeCount ,           // Anzahl
                          GraphCol[5],         // Farbe
                          PS_SOLID);           // Linientyp
     
      break;
      case  PLOTMSG:

            GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
               (LPSTR)G_H2ODZ_SS_TXT,
               (LPSTR)G_H2ODZ_XA_TXT,
               (LPSTR)G_H2ODZ_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
              GrXmin[PLOTMSG],GrXmax[PLOTMSG],GrXdiv[PLOTMSG],GrXdec[PLOTMSG],
              GrYmin[PLOTMSG],GrYmax[PLOTMSG],GrYdiv[PLOTMSG],GrYdec[PLOTMSG]);


      
            GraphFltLine(hGraph,(float far *)afTheta, // Feld mit X-Werten
                          (float far *)afTiefe, // Feld mit Y-Werten
                          (int) pSo->iLayers-1,           // Anzahl
                          GraphCol[0],         // Farbe
                          PS_SOLID);           // Linientyp
     
            GraphFltLine(hGraph,(float far *)afOldTheta, // Feld mit X-Werten
                          (float far *)afTiefe, // Feld mit Y-Werten
                          (int) pSo->iLayers-1 ,           // Anzahl
                          WHITE_CURVE,         // Farbe
                          PS_SOLID);           // Linientyp
     
            GraphFltLine(hGraph,(float far *)afResTheta, // Feld mit X-Werten
                          (float far *)afTiefe, // Feld mit Y-Werten
                          (int) pSo->iLayers-1 ,           // Anzahl
                          GraphCol[1],         // Farbe
                          PS_SOLID);           // Linientyp

         

      break;
      case  PLOTSOILMSG:

         GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
               (LPSTR)G_SOILTEMPDZ_SS_TXT,
               (LPSTR)G_SOILTEMPDZ_XA_TXT,
               (LPSTR)G_SOILTEMPDZ_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
              GrXmin[PLOTSOILMSG],GrXmax[PLOTSOILMSG],GrXdiv[PLOTSOILMSG],GrXdec[PLOTSOILMSG],
              GrYmin[PLOTSOILMSG],GrYmax[PLOTSOILMSG],GrYdiv[PLOTSOILMSG],GrYdec[PLOTSOILMSG]);



        GraphFltLine(hGraph,(float far *)afTemp, // Feld mit X-Werten
                          (float far *)afTiefe, // Feld mit Y-Werten
                          (int) pSo->iLayers-1,           // Anzahl
                          GraphCol[0],         // Farbe
                          PS_SOLID);           // Linientyp

        GraphFltLine(hGraph,(float far *)afOldTemp, // Feld mit X-Werten
                          (float far *)afTiefe, // Feld mit Y-Werten
                          (int) pSo->iLayers-1 ,           // Anzahl
                          WHITE_CURVE,         // Farbe
                          PS_SOLID);           // Linientyp

 
        GraphFltLine(hGraph,(float far *)afResTemp, // Feld mit X-Werten
                          (float far *)afTiefe, // Feld mit Y-Werten
                          (int) pSo->iLayers-1 ,           // Anzahl
                          GraphCol[1],         // Farbe
                          PS_SOLID);           // Linientyp

 
      break;

      case  PLOTSOILTEMP:

          GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
               (LPSTR)G_SOILTEMPDT_SS_TXT,
               (LPSTR)G_SOILTEMPDT_XA_TXT,
               (LPSTR)G_SOILTEMPDT_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
              GrXmin[PLOTSOILTEMP],GrXmax[PLOTSOILTEMP],GrXdiv[PLOTSOILTEMP],GrXdec[PLOTSOILTEMP],
              GrYmin[PLOTSOILTEMP],GrYmax[PLOTSOILTEMP],GrYdiv[PLOTSOILTEMP],GrYdec[PLOTSOILTEMP]);


          //colour = 0;
          GraphFltLine(hGraph,(float far *)afTime,    // Feld mit X-Werten
                          (float far *)afTime0Temp, // Feld mit Y-Werten
                          (int)dTimeCount ,           // Anzahl
                          GraphCol[0],         // Farbe
                          PS_SOLID);           // Linientyp
          GraphFltLine(hGraph,(float far *)afTime,    // Feld mit X-Werten
                          (float far *)afTime1Temp, // Feld mit Y-Werten
                          (int)dTimeCount ,           // Anzahl
                          GraphCol[1],         // Farbe
                          PS_SOLID);           // Linientyp
          GraphFltLine(hGraph,(float far *)afTime,    // Feld mit X-Werten
                          (float far *)afTime2Temp, // Feld mit Y-Werten
                          (int)dTimeCount ,           // Anzahl
                          GraphCol[2],         // Farbe
                          PS_SOLID);           // Linientyp

          GraphFltLine(hGraph,(float far *)afTime,    // Feld mit X-Werten
                          (float far *)afTime3Temp, // Feld mit Y-Werten
                          (int)dTimeCount ,           // Anzahl
                          GraphCol[3],         // Farbe
                          PS_SOLID);           // Linientyp



      break;
      case  PLOTLOGHYD:

             GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
                          (LPSTR)G_PFTHETA_SS_TXT,
                          (LPSTR)G_PFTHETA_XA_TXT,
                          (LPSTR)G_PFTHETA_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
                         GrXmin[PLOTLOGHYD],GrXmax[PLOTLOGHYD],GrXdiv[PLOTLOGHYD],GrXdec[PLOTLOGHYD],
                         GrYmin[PLOTLOGHYD],GrYmax[PLOTLOGHYD],GrYdiv[PLOTLOGHYD],GrYdec[PLOTLOGHYD]);


               // Hutson and Cass
              GraphFltLine(hGraph,(float far *)fa1LogHyd, // Feld mit X-Werten
                          (float far *)afThetaTest, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[0],         // colour                    red
                          PS_SOLID);           // Linientyp

             // LeachN
             GraphFltLine(hGraph,(float far *)fa2LogHyd, // Feld mit X-Werten
                          (float far *)afThetaTest, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[1],         // colour                    green
                          PS_SOLID);           // Linientyp
             // Brooks and Corey
             GraphFltLine(hGraph,(float far *)fa3LogHyd, // Feld mit X-Werten
                          (float far *)afThetaTest, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[2],         // colour                    blue
                          PS_SOLID);           // Linientyp

             // Clapp and Hornberger
             GraphFltLine(hGraph,(float far *)fa4LogHyd, // Feld mit X-Werten
                          (float far *)afThetaTest, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[3],         // colour                    yellow
                          PS_SOLID);           // Linientyp

             // modified Hutson
             GraphFltLine(hGraph,(float far *)fa5LogHyd, // Feld mit X-Werten
                          (float far *)afThetaTest, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[4],         // colour                    lightblue
                          PS_SOLID);           // Linientyp

             // van Genuchten
             GraphFltLine(hGraph,(float far *)fa6LogHyd, // Feld mit X-Werten
                          (float far *)afThetaTest, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[5],         // colour                    violet
                          PS_SOLID);           // Linientyp

          break;

      case  PLOTLOGHYDLEIT:
            GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
               (LPSTR)G_THETAKREL_SS_TXT,
               (LPSTR)G_THETAKREL_XA_TXT,
               (LPSTR)G_THETAKREL_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
               GrXmin[PLOTLOGHYDLEIT],GrXmax[PLOTLOGHYDLEIT],GrXdiv[PLOTLOGHYDLEIT],GrXdec[PLOTLOGHYDLEIT],
               GrYmin[PLOTLOGHYDLEIT],GrYmax[PLOTLOGHYDLEIT],GrYdiv[PLOTLOGHYDLEIT],GrYdec[PLOTLOGHYDLEIT]);


           // Hutson and Cass
            GraphFltLine(hGraph,(float far *)afThetaTest , // Feld mit X-Werten
                          (float far *)fa1LogHydLeit, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[0],         // colour                    red
                          PS_SOLID);           // Linientyp

      
           // LeachN
            GraphFltLine(hGraph,(float far *)afThetaTest, // Feld mit X-Werten
                          (float far *)fa2LogHydLeit, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[1],         // colour                    green
                          PS_SOLID);           // Linientyp

           // Brooks and Corey
            GraphFltLine(hGraph,(float far *)afThetaTest, // Feld mit X-Werten
                          (float far *)fa3LogHydLeit, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[2],         // colour                    blue
                          PS_SOLID);           // Linientyp

           // Clapp and Hornberger
           GraphFltLine(hGraph,(float far *)afThetaTest, // Feld mit X-Werten
                          (float far *)fa4LogHydLeit, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[3],         // colour                    yellow
                          PS_SOLID);           // Linientyp

           // modified Hutson
           GraphFltLine(hGraph,(float far *)afThetaTest, // Feld mit X-Werten
                          (float far *)fa5LogHydLeit, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[4],         // colour                    lightblue
                          PS_SOLID);           // Linientyp

           // van Genuchten
           GraphFltLine(hGraph,(float far *)afThetaTest, // Feld mit X-Werten
                          (float far *)fa6LogHydLeit, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[5],         // colour                    violet
                          PS_SOLID);           // Linientyp
      
           break;

      case  PLOTLOGHYDLEITPOT:

            GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
               (LPSTR)G_PFKREL_SS_TXT,
               (LPSTR)G_PFKREL_XA_TXT,
               (LPSTR)G_PFKREL_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
               GrXmin[PLOTLOGHYDLEITPOT],GrXmax[PLOTLOGHYDLEITPOT],
               GrXdiv[PLOTLOGHYDLEITPOT],GrXdec[PLOTLOGHYDLEITPOT],
               GrYmin[PLOTLOGHYDLEITPOT],GrYmax[PLOTLOGHYDLEITPOT],
               GrYdiv[PLOTLOGHYDLEITPOT],GrYdec[PLOTLOGHYDLEITPOT]);

            // Hutson and Cass
             GraphFltLine(hGraph,(float far *)fa1LogHyd, // Feld mit X-Werten
                            (float far *)fa1LogHydLeit, // Feld mit Y-Werten
                            (int) 100,           // Anzahl
                            GraphCol[0],         // Farbe                       rot
                            PS_SOLID);           // Linientyp
      
          // LeachN   Hutson and Wagenet
             GraphFltLine(hGraph,(float far *)fa2LogHyd, // Feld mit X-Werten
                          (float far *)fa2LogHydLeit, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[1],         // Farbe                          gr�n
                          PS_SOLID);           // Linientyp


          //  Brooks and Corey
            GraphFltLine(hGraph,(float far *)fa3LogHyd, // Feld mit X-Werten
                            (float far *)fa3LogHydLeit, // Feld mit Y-Werten
                            (int) 100,           // Anzahl
                            GraphCol[2],         // Farbe                         blau
                            PS_SOLID);           // Linientyp

          //  Clapp and Hornberger
            GraphFltLine(hGraph,(float far *)fa4LogHyd, // Feld mit X-Werten
                          (float far *)fa4LogHydLeit, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[3],         // Farbe                          gelb
                          PS_SOLID);           // Linientyp

           // modified Hutson
            GraphFltLine(hGraph,(float far *)fa5LogHyd, // Feld mit X-Werten
                          (float far *)fa5LogHydLeit, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[4],         // Farbe                          hellblau
                          PS_SOLID);           // Linientyp

           // van Genuchten
             GraphFltLine(hGraph,(float far *)fa6LogHyd, // Feld mit X-Werten
                          (float far *)fa6LogHydLeit, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[5],         // Farbe                          violett
                          PS_SOLID);           // Linientyp
        
      
          break;


      case  PLOTDWC:

       GraphOpen(lphGraph,(LPRECT)&Rect,TRUE,
               (LPSTR)G_DWC_SS_TXT,
               (LPSTR)G_DWC_XA_TXT,
               (LPSTR)G_DWC_YA_TXT,PC_BLACK,PC_BLUE,PC_BLACK,
               GrXmin[PLOTDWC],GrXmax[PLOTDWC],GrXdiv[PLOTDWC],GrXdec[PLOTDWC],
               GrYmin[PLOTDWC],GrYmax[PLOTDWC],GrYdiv[PLOTDWC],GrYdec[PLOTDWC]);


       
      // Hutson and Cass
      GraphDblLine(hGraph,(double far *)fa1DWC, // Feld mit X-Werten
                            (double far *)afdblThetaTest, // Feld mit Y-Werten
                            (int) 100,           // Anzahl
                            GraphCol[0],         // Farbe                       rot
                            PS_SOLID);           // Linientyp

    

// LeachN   Hutson and Wagenet
      GraphDblLine(hGraph,(double far *)fa2DWC, // Feld mit X-Werten
                          (double far *)afdblThetaTest, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[1],         // Farbe                          gr�n
                          PS_SOLID);           // Linientyp


//  Brooks and Corey
      GraphDblLine(hGraph,(double far *)fa3DWC, // Feld mit X-Werten
                            (double far *)afdblThetaTest, // Feld mit Y-Werten
                            (int) 100,           // Anzahl
                            GraphCol[2],         // Farbe                         blau
                            PS_SOLID);           // Linientyp

//  Clapp and Hornberger
      GraphDblLine(hGraph,(double far *)fa4DWC, // Feld mit X-Werten
                          (double far *)afdblThetaTest, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[3],         // Farbe                          gelb
                          PS_SOLID);           // Linientyp

    // modified Hutson
      GraphDblLine(hGraph,(double far *)fa5DWC, // Feld mit X-Werten
                          (double far *)afdblThetaTest, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[4],         // Farbe                          hellblau
                          PS_SOLID);           // Linientyp

        // van Genuchten
           GraphDblLine(hGraph,(double far *)fa6DWC, // Feld mit X-Werten
                          (double far *)afdblThetaTest, // Feld mit Y-Werten
                          (int) 100,           // Anzahl
                          GraphCol[5],         // Farbe                          violett
                          PS_SOLID);           // Linientyp

        break;

 
      default:
          MessageBox(NULL, "Error Graphic-ID(DrawAll)", "XPLOT.C", MB_ICONEXCLAMATION);
      break;
 }
}
