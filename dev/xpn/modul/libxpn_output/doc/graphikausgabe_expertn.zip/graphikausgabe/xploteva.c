/*******************************************************************************
 *
 * Copyright  (c) by 
 *
 * Author:  C. Sperr
 *
 *------------------------------------------------------------------------------
 *
 * Description:
 *
 *   Det results from simulation - data - structures.
 *
 *------------------------------------------------------------------------------
 *
 * $Revision: 7 $
 *
 * $History: xploteva.c $
 * 
 * *****************  Version 7  *****************
 * User: Christian Bauer Date: 10.06.04   Time: 11:46
 * Updated in $/Projekte/ExpertN/ExpertN/System
 * Output of simulation object in info window
 * 
 * *****************  Version 6  *****************
 * User: Christian Bauer Date: 29.02.04   Time: 12:03
 * Updated in $/Projekte/ExpertN/ExpertN/System
 * 
 * *****************  Version 5  *****************
 * User: Christian Bauer Date: 29.12.01   Time: 11:57
 * Updated in $/Projekte/ExpertN.3.0/ExpertN/System
 * Zur Stabilisierung des Codes Methoden Prototypen Definition in Header
 * Files verschoben statt �ber extern Declarationen festgelegt.
 * 
 * *****************  Version 3  *****************
 * User: Christian Bauer Date: 14.12.01   Time: 18:23
 * Updated in $/Projekte/ExpertN/ExpertN/System
 * Removed define for EPSILON (already defined in one of the several
 * define header files).
 *
 *   21.11.95
 * 
*******************************************************************************/

#include <math.h>
#include "expert.h"
#include "graphs.h"
#include "xdefines.h"
#include "language.h"
#include "xmemory.h"


/* time1.c */
extern int EndDay(PTIME);
extern int NextDate(long);

/* xmeasure.c */ 
extern int XGetNoOfNitroMeasureLayers(void);
extern int XGetNoOfH2OMeasureLayers(void);
extern int XGetDailyNitroMeasData(void);          
extern int XGetDailyH2OMeasData(void);

/* util_fct.c */
extern int DateToString(long lDate,LPSTR lpDate);


/*  internal functions */
int EndDay(PTIME pz);
int XSetPlotResults(void);
 
extern float  far * fa1Hyd;
extern float  far * fa2Hyd;
extern float  far * fa3Hyd;
extern float  far * fa4Hyd;
extern float  far * fa5Hyd;
extern float  far * fa6Hyd;
extern float  far * fa1LogHyd;
extern float  far * fa2LogHyd;
extern float  far * fa3LogHyd;
extern float  far * fa4LogHyd;
extern float  far * fa5LogHyd;
extern float  far * fa6LogHyd;

extern float  far * afThetaTest;
extern double far  * afdblThetaTest;

extern float  far * fa1HydLeit;
extern float  far * fa2HydLeit;
extern float  far * fa3HydLeit;
extern float  far * fa4HydLeit;
extern float  far * fa5HydLeit;
extern float  far * fa6HydLeit;
extern float  far * fa1LogHydLeit;
extern float  far * fa2LogHydLeit;
extern float  far * fa3LogHydLeit;
extern float  far * fa4LogHydLeit;
extern float  far * fa5LogHydLeit;
extern float  far * fa6LogHydLeit;

extern double far  * fa1DWC;
extern double far  * fa2DWC;
extern double far  * fa3DWC;
extern double far  * fa4DWC;
extern double far  * fa5DWC;
extern double far  * fa6DWC;


// graphic - plot parameter: plot.c

extern float  far  * afDummyDZ1;
extern float  far  * afDummyDZ2;


extern  float  far  * afDummy11DT;
extern  float  far  * afDummy12DT;
extern  float  far  * afDummy13DT;
extern  float  far  * afDummy14DT;
extern  float  far  * afDummy15DT;
extern  float  far  * afDummy16DT;

extern  float  far  * afDummy21DT;
extern  float  far  * afDummy22DT;
extern  float  far  * afDummy23DT;
extern  float  far  * afDummy24DT;
extern  float  far  * afDummy25DT;
extern  float  far  * afDummy26DT;

extern float far *   afNitroDZ;    //MaxS 
extern float far *   afOldNitroDZ;    //MaxS
extern float far *   afOld1NitroDZ;    //MaxS
extern float far *   afOld2NitroDZ;    //MaxS
extern float far *   afOld3NitroDZ;    //MaxS

extern float far *   afANitroDZ;   // MaxS


extern float far *   afNitro1DT;
extern float far *   afNitro2DT;
extern float far *   afNitro3DT;
extern float far *   afNitro4DT;
extern float far *   afNitro5DT;
extern float far *   afNitro6DT;
extern float far *   afNitro7DT;
extern float far *   afNitro8DT;
extern float far *   afNitro9DT;
extern float far *   afNitro10DT;
extern float far *   afNitro11DT;
extern float far *   afNitro12DT;
extern float far *   afNitro13DT;
extern float far *   afNitro14DT;
extern float far *   afNitro15DT;
extern float far *   afNitro16DT;


extern  float far * afDevStage; 
extern  float far * afLai;
extern  float far * afTillers; 
extern  float far * afLeafWeight; 
extern  float far * afGrainWeight; 
extern  float far * afStemWeight; 
extern  float far * afObVegWeight; 
extern  float far * afRootWeight; 
extern  float far * afRootLengthDensity; 
extern  float far * afNullRootLengthDensity; 
extern  float far * afActNUptake; 
extern  float far * afCritNConc; 
extern  float far * afNConc; 

extern  float far * afActTr; 
extern  float far * afCumActTr; 

extern float   far  * afTiefe;
extern float   far  * afTheta;
extern float   far  * afTemp;
extern float   far  * afOldTemp;
extern float   far  * afOld1Temp;
extern float   far  * afOld2Temp;
extern float   far  * afOld3Temp;
extern float   far  * afOldTheta;
extern float   far  * afOld1Theta;
extern float   far  * afOld2Theta;
extern float   far  * afOld3Theta;
extern float   far  * afResTemp;
extern float   far  * afResTheta;

extern float   far  * afTimeAktEv;
extern float   far  * afkumPotEv;
extern float   far  * afkumAktEv;
extern float   far  * afSickerW;
extern float   far  * afRunoff;
extern float   far  * afKumSickerW;
extern float   far  * afKumRunoff;
extern float   far  * afKumDrainW;
extern float   far  * afNiederSchl;
extern float   far  * afkumRegen;

extern float   far  * afTime0Temp;
extern float   far  * afTime1Temp;
extern float   far  * afTime2Temp;
extern float   far  * afTime3Temp;

extern float   far  * afTime0Theta;
extern float   far  * afTime1Theta;
extern float   far  * afTime2Theta;
extern float   far  * afTime3Theta;
extern float   far  * afTime;

/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>  ch, 22.5.97 */

extern float   far * afH2OET1;
extern float   far * afH2OET2;
extern float   far * afH2OET3;
extern float   far * afH2OET4;
extern float   far * afH2OET5;
extern float   far * afH2OET6;

extern float   far * afH2OBal1;
extern float   far * afH2OBal2;
extern float   far * afH2OBal3;
extern float   far * afH2OBal4;

extern float   far * afH2OPot1;
extern float   far * afH2OPot2;
extern float   far * afH2OPot3;
extern float   far * afH2OPot4;

extern float   far * afH2OFlux1;
extern float   far * afH2OFlux2;
extern float   far * afH2OFlux3;
extern float   far * afH2OFlux4;

extern float   far * afH2OCond1;
extern float   far * afH2OCond2;
extern float   far * afH2OCond3;
extern float   far * afH2OCond4;

extern float   far * afCumActNUpt;

extern float   far * afNitroBal1;
extern float   far * afNitroBal2;
extern float   far * afNitroBal3;
extern float   far * afNitroBal4;
extern float   far * afNitroBal5;
extern float   far * afNitroBal6;

extern float   far * afNitroGas1;
extern float   far * afNitroGas2;
extern float   far * afNitroGas3;
extern float   far * afNitroGas4;
extern float   far * afNitroGas5;

extern float   far * afNitroCumGas1;
extern float   far * afNitroCumGas2;
extern float   far * afNitroCumGas3;
extern float   far * afNitroCumGas4;
extern float   far * afNitroCumGas5;

extern float   far * afNitroPools1;
extern float   far * afNitroPools2;
extern float   far * afNitroPools3;
extern float   far * afNitroPools4;
extern float   far * afNitroPools5;
extern float   far * afNitroPools6;

extern float   far * afNitroCN1;
extern float   far * afNitroCN2;
extern float   far * afNitroCN3;

extern float   far * afNitroMiner1;
extern float   far * afNitroMiner2;
extern float   far * afNitroMiner3;
extern float   far * afNitroMiner4;
extern float   far * afNitroMiner5;
extern float   far * afNitroMiner6;

extern float   far * afTempIce1;
extern float   far * afTempIce2;
extern float   far * afTempIce3;
extern float   far * afTempIce4;

extern float far *   afPlant1;
extern float far *   afPlant2;
extern float far *   afPlant3;
extern float far *   afPlant4;
extern float far *   afPlant5;
extern float far *   afPlant6;
extern float far *   afPlant7;
extern float far *   afPlant8;
extern float far *   afPlant9;
extern float far *   afPlant10;
extern float far *   afPlant11;
extern float far *   afPlant12;


extern float   fTimeEnd;   
extern unsigned short   dTimeCount;


extern HWND       hCtrlDlg;


float   XFileNFreiFOS   = (float)0.0;
float   XFileNFreiHumus = (float)0.0;

float   fXTimeAktEvDt = (float)0.0;
float   fXSickerWDt   = (float)0.0;
float   fXRunOffDt    = (float)0.0;
float   fXDrainWDt    = (float)0.0;


 
int EndDay(PTIME pz)
{
 /*
  return ( (int)(pz->pSimTime->fTimeAct + pz->pTimeStep->fAct + EPSILON) !=
          (int)(pz->pSimTime->fTimeAct + EPSILON) ) ?
        1 : 0;
  */
  return (pz->pSimTime->fTimeDay + pz->pTimeStep->fAct + EPSILON) >= (float)1?
        1 : 0;
}

/*************************************************************************************
 *  int SetPlotResults(void)
 *
 *  >>>> get results from simulation - data - structures
 *  
 *  
 *  Author  :  C. Sperr     /  21.11.95
 **************************************************************************************
 */                     
int XSetPlotResults(void)
{ 
 int iRet=0;                 
 int idummy,iDay=0;
 long ldummy;
 char outBuff[30];

 //////////////////////////////////////
 PHEAT		pHe=NULL;
 PSPROFILE  pSo=NULL;
 PCLIMATE	pCl=NULL;
 PWATER		pWa=NULL;
 PPLANT		pPl=NULL;
 PGRAPHIC	pGr=NULL;
 PCHEMISTRY	pCh=NULL;
 PTIME		pTi=NULL;
 PSLAYER 	pSL =NULL;
 PCLAYER	pCL =NULL;
 PHLAYER	pHL =NULL;
 PWLAYER	pWL =NULL;
 PLAYERROOT	pLR =NULL;
 PWEATHER	pWE =NULL;
 
 //////////////////////////////////////
 pHe=GetHeatPoi();
 pSo=GetSoilPoi();
 pCl=GetClimatePoi();
 pWa=GetWaterPoi();
 pPl=GetPlantPoi();
 pGr=GetGraphicPoi();
 pCh=GetChemistryPoi();
 pTi=GetTimePoi();
 ////////////////////////////////////// 
/***************************************************************************************
 *=============== P e r       T i m e s t e p     ======================================
 */
   /************************************************
    *  Dll - Array ( DZ  1 / 2)
    */
    for(idummy=0;idummy<pSo->iLayers;idummy++)
    {
        afDummyDZ1[idummy]    = pGr->fPlotDZ1[idummy];
        afDummyDZ2[idummy]    = pGr->fPlotDZ2[idummy];

     } // for idummy
/*
 *=============== P e r       T i m e s t e p     ======================================
 **************************************************************************************
 */
/***************************************************************************************
 *************           D A I L Y                   *********************
 */
if (EndDay(pTi))
{ 
  /*
   *  !! insert  externals in paramter list
   */

 /*****************************************************************************
  *    show date in info dialog
  *  06.04.94 >> comment
  *  
  *  date or time : sprintf(outBuff,"%5.2f",(pTi->pSimTime->fTimeAct));
  *
  */ 
   
  /* ch 22.5.97 benutze besser Variable lTimeDate fuer Datumsausgabe! */
   
   ldummy=pTi->pSimTime->lTimeDate;
   pTi->pSimTime->lTimeDate=NextDate(pTi->pSimTime->lTimeDate);
   DateToString(pTi->pSimTime->lTimeDate,(LPSTR)outBuff);
   pTi->pSimTime->lTimeDate=ldummy;

   SetDlgItemText(hCtrlDlg,ID_CTRL_DLG2A,(LPSTR)outBuff);

/******************************************************************************* 
 *******************************************************************************
 *     Depth Dependent ------------>>>>>>>-------------->
 */
     for(idummy=1,
         pWL   = pWa->pWLayer->pNext,        
         pHL   = pHe->pHLayer->pNext,
         pCL	= pCh->pCLayer->pNext;
                                    (   (pWL!=NULL)
                                     && (pHL!=NULL)
                                     && (pCL!=NULL)
                                     &&(idummy<=pSo->iLayers));
         pWL   =pWL->pNext,
         pHL   =pHL->pNext,
         pCL   =pCL->pNext,
         idummy++)
     {             
 
      /************************************************
       *   water --------------------->
       */
        afOldTheta[idummy]    = afOld1Theta[idummy];
        afOld1Theta[idummy]   = afOld2Theta[idummy];
        afOld2Theta[idummy]   = afOld3Theta[idummy];
        afOld3Theta[idummy]   = afResTheta[idummy];

         afResTheta[idummy]   = pWL->fContAct*(float)100.0;

      /************************************************
       *   Temperature  --------------------->
       */
        afOldTemp[idummy]     = afOld1Temp[idummy];
        afOld1Temp[idummy]    = afOld2Temp[idummy];
        afOld2Temp[idummy]    = afOld3Temp[idummy];
        afOld3Temp[idummy]    = afResTemp[idummy];
     
        afResTemp[idummy]    = pHL->fSoilTempAve;

	  /*************************************************************************
       *   3. NO3 distribution in soil
       */

        afOldNitroDZ[idummy]     = afOld1NitroDZ[idummy]; 
        afOld1NitroDZ[idummy]    = afOld2NitroDZ[idummy];
        afOld2NitroDZ[idummy]    = afOld3NitroDZ[idummy] ;
        afOld3NitroDZ[idummy]    = afNitroDZ[idummy];
        afNitroDZ[idummy]        = pCL->fNO3N;

     } 


     /* plant must be seperately considered because if no plant exists pPl =NULL*/
     if (pPl != NULL){
	     for(idummy=1,
	         pLR   = pPl->pRoot->pLayerRoot->pNext;
	                                    ((pLR!=NULL)&&(idummy<=pSo->iLayers));
	         pLR   =pLR->pNext,idummy++)
	     {             
	      /* ------- Plant ------   */                             
	        afNullRootLengthDensity[idummy]= afRootLengthDensity[idummy]; 
	        afRootLengthDensity[idummy]  = pLR->fLengthDens; 
	
	     }  
     }

 /************----<<<<<---------------------------------
  * for idummy
  */
//------------ boundary layer settings ----------------------------------------
    //----- 
      afResTheta[0]   = afResTheta[1];                                        
      afResTheta[pSo->iLayers-1]   = afResTheta[pSo->iLayers-2]; 
     
      afResTemp[0]    = afResTemp[1];                                        
      afResTemp[pSo->iLayers-1]    = afResTemp[pSo->iLayers-2];
     
      afOldTheta[0]   = afOldTheta[1];                                        
      afOldTheta[pSo->iLayers-1]   = afOldTheta[pSo->iLayers-2]; 
      afOld1Theta[0]   = afOld1Theta[1];                                        
      afOld1Theta[pSo->iLayers-1]   = afOld1Theta[pSo->iLayers-2]; 
      afOld2Theta[0]   = afOld2Theta[1];                                        
      afOld2Theta[pSo->iLayers-1]   = afOld2Theta[pSo->iLayers-2]; 
      afOld3Theta[0]   = afOld3Theta[1];                                        
      afOld3Theta[pSo->iLayers-1]   = afOld3Theta[pSo->iLayers-2]; 
     
      afOldTemp[0]    = afOldTemp[1];                                        
      afOldTemp[pSo->iLayers-1]    = afOldTemp[pSo->iLayers-2];
      afOld1Temp[0]    = afOld1Temp[1];                                        
      afOld1Temp[pSo->iLayers-1]    = afOld1Temp[pSo->iLayers-2];
      afOld2Temp[0]    = afOld2Temp[1];                                        
      afOld2Temp[pSo->iLayers-1]    = afOld2Temp[pSo->iLayers-2];
      afOld3Temp[0]    = afOld3Temp[1];                                        
      afOld3Temp[pSo->iLayers-1]    = afOld3Temp[pSo->iLayers-2];

    //----- 
      afDummyDZ1[0]       = afDummyDZ1[1];
      afDummyDZ2[0]       = afDummyDZ1[1];
    //----     
      afNitroDZ[0]        = afNitroDZ[1]; 
      afNitroDZ[pSo->iLayers-1]       = afNitroDZ[pSo->iLayers-2];
      afOldNitroDZ[0]     = afOldNitroDZ[1];
      afOldNitroDZ[pSo->iLayers-1]    = afOldNitroDZ[pSo->iLayers-2];
      afOld1NitroDZ[0]     = afOld1NitroDZ[1];
      afOld1NitroDZ[pSo->iLayers-1]    = afOld1NitroDZ[pSo->iLayers-2];
      afOld2NitroDZ[0]     = afOld2NitroDZ[1];
      afOld2NitroDZ[pSo->iLayers-1]    = afOld2NitroDZ[pSo->iLayers-2];
      afOld3NitroDZ[0]     = afOld3NitroDZ[1];
      afOld3NitroDZ[pSo->iLayers-1]    = afOld3NitroDZ[pSo->iLayers-2];
     //----
      afNullRootLengthDensity[0] = afNullRootLengthDensity[1];
      afNullRootLengthDensity[pSo->iLayers-1]=afNullRootLengthDensity[pSo->iLayers-2];

      afRootLengthDensity[0] = afRootLengthDensity[1];
      afRootLengthDensity[pSo->iLayers-1]=afRootLengthDensity[pSo->iLayers-2];
//------------ boundary layer settings ----------------------------------------
/*      
 * depth dependend protocol
 ******************************************************************/


/*****************************************************************************
 ****************************************************************************
 *     time dependend -------------------------->
 */                      
 
/****************************************************************************
 ****************************************************************************
 *				WATER
 */                      

     XGetDailyH2OMeasData();                                                

	  /*************************************************************************************
       *   1. Climate 
       */
         afNiederSchl[dTimeCount] =  pCl->pWeather->fRainAmount;
		 // afTime0Temp[dTimeCount] =  pCl->pWeather->fTempAve;
      
	  /*************************************************************************************
       *   2. Run Off
       */
	   afSickerW[dTimeCount] =  pWa->fInfiltDay;
	   afRunoff[dTimeCount] =  pWa->fRunOffDay;

	   /***************************************************************************************                             
       *   3. Cumulative Water Flows
       */
          afkumRegen[dTimeCount+1]   = pCl->fCumRain;  
          afkumAktEv[dTimeCount+1]   = pWa->pWBalance->fActCumEvap;
          afCumActTr[dTimeCount+1]   = pWa->fActTranspCum;
          afKumRunoff[dTimeCount+1]  = pWa->fRunOffCum;                       
          afKumSickerW[dTimeCount+1] = pWa->fCumInfiltration; 
          afKumDrainW[dTimeCount+1]  = pWa->fCumLeaching;

	  /**********************************************************************************                             
       *   4. Evapotranspiration 
       */
		afH2OET1[dTimeCount]  = pWa->fPotETCum;
   		afH2OET2[dTimeCount]  = pWa->pWBalance->fPotCumEvap;
		
       if (pPl!=NULL)
			{
		     afH2OET3[dTimeCount]  = pPl->pPltWater->fCumDemand;
			}

    	afH2OET4[dTimeCount]  = pWa->fActETCum;
		afH2OET5[dTimeCount]  = pWa->pWBalance->fActCumEvap;
   		afH2OET6[dTimeCount]  = pWa->fActTranspCum;

	  /*************************************************************************
       *   6. Temporal Changes
       */                                                                        
       afTime0Theta[dTimeCount] = (float)0.0;
       afTime1Theta[dTimeCount] = (float)0.0;
       afTime2Theta[dTimeCount] = (float)0.0;
       afTime3Theta[dTimeCount] = (float)0.0;

	   
	   /*  water content in the first 25% of the  profile
        */
      
       for(idummy = 0,pWL = pWa->pWLayer->pNext;
             ((pWL->pNext!=NULL)&&(idummy < (pSo->iLayers/4)));
              pWL=pWL->pNext,idummy++)
              afTime0Theta[dTimeCount] += pWL->fContAct*(float)100.0;

       afTime0Theta[dTimeCount] /= (idummy);                          
                                 
       /*  water content in the second 25% of the  profile
        */
       for(idummy = 0;((pWL->pNext!=NULL)&&(idummy < (pSo->iLayers/4)));
                                                                     pWL=pWL->pNext,idummy++)
              afTime1Theta[dTimeCount] += pWL->fContAct*(float)100.0;
                                                                                     
       afTime1Theta[dTimeCount] /= (idummy);                                                                                     
   
       /*  water content in the third 25% of the  profile
        */
      for(idummy = 0;  ((pWL->pNext!=NULL)&&(idummy < (pSo->iLayers/4)));
                                                            pWL=pWL->pNext,idummy++)
                afTime2Theta[dTimeCount] += pWL->fContAct*(float)100.0;
                                                                                     
       afTime2Theta[dTimeCount] /= (idummy);
       
       /*  water content in the last 25% of the  profile
        */
        for(idummy = 0;(pWL->pNext!=NULL); pWL=pWL->pNext,idummy++)
                afTime3Theta[dTimeCount] += pWL->fContAct*(float)100.0;
        
        afTime3Theta[dTimeCount] /= (idummy);

	  /*************************************************************************
       *   7. Analysis H2O
       */                                                                        


	  /*************************************************************************
       *   8. Soil Water Balance
       */                                                                        
		afH2OBal1[dTimeCount]  = pWa->pWBalance->fBalance;
		afH2OBal2[dTimeCount]  = pWa->pWBalance->fProfil + pWa->pWBalance->fProfileIce;
		afH2OBal3[dTimeCount]  = pWa->pWBalance->fInput;
	 // afH2OET5[dTimeCount]  = pWa->pWBalance->fActCumEvap;
		afH2OBal4[dTimeCount]  = pWa->fActTranspCum;
   //   afKumDrainW[dTimeCount]  = pWa->pWBalance->fCumLeaching;


	  /*************************************************************************
       *   9.  Matrix Potential
       *   10. Water Flux Density
       *   11. Hydraulic Conductivity
       */                                                                        

		pWL = pWa->pWLayer->pNext; /* 1. layer */

		afH2OPot1[dTimeCount]  = pWL->fMatPotAct/(float)kPaTOmm;
		afH2OCond1[dTimeCount]  = pWL->fHydrCond;
		afH2OFlux1[dTimeCount]  = pWL->fFluxDay;

	for(idummy = 1,pSL = pSo->pSLayer->pNext, pWL = pWa->pWLayer->pNext;
		((pSL->pNext!=NULL)&&(pWL->pNext!=NULL)&&(pSL->fThickness*idummy < 300 - (float)0.001));
        pSL=pSL->pNext,pWL=pWL->pNext,idummy++);

		if (pWL->pNext!=NULL)
		{
		afH2OPot2[dTimeCount]  = pWL->fMatPotAct/(float)kPaTOmm;
		afH2OCond2[dTimeCount]  = pWL->fHydrCond;
		afH2OFlux2[dTimeCount]  = pWL->fFluxDay;

		for(idummy = 1,pSL = pSo->pSLayer->pNext, pWL = pWa->pWLayer->pNext;
			((pSL->pNext!=NULL)&&(pWL->pNext!=NULL)&&(pSL->fThickness*idummy < 600 - (float)0.001));
			pSL=pSL->pNext,pWL=pWL->pNext,idummy++);

			if (pWL->pNext!=NULL)
			{
			afH2OPot3[dTimeCount]  = pWL->fMatPotAct/(float)kPaTOmm;
			afH2OCond3[dTimeCount]  = pWL->fHydrCond;
			afH2OFlux3[dTimeCount]  = pWL->fFluxDay;

			for(idummy = 1,pSL = pSo->pSLayer->pNext, pWL = pWa->pWLayer->pNext;
				((pSL->pNext!=NULL)&&(pWL->pNext!=NULL)&&(pSL->fThickness*idummy < 900 - (float)0.001));
				pSL=pSL->pNext,pWL=pWL->pNext,idummy++);

				if (pWL->pNext!=NULL)
				{
				afH2OPot4[dTimeCount]  = pWL->fMatPotAct/(float)kPaTOmm;
				afH2OCond4[dTimeCount]  = pWL->fHydrCond;
				afH2OFlux4[dTimeCount]  = pWL->fFluxDay;

				}    /* 900mm */
			}       /* 600mm */
		}          /* 300mm */

       
/****************************************************************************
 ****************************************************************************
 *				NITROGEN
 */                      
     XGetDailyNitroMeasData();


	  /*************************************************************************
       *   1. Temporal Changes
       */                                                                        
          
      /**************************** 
       *contents of the whole profile 
       */
          afNitro1DT[dTimeCount]    = pCh->pCBalance->fNO3NProfile;
          afNitro9DT[dTimeCount]    = pCh->pCBalance->fNH4NProfile;
          afNitro10DT[dTimeCount]   = pCh->pCBalance->fUreaNProfile;

	   /**************************** 
       * contents of the lower tho thirds
       */
       for(idummy = 0,pCL=pCh->pCLayer;
             ((pCL->pNext!=NULL)&&(idummy < (pSo->iLayers/3)));
              pCL=pCL->pNext,idummy++);
       for( afNitro2DT[dTimeCount]    = (float)0.0;(pCL->pNext!=NULL); pCL=pCL->pNext)
             {   afNitro2DT[dTimeCount]    += pCL->fNO3N;
             } // for idummy
      /**************************** 
       * contents of the lower third
       */
       for(idummy = 0,pCL=pCh->pCLayer;
             ((pCL->pNext!=NULL)&&(idummy < (2*pSo->iLayers/3)));
               pCL=pCL->pNext,idummy++);
       for(afNitro3DT[dTimeCount]    = (float)0.0;(pCL->pNext!=NULL);pCL=pCL->pNext)
             {  afNitro3DT[dTimeCount]    += pCL->fNO3N;
             } // for idummy
      

	  /*************************************************************************
       *   2. Analysis NO3
       */                                                                        


	  /*************************************************************************
       *   4. N transformations
       */                                                                        
 	     afNitro11DT[dTimeCount]   =  pCh->pCProfile->fUreaHydroDay;
       afNitro12DT[dTimeCount]   =  pCh->pCProfile->fNLitterMinerDay + pCh->pCProfile->fNManureMinerDay;
       afNitro13DT[dTimeCount]   =  pCh->pCProfile->fNHumusMinerDay;
       afNitro14DT[dTimeCount]   =  pCh->pCProfile->fNH4NitrDay;
       afNitro15DT[dTimeCount]   =  pCh->pCProfile->fNO3DenitDay;
       afNitro16DT[dTimeCount]   =  pCh->pCProfile->fNImmobDay;

	  /*************************************************************************
       *   5. Cum. N Flows
       */                                                                        
       afNitro4DT[dTimeCount]    = pCh->pCProfile->fNO3LeachCum;
       afNitro5DT[dTimeCount]     = pCh->pCProfile->fNMinerCum;
       afNitro6DT[dTimeCount]    = pCh->pCProfile->fNO3DenitCum;
       afNitro7DT[dTimeCount]    = pCh->pCProfile->fNH4NitrCum;
       afNitro8DT[dTimeCount]    = pCh->pCProfile->fNImmobCum;
              afActNUptake[dTimeCount]  = pCh->pCProfile->fCumActNUpt;


	  /*************************************************************************
       *   6. N Balance
       */                                                                        
	   afNitroBal1[dTimeCount]    = pCh->pCBalance->fNBalance;
	   afNitroBal2[dTimeCount]    = pCh->pCBalance->fNProfileAct;
	   afNitroBal3[dTimeCount]    = pCh->pCBalance->fNInputCum;
	   afNitroBal4[dTimeCount]    = pCh->pCProfile->fCumActNUpt;
	   afNitroBal5[dTimeCount]    = pCh->pCProfile->fN2OEmisCum + pCh->pCProfile->fNH3VolatCum;
	   afNitroBal6[dTimeCount]    = pCh->pCProfile->fNTotalLeachCum;


	  /*************************************************************************
       *   7. Gaseous Emissions
       */                                                                        
	   afNitroGas1[dTimeCount]    = pCh->pCProfile->fN2OEmisDay*(float)1000.0;
	   afNitroGas2[dTimeCount]    = pCh->pCProfile->fNH3VolatDay*(float)1000.0;
	   afNitroGas3[dTimeCount]    = pCh->pCProfile->fNOEmisDay*(float)1000.0;
	   afNitroGas4[dTimeCount]    = pCh->pCProfile->fCH4ImisDay*(float)1000.0;
	   afNitroGas5[dTimeCount]    = pCh->pCProfile->fCO2EmisDay*(float)1000.0;

	  /*************************************************************************
       *   8. Cum. Gaseous Emissions
       */                                                                        
	   afNitroCumGas1[dTimeCount]    = pCh->pCProfile->fN2OEmisCum;
	   afNitroCumGas2[dTimeCount]    = pCh->pCProfile->fNH3VolatCum;
	   afNitroCumGas3[dTimeCount]    = pCh->pCProfile->fNOEmisCum;
	   afNitroCumGas4[dTimeCount]    = pCh->pCProfile->fCH4ImisCum;
	   afNitroCumGas5[dTimeCount]    = pCh->pCProfile->fCO2EmisCum;

	  /*************************************************************************
       *   9. C- and N-Pools
       */                                                                        
	   afNitroPools1[dTimeCount]  = 
	   afNitroPools2[dTimeCount]  = 
	   afNitroPools3[dTimeCount]  = 
	   afNitroPools4[dTimeCount]  = 
	   afNitroPools5[dTimeCount]  = 
	   afNitroPools6[dTimeCount]  = (float)0;

	   for(idummy = 1,pCL = pCh->pCLayer->pNext;
			((pSL->pNext!=NULL)&&(pCL->pNext!=NULL)&&(pSL->fThickness*idummy <= 300));
			pSL=pSL->pNext,pCL=pCL->pNext,idummy++)
			{

				afNitroPools1[dTimeCount]  += pCL->fCLitter;
				afNitroPools2[dTimeCount]  += pCL->fCManure;
				afNitroPools3[dTimeCount]  += pSL->fCHumus;
				afNitroPools4[dTimeCount]  += pCL->fNLitter;
				afNitroPools5[dTimeCount]  += pCL->fNManure;
				afNitroPools6[dTimeCount]  += pSL->fNHumus;

			}    /* 300mm */

	  /*************************************************************************
       *   10. C/N Ratios
       */                               

		if (afNitroPools4[dTimeCount] > EPSILON)
		{
			afNitroCN1[dTimeCount] = afNitroPools1[dTimeCount] / afNitroPools4[dTimeCount];
		}

		if (afNitroPools5[dTimeCount] > EPSILON)
		{
			afNitroCN2[dTimeCount] = afNitroPools2[dTimeCount] / afNitroPools5[dTimeCount];
		}

		if (afNitroPools6[dTimeCount] > EPSILON)
		{
			afNitroCN3[dTimeCount] = afNitroPools3[dTimeCount] / afNitroPools6[dTimeCount];
		}


		/*************************************************************************
        *   11. Mineralization/Immobilization
        */                                                                        
		afNitroMiner1[dTimeCount] =  pCh->pCProfile->fNHumusImmobDay;
		afNitroMiner2[dTimeCount] =  pCh->pCProfile->fNManureImmobDay;
		afNitroMiner3[dTimeCount] =  pCh->pCProfile->fNLitterImmobDay;
		afNitroMiner4[dTimeCount] =  pCh->pCProfile->fNHumusMinerDay;
		afNitroMiner5[dTimeCount] =  pCh->pCProfile->fNManureMinerDay;
		afNitroMiner6[dTimeCount] =  pCh->pCProfile->fNLitterMinerDay;




/****************************************************************************
 ****************************************************************************
 *				PLANT
 */                      
      /***************************                             
       *    plant, no plant means :  pPlant == NULL
       */ 
       if (pPl!=NULL){

	  /*************************************************************************
       *   1. Development Stage
       */                                                                        
	   afDevStage[dTimeCount]     =  pPl->pDevelop->fDevStage/(float)10;  
	   afPlant1[dTimeCount]    =  pPl->pDevelop->fStageSUCROS;  

	  /*************************************************************************
       *   2. Biomass Distribution
       */                                                                        
	    afGrainWeight[dTimeCount]  =  pPl->pBiomass->fGrainWeight/(float)1000.0; 
	    afLeafWeight[dTimeCount]   =  pPl->pBiomass->fLeafWeight/(float)1000.0; 
	    afStemWeight[dTimeCount]   =  pPl->pBiomass->fStemWeight/(float)1000.0; 
	    afRootWeight[dTimeCount]   =  pPl->pBiomass->fRootWeight/(float)1000.0; 
	    afObVegWeight[dTimeCount]  =  pPl->pBiomass->fStovWeight/(float)1000.0
			                         +pPl->pBiomass->fGrainWeight/(float)1000.0;

	  /*************************************************************************
       *   3. Leaf Area
       */                                                                        
	        afLai[dTimeCount]          =  pPl->pCanopy->fLAI;
	        afPlant2[dTimeCount]       =  pPl->pCanopy->fCropCoverFrac;

	  /*************************************************************************
       *   4. Tiller
       */                                                                        
	        afTillers[dTimeCount]      =  pPl->pCanopy->fTillerNumSq; 


	  /*************************************************************************
       *   6. Root distribution temporal changes
       */                                                                        
	   
	   /*   first 25% of the  profile        */
       for(idummy = 0,pLR = pPl->pRoot->pLayerRoot->pNext;
             ((pLR->pNext!=NULL)&&(idummy < (pSo->iLayers/4)));
              pLR=pLR->pNext,idummy++)
			  {
			  afPlant3[dTimeCount]       =  pLR->fLengthDens;
			  }

	   /*   2nd 25% of the  profile        */
       for(;
             ((pLR->pNext!=NULL)&&(idummy < (pSo->iLayers/2)));
              pLR=pLR->pNext,idummy++)
			  {
			  afPlant4[dTimeCount]       =  pLR->fLengthDens;
			  }                                                               

	   /*   3rd 25% of the  profile        */
       for(;
             ((pLR->pNext!=NULL)&&(idummy < ((pSo->iLayers*3)/4)));
              pLR=pLR->pNext,idummy++)
			  {
			  afPlant5[dTimeCount]       =  pLR->fLengthDens;
			  }

	   /*   4th 25% of the  profile        */
       for(;
             ((pLR->pNext!=NULL)&&(idummy < pSo->iLayers));
              pLR=pLR->pNext,idummy++)
			  {
			  afPlant6[dTimeCount]       =  pLR->fLengthDens;
			  }
                                 
       
	  /*************************************************************************
       *   7. Transpiration
       */                                                                        
			afPlant7[dTimeCount]       =  pPl->pPltWater->fPotTranspDay;
	        afActTr[dTimeCount]        =  pWa->fActTranspDay;

	  /*************************************************************************
       *   8. N uptake
       */                                                                        
	        afActNUptake[dTimeCount]   =  pPl->pPltNitrogen->fCumActNUpt;
			afPlant8[dTimeCount]       =  pPl->pPltWater->fCumUptake;

	  /*************************************************************************
       *   9. N concentration
       */                                                                        

	   //     afCritNConc[dTimeCount]    =  pPl->pPltNitrogen->fTopsCriticConc;  
	        afNConc[dTimeCount]        =  pPl->pPltNitrogen->fTopsActConc * (float)100.;
	        afPlant9[dTimeCount]       =  pPl->pPltNitrogen->fGrainConc  * (float)100.;
//ch !!!  >>>>>>>>>>>>			        afPlant10[dTimeCount]      =  pPl->pPltNitrogen->fLeafNc;
//ch !!!  >>>>>>>>>>>>			        afPlant11[dTimeCount]      =  pPl->pPltNitrogen->fStemNc;
	        afPlant12[dTimeCount]      =  pPl->pPltNitrogen->fRootActConc * (float)100.;
        }

/****************************************************************************
 ****************************************************************************
 *				TEMPERATURE
 */                      

	  /*************************************************************************
       *   1. temporal changes
       */                                                                        
          afTime0Temp[dTimeCount]  = pCl->pWeather->fTempAve;
      
	   /* first third profile 
       */
       for(idummy = 0,pHL=pHe->pHLayer;
             ((pHL->pNext!=NULL)&&(idummy < (pSo->iLayers/3)));
           pHL=pHL->pNext,idummy++);
       afTime1Temp[dTimeCount]  = pHL->fSoilTempAve;  
       
      /* second third profile 
       */
       for(idummy = 0,pHL=pHe->pHLayer;
             ((pHL->pNext!=NULL)&&(idummy < (2*pSo->iLayers/3)));
           pHL=pHL->pNext,idummy++);
       afTime2Temp[dTimeCount]  = pHL->fSoilTempAve;  

      /* lowest profile 
       */
       for(idummy = 0,pHL=pHe->pHLayer;
             ((pHL->pNext->pNext!=NULL)&&(idummy < (2*pSo->iLayers/3)));
           pHL=pHL->pNext,idummy++);
        /* set */
        afTime3Temp[dTimeCount]  = pHL->fSoilTempAve;


	  /*************************************************************************
       *   2. distribution in profile
       */                                                                        

	  /*************************************************************************
       *   3. ice content
       */                                                                        
	   
		afTempIce1[dTimeCount]  = 
		afTempIce2[dTimeCount]  = 
		afTempIce3[dTimeCount]  = 
		afTempIce4[dTimeCount]  = (float)0;

	   for(idummy = 1,pWL = pWa->pWLayer->pNext;
			((pSL->pNext!=NULL)&&(pWL->pNext!=NULL)&&(pSL->fThickness*idummy <= 300));
			pSL=pSL->pNext,pWL=pWL->pNext,idummy++)
			{
				afTempIce1[dTimeCount]  += pWL->fIce;
			}    /* 300mm */

	   for(;
			((pSL->pNext!=NULL)&&(pWL->pNext!=NULL)&&(pSL->fThickness*idummy <= 600));
			pSL=pSL->pNext,pWL=pWL->pNext,idummy++)
			{
				afTempIce2[dTimeCount]  += pWL->fIce;
			}    /* 600mm */

	   for(;
			((pSL->pNext!=NULL)&&(pWL->pNext!=NULL)&&(pSL->fThickness*idummy <= 900));
			pSL=pSL->pNext,pWL=pWL->pNext,idummy++)
			{
				afTempIce3[dTimeCount]  += pWL->fIce;
			}    /* 900mm */

	   for(;
			((pSL->pNext!=NULL)&&(pWL->pNext!=NULL)&&(pSL->fThickness*idummy <= 1200));
			pSL=pSL->pNext,pWL=pWL->pNext,idummy++)
			{
				afTempIce4[dTimeCount]  += pWL->fIce;
			}    /* 1200mm */

/****************************************************************************
 ****************************************************************************
 *				PLANT
 */                      
          afDummy11DT[dTimeCount]    =  pGr->fPlotDT11;
          afDummy12DT[dTimeCount]    =  pGr->fPlotDT12;
          afDummy13DT[dTimeCount]    =  pGr->fPlotDT13;
          afDummy14DT[dTimeCount]    =  pGr->fPlotDT14;
          afDummy15DT[dTimeCount]    =  pGr->fPlotDT15;
          afDummy16DT[dTimeCount]    =  pGr->fPlotDT16;

          afDummy21DT[dTimeCount]    =  pGr->fPlotDT21;
          afDummy22DT[dTimeCount]    =  pGr->fPlotDT22;
          afDummy23DT[dTimeCount]    =  pGr->fPlotDT23;
          afDummy24DT[dTimeCount]    =  pGr->fPlotDT24;
          afDummy25DT[dTimeCount]    =  pGr->fPlotDT25;
          afDummy26DT[dTimeCount]    =  pGr->fPlotDT26;




 /*************************************************************************
  *   >>>>>>>> S w i t c h      N e w    D a y    <<<<<<<<<<<<<<<<<<<<<<<<
  */
          afTime[dTimeCount]       = pTi->pSimTime->fTimeAct;//-(float)1;
          dTimeCount++;
 /* >>>>>>>>>>>>>>>>      N e w    D a y   <<<<<<<<<<<<<<<<<<<<<<<<<<<<<
  *************************************************************************
  */
 }  ///  if  end of day 
 
   return iRet;
}

/*******************************************************************************
** EOF */
