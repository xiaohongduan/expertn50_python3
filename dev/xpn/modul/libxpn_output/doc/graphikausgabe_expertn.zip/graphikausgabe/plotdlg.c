/*******************************************************************************
 *
 * Copyright (c) by 
 *
 * Author:   C. Sperr
 *
 *------------------------------------------------------------------------------
 *
 * Description:  graphic dialogbox callback -functions     EXPERT-N simulation result
 *
 *------------------------------------------------------------------------------
 *
 * $Revision: 9 $
 *
 * $History: plotdlg.c $
 * 
 * *****************  Version 9  *****************
 * User: Christian Bauer Date: 6.06.04    Time: 10:12
 * Updated in $/Projekte/ExpertN/ExpertN/System
 * Todo list from Eckart, received on Friday, 28. Mai 2004.
 * 
 * *****************  Version 8  *****************
 * User: Christian Bauer Date: 29.02.04   Time: 12:03
 * Updated in $/Projekte/ExpertN/ExpertN/System
 * 
 * *****************  Version 7  *****************
 * User: Christian Bauer Date: 23.01.02   Time: 14:11
 * Updated in $/Projekte/ExpertN/ExpertN/System
 * 
 * *****************  Version 6  *****************
 * User: Christian Bauer Date: 30.12.01   Time: 21:35
 * Updated in $/Projekte/ExpertN.3.0/ExpertN/System
 * Ge�nderte ID f�r HYDR Icon (jetzt IDI_GRAPH)
 * 
 * *****************  Version 5  *****************
 * User: Christian Bauer Date: 29.12.01   Time: 11:45
 * Updated in $/Projekte/ExpertN.3.0/ExpertN/System
 * Weiter mit Portierung auf Win32 API (DLGPROC statt FARPROC).
 * Zur Stabilisierung des Codes Methoden Prototypen Definition in Header
 * Files verschoben statt �ber extern Declarationen festgelegt.
 * 
 * *****************  Version 3  *****************
 * User: Christian Bauer Date: 14.12.01   Time: 17:46
 * Updated in $/Projekte/ExpertN/ExpertN/System
 * Name of global constants changed.
 * 
 *   29.08.94
 *
*******************************************************************************/

#include <windows.h>
#include <stdlib.h>
#include <math.h>
#include <memory.h>
#include "graphs.h"
#include "plottype.h"
#include "plotlist.h"
#include "resource.h"
#include "defines.h"
#include "language.h"
#include "expert.h"
#include "plotdlg.h"

extern LPPOINT lpPoint;

#ifndef GCL_HICON
#define GCL_HICON GCW_HICON
#endif

#ifndef GWL_HINSTANCE
#define GWL_HINSTANCE GWW_HINSTANCE
#endif

/*
 * resolution dependant values ! change xplot.dlg - defines also!!!!!
 *   VGA 640 x 480   */
int  LEGEND_X0      =  20;
int  LEGEND_Y0      = 320;
int  LEGEND_LINE_DX =  50;
int  LEGEND_TEXT_X0 =  55;
int  LEGEND_TEXT_Y0 = 315;
int  TXT_DY_1  =15       ;
int  TXT_DY_2  =30       ;
int  TXT_DY_3  =45       ;
int  TXT_DY_4  =60       ;
int  TXT_DY_5  =75       ;
int  TXT_DY_6  =90       ;
int  TXT_DY_7  =115      ;



HICON  hIcon;
int iIconCount= 0;

double GrXmin[MAXPLOTS];
double GrXmax[MAXPLOTS];
double GrXdiv[MAXPLOTS];
int    GrXdec[MAXPLOTS];
double GrYmin[MAXPLOTS];
double GrYmax[MAXPLOTS];
double GrYdiv[MAXPLOTS];
int    GrYdec[MAXPLOTS];

int            iColor;

LPPLOTPAR lpPPS= NULL;
/********************************************************************************
 * flags whether caption of x-axis shall be transformed to data format
 * both for printer  and screen are necessary becuase of time overlapping effects
 * in windows message queue
 */
BOOL   bDateString=FALSE;
BOOL   bPrnDateString=FALSE;


/*----< global.c >------*/
extern HPEN   far * lpahGrafPens;
extern HFONT  far * lpahExpFonts;


/*----< measure.c >--------*/
extern char acNO3Legend_1[];
extern char acNO3Legend_2[];
extern char acNO3Legend_3[];
extern char acNO3Legend_4[];
extern char acNO3Legend_5[];
extern char acNH4Legend_1[];
extern char acH2OLegend_1[];
extern char acH2OLegend_2[];
extern char acH2OLegend_3[];
extern char acH2OLegend_4[];
extern char acH2OLegend_5[];
extern int XGetNoOfNitroMeasurePoints(void);
extern int XGetNoOfH2OMeasurePoints(void);
 
/*----<  util.c  >-----------*/
extern  BOOL  DoubleToText(double, LPSTR, int);
// graphic - plot parameter: xplot.c
extern  double     PlotDZ1Ymin;
extern  double     PlotDZ1Ymax;
extern  double     PlotDZ1YDiv;
extern  int        PlotDZ1YDec;

extern  double     PlotDZ1Xmin;
extern  double     PlotDZ1Xmax;
extern  double     PlotDZ1XDiv;
extern  int        PlotDZ1XDec;

extern  double     PlDZ1Xmin;
extern  double     PlDZ1Xmax;
extern  double     PlDZ1Xdiv;
extern  int        PlDZ1Xdec;



extern  double     PlotDT1Xmin;
extern  double     PlotDT1Xmax;
extern  double     PlotDT1XDiv;
extern  int        PlotDT1XDec;

extern  double     PlotDT1Ymin;
extern  double     PlotDT1Ymax;
extern  double     PlotDT1YDiv;
extern  int        PlotDT1YDec;

/*---*/
extern  double     PlotDZ2Ymin;
extern  double     PlotDZ2Ymax;
extern  double     PlotDZ2YDiv;
extern  int        PlotDZ2YDec;

extern  double     PlotDZ2Xmin;
extern  double     PlotDZ2Xmax;
extern  double     PlotDZ2XDiv;
extern  int        PlotDZ2XDec;

extern  double     PlDZ2Xmin;   /// for dummy graphics
extern  double     PlDZ2Xmax;
extern  double     PlDZ2Xdiv;
extern  int        PlDZ2Xdec;

extern  double     PlotDT2Xmin;
extern  double     PlotDT2Xmax;
extern  double     PlotDT2XDiv;
extern  int        PlotDT2XDec;

extern  double     PlotDT2Ymin;
extern  double     PlotDT2Ymax;
extern  double     PlotDT2YDiv;
extern  int        PlotDT2YDec;
//-------------
extern COLORREF GraphCol[];
/*------< Xplot.c >--------*/
extern void XDrawAll(int iNr, LPHGRAPH lphGraph, RECT Rect);

/*-----< PRINTER.C >--------*/
extern int  PrintObject(LPSTR);
// -----------------  export procedures   prototypes   -----------------------
HICON HydrIcon(HINSTANCE);
void DestroyHydrIcon(void);

int doXScaleDlg( HWND hWndDlg);
int doYScaleDlg( HWND hWndDlg);
int eraseDlgPPS( HWND hDlg);

void resetLegendAndButtons( HWND, int); 
void initPlotWndDim( HWND);


/*********************************************************************************************
 *   void  initPlotWndDim( HWND  hWndDlg)
 *--------------------------------------------------------------------------------------------
 *   C. Sperr
 *   5.12.97
 *********************************************************************************************
 */
void  initPlotWndDim( HWND  hWndDlg)
{
int iXDim,iYDim;
int iTop,iLeft,iWidth,iHeight;
static bToggle=TRUE;
   iXDim = GetSystemMetrics(SM_CXSCREEN);
   iYDim = GetSystemMetrics(SM_CYSCREEN);
 // origin
   if (bToggle) iLeft  = 0;
   else      iLeft  = iXDim/2;
   iTop    = iYDim/15;
 // dimensions
   iWidth  = iXDim/2;
   iHeight  = 13*iYDim/15;
   MoveWindow(hWndDlg,iLeft,iTop,iWidth,iHeight,TRUE);
   bToggle = !bToggle;
 return;
}

/*******************************************************************************************
 *   void resetLegendAndButtons( HWND hWndDlg,int iBtnTypes)
 *   iBtnTypes :   1 = only Y and cancel and print 
 *   iBtnTypes :   2 = X and Y  and cancel and print 
 *   C. Sperr
 *   5.12.97
 *********************************************************************************************
 */
//determine relative positions of buttons  
void resetLegendAndButtons( HWND hWndDlg,int iBtnTypes)
   { HWND hXButton;
   HWND hYButton;
   HWND hCANCELButton;
   HWND hPRINTButton;

//   HWND hExpWnd;
   RECT WinRect;
   
    int  iLeft, iTop,iWidth, iHeight;

      // resize the graphic Window
/* does not work ---------------------------------------------------------
    hExpWnd = GetParent(hWndDlg);
    if (hExpWnd == NULL)lastErrorMsg(__FILE__, __LINE__, " ClientRect");
    else {GetClientRect(hExpWnd,(LPRECT)&WinRect);
      MoveWindow(hWndDlg,WinRect.left,
              WinRect.top+WinRect.right/10,
              WinRect.right,
              WinRect.bottom,TRUE);  
    }
does not work ---------------------------------------------------------*/
      
    // position the controls on dialogs
    GetClientRect(hWndDlg,(LPRECT)&WinRect);

    hXButton = GetDlgItem(hWndDlg, ID_X_SCALE);
    hYButton = GetDlgItem(hWndDlg, ID_Y_SCALE);
    hCANCELButton = GetDlgItem(hWndDlg, IDCANCEL);
    hPRINTButton = GetDlgItem(hWndDlg, ID_PRINT);
    // generally for all 
    iWidth = WinRect.right/5;
    iHeight = WinRect.bottom/35;
    iLeft =  WinRect.right - (int)( 1.2* (float)iWidth);
    // distinguish by Y - position
    iTop = 27*WinRect.bottom/32;
    if (iBtnTypes > 1){
        MoveWindow(hXButton,iLeft,iTop,iWidth,iHeight,TRUE);  
        iTop += (int)(1.2*(float)iHeight);
    } else {
        MoveWindow(hXButton,2* WinRect.right,iTop,iWidth,iHeight,TRUE);  
    }
    MoveWindow(hYButton,iLeft,iTop,iWidth,iHeight,TRUE);  
    iTop +=(int)(1.2*(float)iHeight);
    MoveWindow(hCANCELButton,iLeft,iTop,iWidth,iHeight,TRUE);  
    iTop += (int)(1.2*(float)iHeight);
    MoveWindow(hPRINTButton,iLeft,iTop,iWidth,iHeight,TRUE);  
  
 //determine relartive positions of legend    
     LEGEND_X0 = WinRect.left + (WinRect.right/35);
      LEGEND_Y0 = 27 * WinRect.bottom/32;
    
    LEGEND_LINE_DX = WinRect.right/3;
    LEGEND_TEXT_X0 = LEGEND_X0 + LEGEND_LINE_DX;
    LEGEND_TEXT_Y0  = LEGEND_Y0-10; 

 return;  
}

/*******************************************************************************************
 *   HICON HydrIcon(HINSTANCE hI)
 *         load icon only once
 *   C. Sperr
 *   28.01.94
 *********************************************************************************************
 */
HICON HydrIcon(HINSTANCE hI)
{
  if (!hIcon){   iIconCount++;
               hIcon = LoadIcon(hI,MAKEINTRESOURCE(IDI_GRAPH));
           }
  else    iIconCount++;

  return hIcon;
}
/*******************************************************************************************
 *  void DestroyHydrIcon()
 *        destroy icon if last instance shut down
 *   C. Sperr
 *   28.01.94
 *********************************************************************************************
 */

void DestroyHydrIcon()
{
  if(!(--iIconCount))
  { DestroyIcon(hIcon);
    hIcon = 0;
  }
}

/*************************************************************************************************
 *   call Y - Scaling dialog
 *
 *   C. Sperr
 *   20.01.94
 */
int doYScaleDlg( HWND hWndDlg )
{
  int  nRc = DialogBox( GetExpertNAppInstance(), MAKEINTRESOURCE(IDD_DIALOG1), hWndDlg, YScaleDLGProc );
  InvalidateRect(hWndDlg, NULL,TRUE);
  return nRc;
}

/*************************************************************************************************
 *   call X - Scaling dialog
 *
 *   C. Sperr
 *   20.01.94
 */
int doXScaleDlg( HWND hWndDlg)
{
  int  nRc = DialogBox( GetExpertNAppInstance(), MAKEINTRESOURCE(IDD_DIALOG2), hWndDlg, XScaleDLGProc );
  InvalidateRect(hWndDlg, NULL,TRUE);
  return nRc;
}

/*******************************************************************************************
 *  Dialog  for scaling
 *
 *  Author : C. Sperr
 *  Date   : 19.01.94
 */
INT_PTR CALLBACK YScaleDLGProc( HWND hDlg, UINT wMsg, WPARAM wParam, LPARAM lParam)
{
  BOOL fProcessed = TRUE;
  HWND   hMin,hMax,hDiv;
  char acMin[20]={"0.0"},acMax[20]={"1.0"},acDiv[20]={"1"};

  switch (wMsg)
  {
    case WM_INITDIALOG:
      // During initialization, before any windows are shown, resize the
      // dialog box so that only the "default" portion is shown.
      {
        hMin = GetDlgItem(hDlg,IDC_EDIT1);
        hMax = GetDlgItem(hDlg,IDC_EDIT2);
        hDiv = GetDlgItem(hDlg,IDC_EDIT3);
        lpPPS = SearchPPSMember(getRootPPS(),GetParent(hDlg));
        if (lpPPS !=NULL)
        {
          DoubleToText(lpPPS->dYmin, (LPSTR)acMin,2);
          DoubleToText(lpPPS->dYmax, (LPSTR)acMax,2);
          itoa(lpPPS->iYdiv,acDiv,10);
        }
        SetDlgItemText(hDlg,IDC_EDIT1,acMin);
        SetDlgItemText(hDlg,IDC_EDIT2,acMax);
        SetDlgItemText(hDlg,IDC_EDIT3,acDiv);
      }
      break;

    case WM_COMMAND:
      switch (wParam)
      {
        case IDOK:
        {
          GetDlgItemText(hDlg,IDC_EDIT1,acMin,10);
          GetDlgItemText(hDlg,IDC_EDIT2,acMax,10);
          GetDlgItemText(hDlg,IDC_EDIT3,acDiv,10);
          lpPPS = SearchPPSMember(getRootPPS(),GetParent(hDlg));
          if (lpPPS !=NULL)
          {
            lpPPS->dYmin =atof((const char *)acMin);
            lpPPS->dYmax =atof((const char *)acMax);
            if (lpPPS->dYmin>=lpPPS->dYmax)
              lpPPS->dYmax =lpPPS->dYmin + 1.0;
            lpPPS->iYdiv =atoi((const char *)acDiv);
            if (lpPPS->iYdiv <= 0)
              lpPPS->iYdiv =1;
          }
          EndDialog(hDlg, wParam);
          break;
        }

        case IDCANCEL:
          // Terminate dialog box if user selects the "Ok" or
          // "Cancel" buttons.
          EndDialog(hDlg, wParam);
          break;

        default:
          break;
      }
      break;

    default:
      fProcessed = FALSE;
      break;
  }
  return(fProcessed);
}

/*******************************************************************************************
 *  Dialog  for scaling
 *
 *  Author : C. Sperr
 *  Date   : 19.01.94
 */
INT_PTR CALLBACK XScaleDLGProc( HWND hDlg, UINT wMsg, WPARAM wParam, LPARAM lParam )
{
  BOOL fProcessed = TRUE;
  HWND   hMin,hMax,hDiv;
  char acMin[20]={"0.0"},acMax[20]={"1.0"},acDiv[20]={"1"};

  switch (wMsg)
  {
    case WM_INITDIALOG:
    {
      // During initialization, before any windows are shown, resize the
      // dialog box so that only the "default" portion is shown.
      hMin = GetDlgItem(hDlg,IDC_EDIT1);
      hMax = GetDlgItem(hDlg,IDC_EDIT2);
      hDiv = GetDlgItem(hDlg,IDC_EDIT3);
      lpPPS = SearchPPSMember(getRootPPS(),GetParent(hDlg));
      if (lpPPS !=NULL)
      {
        DoubleToText(lpPPS->dXmin, (LPSTR)acMin,2);
        DoubleToText(lpPPS->dXmax, (LPSTR)acMax,2);
        itoa(lpPPS->iXdiv,acDiv,10);
        if (lpPPS->iYdiv <= 0)
          lpPPS->iYdiv =1;
      }
      SetDlgItemText(hDlg,IDC_EDIT1,acMin);
      SetDlgItemText(hDlg,IDC_EDIT2,acMax);
      SetDlgItemText(hDlg,IDC_EDIT3,acDiv);
      break;
    }
    case WM_COMMAND:
      switch (wParam)
      {
        case IDOK:
        {
          GetDlgItemText(hDlg,IDC_EDIT1,acMin,10);
          GetDlgItemText(hDlg,IDC_EDIT2,acMax,10);
          GetDlgItemText(hDlg,IDC_EDIT3,acDiv,10);
          lpPPS = SearchPPSMember(getRootPPS(),GetParent(hDlg));
          if (lpPPS !=NULL)
          {
            lpPPS->dXmin =atof((const char *)acMin);
            lpPPS->dXmax =atof((const char *)acMax);
            if (lpPPS->dXmin>=lpPPS->dXmax)
              lpPPS->dXmax =lpPPS->dXmin + 1.0;
            lpPPS->iXdiv =atoi((const char *)acDiv);
            if (lpPPS->iXdiv <= 0)
              lpPPS->iXdiv =1;
          }
          EndDialog(hDlg, wParam);
          break;
        }
        case IDCANCEL:
          // Terminate dialog box if user selects the 
          // "Cancel" buttons.
          EndDialog(hDlg, wParam);
          break;
        default:
          break;
      }
      break;

    default:
      fProcessed = FALSE;
      break;
  }
  return(fProcessed);
}

/***********************************************************************************************
 * Function    :  PlotMeasH2OProc
 *                Graphic - Call Back Procedure    Measurement  analysis  plot dialog
 *
 * Author   :  C.Sperr
 * Date     :  27.08.94
 *
 *----------------------------------------------------------------------------------------------
 * Changed :   Date     Name                        report
 *
 *
 ***********************************************************************************************
 */
extern INT_PTR CALLBACK PlotMeasH2OProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{     HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;
 int            iMax;

 switch (Message)
 {
   case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
     /*
      * adjust coordinate system
      */
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
    lpPPS->iIDMenu = IDM_G_MEAS_H2O;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
        lpPPS->dXmax = PlotDT1Xmax;
        lpPPS->iXdiv = (int)PlotDT1XDiv;
        lpPPS->iXdec= (int) PlotDT1XDec;

        lpPPS->dYmin = 10.0;
        lpPPS->dYmax = 60.0;
        lpPPS->iYdiv = 5;
        lpPPS->iYdec = 0;
      }
     
    SetWindowText(hWndDlg,G_MEASH2O_SS_TXT);
      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON, (long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    initPlotWndDim(hWndDlg);

      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */

           
    

     lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
     GrXmin[PLOTMEASH2O] =lpPPS->dXmin; // ] = PlotDT1Xmin
     GrXmax[PLOTMEASH2O] =lpPPS->dXmax; // ] = PlotDT1XMax
     GrXdiv[PLOTMEASH2O] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
     GrXdec[PLOTMEASH2O] = lpPPS->iXdec ;  //] = PlotDT1XDec;
     GrYmin[PLOTMEASH2O] = lpPPS->dYmin;
     GrYmax[PLOTMEASH2O] = lpPPS->dYmax;
     GrYdiv[PLOTMEASH2O] = (double)lpPPS->iYdiv;
     GrYdec[PLOTMEASH2O] = lpPPS->iYdec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
    
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;
    /****************************************
     * paint color lines for legend
     */

      iMax = XGetNoOfH2OMeasurePoints();
      for (iColor=0;iColor < iMax;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }

        // Set text style
        hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      /**************************************
       * Legend text
       */  
                          
      for (iColor=0;iColor <= iMax;iColor++)
      { switch (iColor){
         case 0: TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 ,acH2OLegend_1,lstrlen(acH2OLegend_1));
         break;
         case 1: TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_1 ,acH2OLegend_2,lstrlen(acH2OLegend_2));
         break;
         case 2: TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_2 ,acH2OLegend_3,lstrlen(acH2OLegend_3));
         break;
         case 3: TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_3 ,acH2OLegend_4,lstrlen(acH2OLegend_4));
         break;
         case 4: TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_4 ,acH2OLegend_5,lstrlen(acH2OLegend_5));
         break;
         default:break; 
        } 
      }
      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTMEASH2O,(LPHGRAPH) &s_hGraph, WinRect);
//      else             
      XDrawAll(PLOTMEASH2O,(LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

 
    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PrnMeasH2O");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;

           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
        DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);
                
        break;
         }
         break;    /* End of WM_COMMAND                                 */

       default:
           return FALSE;
    }
    return TRUE;



}
/***********************************************************************************************
 * Function    :  PlotMeasNO3Proc
 *                Graphic - Call Back Procedure    Measurement  analysis  plot dialog
 *
 * Author   :  C.Sperr
 * Date     :  27.08.94
 *
 *----------------------------------------------------------------------------------------------
 * Changed :   Date     Name                        report
 *
 *
 ***********************************************************************************************
 */
extern INT_PTR CALLBACK PlotMeasNO3Proc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{     HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;

 
 switch (Message)
 {
   case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
     /*
      * adjust coordinate system
      */
      

      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      { 
    lpPPS->iIDMenu = IDM_G_MEAS_NO3;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
        lpPPS->dXmax = PlotDT1Xmax;
        lpPPS->iXdiv = (int)PlotDT1XDiv;
        lpPPS->iXdec= (int) PlotDT1XDec;

        lpPPS->dYmin = 0.0;
        lpPPS->dYmax = 100.0;
        lpPPS->iYdiv = 10;
        lpPPS->iYdec = 0;
      }

      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON, (long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_MEASNO3_SS_TXT);
     initPlotWndDim(hWndDlg);

      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */


      

     lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
     GrXmin[PLOTMEASNO3] =lpPPS->dXmin; // ] = PlotDT1Xmin
     GrXmax[PLOTMEASNO3] =lpPPS->dXmax; // ] = PlotDT1XMax
     GrXdiv[PLOTMEASNO3] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
     GrXdec[PLOTMEASNO3] = lpPPS->iXdec ;  //] = PlotDT1XDec;
     GrYmin[PLOTMEASNO3] = lpPPS->dYmin;
     GrYmax[PLOTMEASNO3] = lpPPS->dYmax;
     GrYdiv[PLOTMEASNO3] = (double)lpPPS->iYdiv;
     GrYdec[PLOTMEASNO3] = lpPPS->iYdec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;
    /****************************************
     * paint color lines for legend
     */
     ///iMax =  XGetNoOfNitroMeasurePoints();

      for (iColor=0;iColor < 4;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
       }
 /*
       if (iMax >0) {         /// NH4   Legend line
          hOldPen = SelectObject(hDC,lpahGrafPens[5]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0     +  5 *15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 +  5 *15));
          SelectObject(hDC, hOldPen);
        }
 */
        // Set text style
        hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      /**************************************
       * Legend text
       */                                  
    lstrcpy(acNH4Legend_1,GL_NH4_SCH11_TXT);   
    //-----------------
    lstrcpy(acNO3Legend_1,GL_NO3_SCH01_TXT);
    lstrcpy(acNO3Legend_2,GL_NO3_SCH11_TXT);
    lstrcpy(acNO3Legend_3,GL_NO3_SCH21_TXT);
    

    for (iColor=0;iColor < 4;iColor++)
    { switch (iColor){
       case 0: TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 ,acNO3Legend_1,lstrlen(acNO3Legend_1));         
       break;
       case 1: TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_1 ,acNO3Legend_2,lstrlen(acNO3Legend_2));
       break;
       case 2: TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_2 ,acNO3Legend_3,lstrlen(acNO3Legend_3));
       break;
       case 3: TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_3 ,acNH4Legend_1,lstrlen(acNH4Legend_1));
       break;
       case 4: TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_4 ,acNO3Legend_4,lstrlen(acNO3Legend_4));
       break;
       case 5: TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_5 ,acNO3Legend_5,lstrlen(acNO3Legend_5));
       break;
       default:break; 
      } 
     }
   
      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTMEASNO3,(LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTMEASNO3,(LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PrnMeasNO3");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;


           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
          DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);

                break;
         }
         break;    /* End of WM_COMMAND                                 */

       default:
           return FALSE;
    }
    return TRUE;



}

/***********************************************************************************************
 * Plant :  extern INT_PTR CALLBACK PlotDevStageProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
 * Graphic - Call Back Procedure
 *
 * C.Sperr
 * 25.04.94
 *
 ***********************************************************************************************
 */
extern INT_PTR CALLBACK PlotDevStageProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{     HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;

 switch (Message)
 {
   case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
     /*
      * adjust coordinate system
      */
      

      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_DEVSTAGE;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
        lpPPS->dXmax = PlotDT1Xmax;
        lpPPS->iXdiv = (int)PlotDT1XDiv;
        lpPPS->iXdec= (int) PlotDT1XDec;

        lpPPS->dYmin = 0.0;
        lpPPS->dYmax = 10.0;
        lpPPS->iYdiv = 10;
        lpPPS->iYdec = 0;
      }
     SetWindowText(hWndDlg,G_DEVSTAGE_SS_TXT);
      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON, (long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
      initPlotWndDim(hWndDlg);

      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */


      

     lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
     GrXmin[PLOTDEVSTAGE] =lpPPS->dXmin; // ] = PlotDT1Xmin
     GrXmax[PLOTDEVSTAGE] =lpPPS->dXmax; // ] = PlotDT1XMax
     GrXdiv[PLOTDEVSTAGE] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
     GrXdec[PLOTDEVSTAGE] = lpPPS->iXdec ;  //] = PlotDT1XDec;
     GrYmin[PLOTDEVSTAGE] = lpPPS->dYmin;
     GrYmax[PLOTDEVSTAGE] = lpPPS->dYmax;
     GrYdiv[PLOTDEVSTAGE] = (double)lpPPS->iYdiv;
     GrYdec[PLOTDEVSTAGE] = lpPPS->iYdec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;
    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <2;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }

        // Set text style
        hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      /**************************************
       * Legend text
       */
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 ,(LPSTR)GL_DEVSTAGE1_TXT,lstrlen((LPSTR)GL_DEVSTAGE1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_1 ,(LPSTR)GL_DEVSTAGE2_TXT,lstrlen((LPSTR)GL_DEVSTAGE2_TXT));

      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTDEVSTAGE, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTDEVSTAGE, (LPHGRAPH) &s_hGraph, WinRect);
      
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PrnDevStage");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;


           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);
        break;
         }
         break;    /* End of WM_COMMAND                                 */

       default:
           return FALSE;
    }
    return TRUE;



}
/***********************************************************************************************
 * Plant :  extern INT_PTR CALLBACK PlotLaiProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
 * Graphic - Call Back Procedure
 *
 * C.Sperr
 * 25.04.94
 *
 ***********************************************************************************************
 */
extern INT_PTR CALLBACK PlotLaiProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;

 switch (Message)
 {
   case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
     /*
      * adjust coordinate system
      */
      

      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_LAI;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
        lpPPS->dXmax = PlotDT1Xmax;
        lpPPS->iXdiv = (int)PlotDT1XDiv;
        lpPPS->iXdec= (int) PlotDT1XDec;

        lpPPS->dYmin = 0.0;
        lpPPS->dYmax = 10.0;
        lpPPS->iYdiv = 5;
        lpPPS->iYdec = 2;
      }

      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON, (long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
      SetWindowText(hWndDlg,G_LAI_SS_TXT);
      initPlotWndDim(hWndDlg);

      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */


      

     lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
     GrXmin[PLOTLAI] =lpPPS->dXmin; // ] = PlotDT1Xmin
     GrXmax[PLOTLAI] =lpPPS->dXmax; // ] = PlotDT1XMax
     GrXdiv[PLOTLAI] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
     GrXdec[PLOTLAI] = lpPPS->iXdec ;  //] = PlotDT1XDec;
     GrYmin[PLOTLAI] = lpPPS->dYmin;
     GrYmax[PLOTLAI] = lpPPS->dYmax;
     GrYdiv[PLOTLAI] = (double)lpPPS->iYdiv;
     GrYdec[PLOTLAI] = lpPPS->iYdec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;
    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <1;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }

        // Set text style
        hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      /**************************************
       * Legend text
       */
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 ,(LPSTR)GL_LAI_TXT,lstrlen((LPSTR)GL_LAI_TXT));

      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTLAI, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTLAI, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PrnLai");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;

           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);
                break;
         }
         break;    /* End of WM_COMMAND                                 */

       default:
           return FALSE;
    }
    return TRUE;


}

/***********************************************************************************************
 * Plant :  extern INT_PTR CALLBACK PlotTillersProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
 * Graphic - Call Back Procedure
 *
 * C.Sperr
 * 25.04.94
 *
 ***********************************************************************************************
 */
extern INT_PTR CALLBACK PlotTillersProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;

 switch (Message)
 {
   case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
     /*
      * adjust coordinate system
      */
      

      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_TILLERS;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
        lpPPS->dXmax = PlotDT1Xmax;
        lpPPS->iXdiv = (int)PlotDT1XDiv;
        lpPPS->iXdec= (int) PlotDT1XDec;

        lpPPS->dYmin = 0.0;
        lpPPS->dYmax = 2000.0;
        lpPPS->iYdiv = 10;
        lpPPS->iYdec = 0;
      }

      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON, (long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_TILLERS_SS_TXT);
    
    initPlotWndDim(hWndDlg);

      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */


      

     lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
     GrXmin[PLOTTILLERS] =lpPPS->dXmin; // ] = PlotDT1Xmin
     GrXmax[PLOTTILLERS] =lpPPS->dXmax; // ] = PlotDT1XMax
     GrXdiv[PLOTTILLERS] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
     GrXdec[PLOTTILLERS] = lpPPS->iXdec ;  //] = PlotDT1XDec;
     GrYmin[PLOTTILLERS] = lpPPS->dYmin;
     GrYmax[PLOTTILLERS] = lpPPS->dYmax;
     GrYdiv[PLOTTILLERS] = (double)lpPPS->iYdiv;
     GrYdec[PLOTTILLERS] = lpPPS->iYdec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
  /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
 // border of coordinate system
    LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn
      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;
    /****************************************
     * paint color lines for legend
     */
 
      for (iColor=0;iColor <1;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }

        // Set text style
        hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      /**************************************
       * Legend text
       */
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 ,(LPSTR)GL_TILLERS_TXT,lstrlen((LPSTR)GL_TILLERS_TXT));

      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTTILLERS, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTTILLERS, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    
    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PrnTillers");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;


           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);
                break;
         }
         break;    /* End of WM_COMMAND                                 */

       default:
           return FALSE;
    }
    return TRUE;

}

/***********************************************************************************************
 * Plant :  extern INT_PTR CALLBACK PlotBiomassProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
 * Graphic - Call Back Procedure
 *
 * C.Sperr
 * 25.04.94
 *
 ***********************************************************************************************
 */
extern INT_PTR CALLBACK PlotBiomassProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
  static HGRAPH  s_hGraph;
  HDC            hDC;
  PAINTSTRUCT    ps;
  HPEN           hOldPen;
  HFONT          hOldFont;
  RECT           WinRect;

  switch (Message)
  {
    case WM_ERASEBKGND:
      s_hGraph.bRedraw = TRUE;
      return FALSE;

    case WM_INITDIALOG:
      /*
      * adjust coordinate system
      */
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_BIOMASS;
        lpPPS->bXTimeScale = TRUE;
        lpPPS->dXmin = PlotDT1Xmin;
        lpPPS->dXmax = PlotDT1Xmax;
        lpPPS->iXdiv = (int)PlotDT1XDiv;
        lpPPS->iXdec= (int) PlotDT1XDec;
        lpPPS->dYmin = 0.0;
        lpPPS->dYmax = 15.0;
        lpPPS->iYdiv = 15;
        lpPPS->iYdec = 2;
      }

      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON, (long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
      SetWindowText(hWndDlg,G_BIOMASS_SS_TXT);
      initPlotWndDim(hWndDlg);
      break;      /*  End of WM_CREATE */

    case WM_PAINT: /* code for the window's client area */
      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
      GrXmin[PLOTBIOMASS] =lpPPS->dXmin; // ] = PlotDT1Xmin
      GrXmax[PLOTBIOMASS] =lpPPS->dXmax; // ] = PlotDT1XMax
      GrXdiv[PLOTBIOMASS] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
      GrXdec[PLOTBIOMASS] = lpPPS->iXdec ;  //] = PlotDT1XDec;
      GrYmin[PLOTBIOMASS] = lpPPS->dYmin;
      GrYmax[PLOTBIOMASS] = lpPPS->dYmax;
      GrYdiv[PLOTBIOMASS] = (double)lpPPS->iYdiv;
      GrYdec[PLOTBIOMASS] = lpPPS->iYdec;

      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
      // reposition legend and buttons    
      resetLegendAndButtons(hWndDlg,2); 
      // range where coordinate system is drawn
      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;
      /****************************************
      * paint color lines for legend
      */

      for (iColor=0;iColor <5;iColor++)
      {
        hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
        MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
        LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
        SelectObject(hDC, hOldPen);
      }

      // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      /**************************************
       * Legend text
      */
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 ,(LPSTR)GL_GRAINW_TXT,lstrlen((LPSTR)GL_GRAINW_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_1,(LPSTR)GL_LEAFW_TXT,lstrlen((LPSTR)GL_LEAFW_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_2,(LPSTR)GL_STEMW_TXT,lstrlen((LPSTR)GL_STEMW_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_3,(LPSTR)GL_ROOTW_TXT,lstrlen((LPSTR)GL_ROOTW_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_4,(LPSTR)GL_O_VEG_TXT,lstrlen((LPSTR)GL_O_VEG_TXT));

      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
      //      if (!gbVersionSelect)  DrawAll(PLOTBIOMASS, (LPHGRAPH) &s_hGraph, WinRect);
      //      else               
      XDrawAll(PLOTBIOMASS, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
      InvalidateRect(hWndDlg, NULL,TRUE);
      break;

    case WM_CLOSE:
      /*
      * force execution of IDCANCEL - Codesection  below!
      */
      PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
      break;

    case WM_HSCROLL:
      break;

    case WM_COMMAND:
      switch(wParam)
      {
        case ID_PRINT:
          //-------<Printer Output PRINT.C>-------
          bPrnDateString=TRUE;
          PrintObject((LPSTR)"PrnBiomass");
          bPrnDateString=FALSE;
          //--------------------------------------
          break;
        case ID_Y_SCALE:
          doYScaleDlg(hWndDlg);
          break;
        case ID_X_SCALE:
          doXScaleDlg(hWndDlg);
          break;
        case IDOK:
        case IDCANCEL:
          DestroyHydrIcon();
          lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
          if (lpPPS != NULL)
          {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
          }
          DestroyWindow(hWndDlg);
          eraseDlgPPS(hWndDlg);
          break;
      }
      break;    /* End of WM_COMMAND                                 */

    default:
      return FALSE;
  }
  return TRUE;
}

/***********************************************************************************************
 * Plant :  extern INT_PTR CALLBACK PlotRootLengthProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
 * Graphic - Call Back Procedure
 *
 * C.Sperr
 * 25.04.94
 *
 ***********************************************************************************************
 */
extern INT_PTR CALLBACK PlotRootLengthProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT           WinRect;



   switch (Message)
   {
    case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;

   case WM_INITDIALOG:

      

       lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
       if (lpPPS !=NULL)
       {
         lpPPS->iIDMenu = IDM_G_ROOTLENGTH;
     lpPPS->bYDepthScale = TRUE;

         lpPPS->dXmin = 0.0;
         lpPPS->dXmax = 10.0;
         lpPPS->iXdiv = 5;
         lpPPS->iXdec = 1;

         lpPPS->dYmin = PlotDZ1Ymin;
         lpPPS->dYmax = PlotDZ1Ymax;
         lpPPS->iYdiv = (int)PlotDZ1YDiv;
         lpPPS->iYdec = PlotDZ1YDec;
       }

      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON,(long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_ROOTLENGTH_SS_TXT);
    initPlotWndDim(hWndDlg);

      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */

      

      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);

      GrXmin[PLOTROOTLENGTH] =lpPPS->dXmin;
      GrXmax[PLOTROOTLENGTH] =lpPPS->dXmax;
      GrXdiv[PLOTROOTLENGTH] = (double)lpPPS->iXdiv;
      GrXdec[PLOTROOTLENGTH] = lpPPS->iXdec;
 /*------- depth dependant   scale parameter  ------------------*/

/* resize if Layer data in file were changed
       
      lpPPS->dYmin = PlotDZ1Ymin;
      lpPPS->dYmax = PlotDZ1Ymax;
      lpPPS->iYdiv = (int)PlotDZ1YDiv;
      lpPPS->iYdec = PlotDZ1YDec;
081297*****************************/

      GrYmin[PLOTROOTLENGTH] = lpPPS->dYmin;
      GrYmax[PLOTROOTLENGTH] = lpPPS->dYmax;
      GrYdiv[PLOTROOTLENGTH] = (double)lpPPS->iYdiv;
      GrYdec[PLOTROOTLENGTH] = lpPPS->iYdec;


      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);

      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;

      for (iColor=0;iColor < 1;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor/**15*/),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor/**15*/));
          SelectObject(hDC, hOldPen);
      }
        // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_ROOTLENGTH_TXT,lstrlen((LPSTR)GL_ROOTLENGTH_TXT));
      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

//      if (!gbVersionSelect)  DrawAll(PLOTROOTLENGTH, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTROOTLENGTH, (LPHGRAPH) &s_hGraph, WinRect);

      EndPaint(hWndDlg, &ps);

      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               PrintObject("PrnRootLength");
               //--------------------------------------
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;



           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
        eraseDlgPPS(hWndDlg);
                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;

}

/***********************************************************************************************
 * Plant :  extern INT_PTR CALLBACK PlotRootLengthDTProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
 * Graphic - Call Back Procedure
 *
 * C.Sperr
 * 25.04.94
 *
 ***********************************************************************************************
 */
extern INT_PTR CALLBACK PlotRootLengthDTProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT           WinRect;



   switch (Message)
   {
    case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;

   case WM_INITDIALOG:

      

       lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
       if (lpPPS !=NULL)
       {
        lpPPS->iIDMenu = IDM_G_ROOTLENGTHDT;
    lpPPS->bXTimeScale = TRUE;


        lpPPS->dXmin = PlotDT1Xmin;
        lpPPS->dXmax = PlotDT1Xmax;
        lpPPS->iXdiv = (int)PlotDT1XDiv;
        lpPPS->iXdec= (int) PlotDT1XDec;

         lpPPS->dYmin = 0;
         lpPPS->dYmax = 10;
         lpPPS->iYdiv = 10;
         lpPPS->iYdec = 1;
       }

      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON,(long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_ROOTLENGTH_SS_TXT);
    initPlotWndDim(hWndDlg);
      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */

      

      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
     GrXmin[PLOTROOTLENGTHDT] =lpPPS->dXmin; // ] = PlotDT1Xmin
     GrXmax[PLOTROOTLENGTHDT] =lpPPS->dXmax; // ] = PlotDT1XMax
     GrXdiv[PLOTROOTLENGTHDT] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
     GrXdec[PLOTROOTLENGTHDT] = lpPPS->iXdec ;  //] = PlotDT1XDec;
     GrYmin[PLOTROOTLENGTHDT] = lpPPS->dYmin;
     GrYmax[PLOTROOTLENGTHDT] = lpPPS->dYmax;
     GrYdiv[PLOTROOTLENGTHDT] = (double)lpPPS->iYdiv;
     GrYdec[PLOTROOTLENGTHDT] = lpPPS->iYdec;

      
   
 /*------- depth dependant   scale parameter  ------------------*/


      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);

      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);

// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn
      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;

      for (iColor=0;iColor < 4;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }
        // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_ROOTLENGTHDT1_TXT,lstrlen((LPSTR)GL_ROOTLENGTHDT1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_1,(LPSTR)GL_ROOTLENGTHDT2_TXT,lstrlen((LPSTR)GL_ROOTLENGTHDT2_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_2,(LPSTR)GL_ROOTLENGTHDT3_TXT,lstrlen((LPSTR)GL_ROOTLENGTHDT3_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_3,(LPSTR)GL_ROOTLENGTHDT4_TXT,lstrlen((LPSTR)GL_ROOTLENGTHDT4_TXT));
      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;
      
      bDateString=TRUE;
      XDrawAll(PLOTROOTLENGTHDT, (LPHGRAPH) &s_hGraph, WinRect);

      EndPaint(hWndDlg, &ps);

      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               PrintObject("PrnRootLength");
               //--------------------------------------
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;



           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
        eraseDlgPPS(hWndDlg);
                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;

}

/***********************************************************************************************
 * Plant :  extern INT_PTR CALLBACK PlotTranspProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
 * Graphic - Call Back Procedure
 *
 * C.Sperr
 * 25.04.94
 *
 ***********************************************************************************************
 */
extern INT_PTR CALLBACK PlotTranspProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
  static HGRAPH  s_hGraph;
  HDC            hDC;
  PAINTSTRUCT    ps;
  HPEN           hOldPen;
  HFONT          hOldFont;
  RECT           WinRect;

  switch (Message)
  {
    case WM_ERASEBKGND:
      s_hGraph.bRedraw = TRUE;
      return FALSE;

    case WM_INITDIALOG:
      /*
      * adjust coordinate system
      */
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_TRANSP;
        lpPPS->bXTimeScale = TRUE;
        lpPPS->dXmin = PlotDT1Xmin;
        lpPPS->dXmax = PlotDT1Xmax;
        lpPPS->iXdiv = (int)PlotDT1XDiv;
        lpPPS->iXdec= (int) PlotDT1XDec;
        lpPPS->dYmin = 0.0;
        lpPPS->dYmax = 10.0;
        lpPPS->iYdiv = 10;
        lpPPS->iYdec = 1;
      }

      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON, (long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
      SetWindowText(hWndDlg,G_TRANSP_SS_TXT);
      initPlotWndDim(hWndDlg);
      break;      /*  End of WM_CREATE */

    case WM_PAINT: /* code for the window's client area */
      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
      GrXmin[PLOTTRANSP] =lpPPS->dXmin; // ] = PlotDT1Xmin
      GrXmax[PLOTTRANSP] =lpPPS->dXmax; // ] = PlotDT1XMax
      GrXdiv[PLOTTRANSP] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
      GrXdec[PLOTTRANSP] = lpPPS->iXdec ;  //] = PlotDT1XDec;
      GrYmin[PLOTTRANSP] = lpPPS->dYmin;
      GrYmax[PLOTTRANSP] = lpPPS->dYmax;
      GrYdiv[PLOTTRANSP] = (double)lpPPS->iYdiv;
      GrYdec[PLOTTRANSP] = lpPPS->iYdec;

      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
      // reposition legend and buttons    
      resetLegendAndButtons(hWndDlg,2); 

      // range where coordinate system is drawn
      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;
      /****************************************
      * paint color lines for legend
      */

      for (iColor=0;iColor <2;iColor++)
      {
        hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
        MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
        LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
        SelectObject(hDC, hOldPen);
      }

      // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      /**************************************
      * Legend text
      */
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_ACT_TRANSP_TXT,lstrlen((LPSTR)GL_ACT_TRANSP_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_1,(LPSTR)GL_POT_TRANSP_TXT,lstrlen((LPSTR)GL_POT_TRANSP_TXT));
      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
      //      if (!gbVersionSelect)  DrawAll(PLOTTRANSP, (LPHGRAPH) &s_hGraph, WinRect);
      //      else               
      XDrawAll(PLOTTRANSP, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
      InvalidateRect(hWndDlg, NULL,TRUE);
      break;

    case WM_CLOSE:
      /*
      * force execution of IDCANCEL - Codesection  below!
      */
      PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
      break;

    case WM_HSCROLL:
      break;

    case WM_COMMAND:
      switch(wParam)
      {
        case ID_PRINT:
          //-------<Printer Output PRINT.C>-------
          bPrnDateString=TRUE;
          PrintObject((LPSTR)"PrnTransp");
          bPrnDateString=FALSE;
          //--------------------------------------
          break;
        case ID_Y_SCALE:
          doYScaleDlg(hWndDlg);
          break;
        case ID_X_SCALE:
          doXScaleDlg(hWndDlg);
          break;
        case IDOK:
        case IDCANCEL:
          DestroyHydrIcon();
          lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
          if (lpPPS != NULL)
          {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
          }
          DestroyWindow(hWndDlg);
          eraseDlgPPS(hWndDlg);
          break;
      }
      break;    /* End of WM_COMMAND                                 */

    default:
      return FALSE;
  }
  return TRUE;
}

/***********************************************************************************************
 * Plant :  extern INT_PTR CALLBACK PlotNUptakeProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
 * Graphic - Call Back Procedure
 *
 * C.Sperr
 * 25.04.94
 *
 ***********************************************************************************************
 */

extern INT_PTR CALLBACK PlotNUptakeProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;

 switch (Message)
 {
   case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
     /*
      * adjust coordinate system
      */
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_NUPTAKE;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
        lpPPS->dXmax = PlotDT1Xmax;
        lpPPS->iXdiv = (int)PlotDT1XDiv;
        lpPPS->iXdec= (int) PlotDT1XDec;

        lpPPS->dYmin = 0.0;
        lpPPS->dYmax = 400.0;
        lpPPS->iYdiv = 8;
        lpPPS->iYdec = 1;
      }

      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON, (long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_NUPTAKE_SS_TXT);
      initPlotWndDim(hWndDlg);

      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */


     lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
     GrXmin[PLOTNUPTAKE] =lpPPS->dXmin; // ] = PlotDT1Xmin
     GrXmax[PLOTNUPTAKE] =lpPPS->dXmax; // ] = PlotDT1XMax
     GrXdiv[PLOTNUPTAKE] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
     GrXdec[PLOTNUPTAKE] = lpPPS->iXdec ;  //] = PlotDT1XDec;
     GrYmin[PLOTNUPTAKE] = lpPPS->dYmin;
     GrYmax[PLOTNUPTAKE] = lpPPS->dYmax;
     GrYdiv[PLOTNUPTAKE] = (double)lpPPS->iYdiv;
     GrYdec[PLOTNUPTAKE] = lpPPS->iYdec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;
    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <2;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }

        // Set text style
        hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      /**************************************
       * Legend text
       */
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_NUPTAKE_TXT,lstrlen((LPSTR)GL_NUPTAKE_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_1,(LPSTR)GL_H2OUPTAKE_TXT,lstrlen((LPSTR)GL_H2OUPTAKE_TXT));

      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTNUPTAKE, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTNUPTAKE, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PrnNUptake");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;


           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
        eraseDlgPPS(hWndDlg);
                break;
         }
         break;    /* End of WM_COMMAND                                 */

       default:
           return FALSE;
    }
    return TRUE;


}

/***********************************************************************************************
 * Plant :  extern INT_PTR CALLBACK PlotNConcProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
 * Graphic - Call Back Procedure
 *
 * C.Sperr
 * 25.04.94
 *
 ***********************************************************************************************
 */
extern INT_PTR CALLBACK PlotNConcProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;

 switch (Message)
 {
   case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
     /*
      * adjust coordinate system
      */
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_NCONC;
    lpPPS->bXTimeScale = TRUE;

      lpPPS->dXmin = PlotDT1Xmin;
        lpPPS->dXmax = PlotDT1Xmax;
        lpPPS->iXdiv = (int)PlotDT1XDiv;
        lpPPS->iXdec= (int) PlotDT1XDec;

        lpPPS->dYmin = 0.0;
        lpPPS->dYmax = 5.0;
        lpPPS->iYdiv = 5;
        lpPPS->iYdec = 1;
      }

      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON, (long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_NCONC_SS_TXT);
    initPlotWndDim(hWndDlg);

      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */


     lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
     GrXmin[PLOTNCONC] =lpPPS->dXmin; // ] = PlotDT1Xmin
     GrXmax[PLOTNCONC] =lpPPS->dXmax; // ] = PlotDT1XMax
     GrXdiv[PLOTNCONC] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
     GrXdec[PLOTNCONC] = lpPPS->iXdec ;  //] = PlotDT1XDec;
     GrYmin[PLOTNCONC] = lpPPS->dYmin;
     GrYmax[PLOTNCONC] = lpPPS->dYmax;
     GrYdiv[PLOTNCONC] = (double)lpPPS->iYdiv;
     GrYdec[PLOTNCONC] = lpPPS->iYdec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
 
 // reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;
    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <6;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }

        // Set text style
        hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      /**************************************
       * Legend text
       */
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_CRIT_NCONC_TXT,lstrlen((LPSTR)GL_CRIT_NCONC_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_1,(LPSTR)GL_NCONC_TXT,lstrlen((LPSTR)GL_NCONC_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_2,(LPSTR)GL_NCONC2_TXT,lstrlen((LPSTR)GL_NCONC2_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_3,(LPSTR)GL_NCONC3_TXT,lstrlen((LPSTR)GL_NCONC3_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_4,(LPSTR)GL_NCONC4_TXT,lstrlen((LPSTR)GL_NCONC4_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0+TXT_DY_5,(LPSTR)GL_NCONC5_TXT,lstrlen((LPSTR)GL_NCONC5_TXT));

      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTNCONC, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTNCONC, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PrnNConc");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;


           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
              DestroyWindow(hWndDlg);
        eraseDlgPPS(hWndDlg);
                break;
         }
         break;    /* End of WM_COMMAND                                 */

       default:
           return FALSE;
    }
    return TRUE;


}



/************************************************************************/
/*                                                                      */
/* Plot Window Procedure                                                */
/*          DummyDZ -ARRAY    afDummyDZ[]                               */
/* autor : C.Sperr                                                                         */
/* date  : 01.11.92                                                                        */
/*******************************************************************************************/

/************************************************************************/

extern INT_PTR CALLBACK PlotDummyDZ1Proc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT           WinRect;



   switch (Message)
   {
    case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;

   case WM_INITDIALOG:

       lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
       if (lpPPS !=NULL)
       {
        lpPPS->iIDMenu = IDM_G_DUMMYDZ1;
    lpPPS->bYDepthScale = TRUE;

         lpPPS->dXmin = PlotDZ1Xmin;
         lpPPS->dXmax = PlotDZ1Xmax;
         lpPPS->iXdiv = (int)PlotDZ1XDiv;
         lpPPS->iXdec = PlotDZ1XDec;

         lpPPS->dYmin = PlotDZ1Ymin;
         lpPPS->dYmax = PlotDZ1Ymax;
         lpPPS->iYdiv = (int)PlotDZ1YDiv;
         lpPPS->iYdec = PlotDZ1YDec;
       }

      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON,(long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_DUMMYDZ1_SS_TXT);
    initPlotWndDim(hWndDlg);
      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */

      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);

      GrXmin[PLOTDUMMYDZ1] =lpPPS->dXmin;
      GrXmax[PLOTDUMMYDZ1] =lpPPS->dXmax;
      GrXdiv[PLOTDUMMYDZ1] = (double)lpPPS->iXdiv;
      GrXdec[PLOTDUMMYDZ1] = lpPPS->iXdec;
 /*------- depth dependant   scale parameter  ------------------*/

/* resize if Layer data in file were changed
       *
      lpPPS->dYmin = PlotDZ1Ymin;
      lpPPS->dYmax = PlotDZ1Ymax;
      lpPPS->iYdiv = (int)PlotDZ1YDiv;
      lpPPS->iYdec = PlotDZ1YDec;
*/

      GrYmin[PLOTDUMMYDZ1] = lpPPS->dYmin;
      GrYmax[PLOTDUMMYDZ1] = lpPPS->dYmax;
      GrYdiv[PLOTDUMMYDZ1] = (double)lpPPS->iYdiv;
      GrYdec[PLOTDUMMYDZ1] = lpPPS->iYdec;


      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);

      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;

      for (iColor=0;iColor < 1;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor/**15*/),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor/**15*/));
          SelectObject(hDC, hOldPen);
      }
        // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_DUMMYDZ11_TXT,lstrlen((LPSTR)GL_DUMMYDZ11_TXT));
//      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_DUMMYDZ12_TXT,lstrlen((LPSTR)GL_DUMMYDZ12_TXT));
      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

//      if (!gbVersionSelect)  DrawAll(PLOTDUMMYDZ1, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTDUMMYDZ1, (LPHGRAPH) &s_hGraph, WinRect);

      EndPaint(hWndDlg, &ps);

      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               PrintObject((LPSTR)"PLOTDummyDZ1");
               //--------------------------------------
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;



           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);
                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of DUMMYDZ1Proc                                      */


/********************************************************************************************/
/*                                                                                          */
/* Plot Time Protocoll   Window Procedure                                                   */
/* time dependent graphic: DummyDT - Array  afDummyDT[]                       */
/* autor : C.Sperr                                                                         */
/* date  : 02.02.93                                                                        */
/*******************************************************************************************/

extern INT_PTR CALLBACK PlotDummyDT1Proc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;

 switch (Message)
 {
   case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
     /*
      * adjust coordinate system
      */
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_DUMMYDT1;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
        lpPPS->dXmax = PlotDT1Xmax;
        lpPPS->iXdiv = (int)PlotDT1XDiv;
        lpPPS->iXdec= (int) PlotDT1XDec;

        lpPPS->dYmin = PlotDT1Ymin;
        lpPPS->dYmax = PlotDT1Ymax;
        lpPPS->iYdiv = (int)PlotDT1YDiv;
        lpPPS->iYdec = (int)PlotDT1YDec;
    }

      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON, (long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_DUMMYDT1_SS_TXT);
    initPlotWndDim(hWndDlg);

      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */


     lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
     GrXmin[PLOTDUMMYDT1] =lpPPS->dXmin; // ] = PlotDT1Xmin
     GrXmax[PLOTDUMMYDT1] =lpPPS->dXmax; // ] = PlotDT1XMax
     GrXdiv[PLOTDUMMYDT1] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
     GrXdec[PLOTDUMMYDT1] = lpPPS->iXdec ;  //] = PlotDT1XDec;
     GrYmin[PLOTDUMMYDT1] =  lpPPS->dYmin;
     GrYmax[PLOTDUMMYDT1] =  lpPPS->dYmax;
     GrYdiv[PLOTDUMMYDT1] =  (double)lpPPS->iYdiv;
     GrYdec[PLOTDUMMYDT1] = PlotDT1YDec;

//   GrYmin[PLOTDUMMYDT1] =   0.0;
//   GrYmax[PLOTDUMMYDT1] =  20.0;
//   GrYdiv[PLOTDUMMYDT1] =   4.0;
//   GrYdec[PLOTDUMMYDT1] =     0;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;
    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <6;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }

        // Set text style
        hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      /**************************************
       * Legend text
       */
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_DUMMYDT11_TXT,lstrlen((LPSTR)GL_DUMMYDT11_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_DUMMYDT12_TXT,lstrlen((LPSTR)GL_DUMMYDT12_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)GL_DUMMYDT13_TXT,lstrlen((LPSTR)GL_DUMMYDT13_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)GL_DUMMYDT14_TXT,lstrlen((LPSTR)GL_DUMMYDT14_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_4,(LPSTR)GL_DUMMYDT15_TXT,lstrlen((LPSTR)GL_DUMMYDT15_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_5,(LPSTR)GL_DUMMYDT16_TXT,lstrlen((LPSTR)GL_DUMMYDT16_TXT));

      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTDUMMYDT1, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTDUMMYDT1, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PLOTDummyDT1");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;


           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
              DestroyWindow(hWndDlg);
        eraseDlgPPS(hWndDlg);
                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotDummyDT1Proc ===============================  */

/**************************************************************************************
 *
 * Plot Window Procedure
 *         second  DummyDZ2 -ARRAY    afDummyDZ2[]
 * autor : C.Sperr
 * date  : 25.11.93
 ***************************************************************************************/

/************************************************************************/

extern INT_PTR CALLBACK PlotDummyDZ2Proc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT           hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;

   switch (Message)
   {
    case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;

   case WM_INITDIALOG:

       lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
       if (lpPPS !=NULL)
       {
        lpPPS->iIDMenu = IDM_G_DUMMYDZ2;
    lpPPS->bXTimeScale = TRUE;

         lpPPS->dXmin = PlDZ2Xmin;
         lpPPS->dXmax = PlDZ2Xmax;
         lpPPS->iXdiv = (int)PlDZ2Xdiv;
         lpPPS->iXdec = PlotDZ2XDec;
  
     lpPPS->dYmin = PlotDZ2Ymin;
         lpPPS->dYmax = PlotDZ2Ymax;
         lpPPS->iYdiv = (int)PlotDZ2YDiv;
         lpPPS->iYdec = PlotDZ2YDec;
       }
      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON,(long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_DUMMYDZ2_SS_TXT);
      initPlotWndDim(hWndDlg);
    break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */

      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);

      /* resize if Layer data in file were changed
       *
      lpPPS->dYmin = PlotDZ2Ymin;
      lpPPS->dYmax = PlotDZ2Ymax;
      lpPPS->iYdiv = (int)PlotDZ2YDiv;
      lpPPS->iYdec = PlotDZ2YDec;
*******************/
      GrXmin[PLOTDUMMYDZ2] =  lpPPS->dXmin;
      GrXmax[PLOTDUMMYDZ2] =  lpPPS->dXmax;
      GrXdiv[PLOTDUMMYDZ2] =  (double)lpPPS->iXdiv;
      GrXdec[PLOTDUMMYDZ2] =  PlDZ2Xdec;
 /*------- depth dependant   scale parameter  ------------------*/
      GrYmin[PLOTDUMMYDZ2] = lpPPS->dYmin;
      GrYmax[PLOTDUMMYDZ2] = lpPPS->dYmax;
      GrYdiv[PLOTDUMMYDZ2] = (double)lpPPS->iYdiv;
      GrYdec[PLOTDUMMYDZ2] = lpPPS->iYdec;


      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);

      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;

    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <1;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC,LEGEND_X0,     (LEGEND_Y0 + iColor),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor));
          SelectObject(hDC, hOldPen);
      }

      // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_DUMMYDZ21_TXT,lstrlen((LPSTR)GL_DUMMYDZ21_TXT));
//      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_DUMMYDZ22_TXT,lstrlen((LPSTR)GL_DUMMYDZ22_TXT));

      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

//      if (!gbVersionSelect)  DrawAll(PLOTDUMMYDZ2, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTDUMMYDZ2, (LPHGRAPH) &s_hGraph, WinRect);

      EndPaint(hWndDlg, &ps);

      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               PrintObject((LPSTR)"PLOTDummyDZ2");
               //--------------------------------------
                break;

            case ID_X_SCALE:

                 doXScaleDlg(hWndDlg);
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;



           case IDOK:
           case IDCANCEL:   
          DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
        eraseDlgPPS(hWndDlg);
                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of DUMMYDZ2Proc                                      */


/********************************************************************************************
 *
 * Plot Time Protocoll   Window Procedure
 * time dependent graphic: DummyDT2 - Array  afDummyDT2[]
 * autor : C.Sperr
 * date  : 25.11.93
 *******************************************************************************************/

extern INT_PTR CALLBACK PlotDummyDT2Proc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;

 switch (Message)
 {
    case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:

       lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
       if (lpPPS !=NULL)
       {
        lpPPS->iIDMenu = IDM_G_DUMMYDT2;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
        lpPPS->dXmax = PlotDT1Xmax;
        lpPPS->iXdiv = (int)PlotDT1XDiv;
        lpPPS->iXdec = (int)PlotDT1XDec;


         lpPPS->dYmin =      PlotDT2Ymin;
         lpPPS->dYmax =      PlotDT2Ymax;
         lpPPS->iYdiv = (int)PlotDT2YDiv;
         lpPPS->iYdec = (int)PlotDT2YDec;

       }
      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON,(long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_DUMMYDT2_SS_TXT);
    initPlotWndDim(hWndDlg);
      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */

     lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
     GrYmin[PLOTDUMMYDT2] =          lpPPS->dYmin;
     GrYmax[PLOTDUMMYDT2] =          lpPPS->dYmax;
     GrYdiv[PLOTDUMMYDT2] =  (double)lpPPS->iYdiv;
     GrYdec[PLOTDUMMYDT2] =          lpPPS->iYdec;
     GrXmin[PLOTDUMMYDT2] =           lpPPS->dXmin; //PlotDT2Xmin;
     GrXmax[PLOTDUMMYDT2] =           lpPPS->dXmax; //PlotDT2Xmax;
     GrXdiv[PLOTDUMMYDT2] =  (double) lpPPS->iXdiv; //PlotDT2XDiv;
     GrXdec[PLOTDUMMYDT2] =           lpPPS->iXdec; //dPlotDT2XDec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;

    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <6;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }

        // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_DUMMYDT21_TXT,lstrlen((LPSTR)GL_DUMMYDT21_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_DUMMYDT22_TXT,lstrlen((LPSTR)GL_DUMMYDT22_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)GL_DUMMYDT23_TXT,lstrlen((LPSTR)GL_DUMMYDT23_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)GL_DUMMYDT24_TXT,lstrlen((LPSTR)GL_DUMMYDT24_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_4,(LPSTR)GL_DUMMYDT25_TXT,lstrlen((LPSTR)GL_DUMMYDT25_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_5,(LPSTR)GL_DUMMYDT26_TXT,lstrlen((LPSTR)GL_DUMMYDT26_TXT));

      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
      XDrawAll(PLOTDUMMYDT2, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
           case ID_PRINT:
           //-------<Printer Output PRINT.C>-------
              bPrnDateString=TRUE;
              PrintObject((LPSTR)"PLOTDummyDT2");
              bPrnDateString=FALSE;
           //--------------------------------------
               break;
           case ID_Y_SCALE:
               doYScaleDlg(hWndDlg);
            break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;


           case IDOK:
           case IDCANCEL:   
         DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
             DestroyWindow(hWndDlg);
         eraseDlgPPS(hWndDlg);
             break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotDummyDT2Proc ===============================  */


/************************************************************************/
/*                                                                      */
/* Plot Window Procedure                                                */
/*          Nitrogen                                                    */
/* autor : C.Sperr                                                      */
/* date  : 01.03.93                                                     */
/************************************************************************/

/************************************************************************/

extern INT_PTR CALLBACK PlotNitroDZProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT           WinRect;

   switch (Message)
   {
    case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_NITRODZ;
    lpPPS->bYDepthScale = TRUE;

        lpPPS->dXmin =        0.0;
        lpPPS->dXmax =       20.0;
        lpPPS->iXdiv =   (int)4.0;
        lpPPS->iXdec =        0;

        lpPPS->dYmin =  PlotDZ1Ymin;
        lpPPS->dYmax =  PlotDZ1Ymax;
        lpPPS->iYdiv = (int) PlotDZ1YDiv;
        lpPPS->iYdec =  PlotDZ1YDec;
      }

      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON,(long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_NO3DZ_SS_TXT);
    initPlotWndDim(hWndDlg);
      
    break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */

      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);

      /*
       * resize if file content was changed
       
        lpPPS->dYmin =  PlotDZ1Ymin;
        lpPPS->dYmax =  PlotDZ1Ymax;
        lpPPS->iYdiv = (int) PlotDZ1YDiv;
        lpPPS->iYdec =  PlotDZ1YDec;
081297*****************************/
      GrXmin[PLOTNITRODZ] =  lpPPS->dXmin;
      GrXmax[PLOTNITRODZ] =  lpPPS->dXmax;
      GrXdiv[PLOTNITRODZ] =  lpPPS->iXdiv;
      GrXdec[PLOTNITRODZ] =  lpPPS->iXdec;
      GrYmin[PLOTNITRODZ] =  lpPPS->dYmin;
      GrYmax[PLOTNITRODZ] =  lpPPS->dYmax;
      GrYdiv[PLOTNITRODZ] =  lpPPS->iYdiv;
      GrYdec[PLOTNITRODZ] =  lpPPS->iYdec;

      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      hDC = BeginPaint(hWndDlg, &ps);
      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;

      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <2;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }


      for (iColor=1;iColor <2;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + TXT_DY_1 + iColor),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + TXT_DY_1 + iColor));
          SelectObject(hDC, hOldPen);
      }

      // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_NO3_DZ1_TXT,lstrlen((LPSTR)GL_NO3_DZ1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_NO3_DZ2_TXT,lstrlen((LPSTR)GL_NO3_DZ2_TXT));

      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;


//      if (!gbVersionSelect)  DrawAll(PLOTNITRODZ, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTNITRODZ, (LPHGRAPH) &s_hGraph, WinRect);

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               PrintObject((LPSTR)"PLOTNITRODZ");
               //--------------------------------------
               break;
           case ID_X_SCALE:
                doXScaleDlg(hWndDlg);
             break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;



           case IDOK:
           case IDCANCEL:

                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
              DestroyWindow(hWndDlg);
        eraseDlgPPS(hWndDlg);
                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of NitroDZProc                                      */


/********************************************************************************************/
/*                                                                                          */
/* Plot Time Protocoll   Window Procedure                                                   */
/* time dependent  nitrogen  */
/* autor : C.Sperr                                                                         */
/* date  : 01.03.93                                                                        */
/*******************************************************************************************/

extern INT_PTR CALLBACK PlotNitroDTProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT           WinRect;

 switch (Message)
 {
    case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_NITRODT;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
        lpPPS->dXmax = PlotDT1Xmax;
        lpPPS->iXdiv = (int)PlotDT1XDiv;
        lpPPS->iXdec = (int)PlotDT1XDec;

        lpPPS->dYmin =    0.0;
        lpPPS->dYmax =  200.0;
        lpPPS->iYdiv =    10;
        lpPPS->iYdec =    1;
      }

      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON,(long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_NO3DT_SS_TXT);
    initPlotWndDim(hWndDlg);

      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */

      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */

      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
      GrXmin[PLOTNITRODT] =lpPPS->dXmin; // ] = PlotDT1Xmin
      GrXmax[PLOTNITRODT] =lpPPS->dXmax; // ] = PlotDT1XMax
      GrXdiv[PLOTNITRODT] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
      GrXdec[PLOTNITRODT] = lpPPS->iXdec ;  //] = PlotDT1XDec;
      GrYmin[PLOTNITRODT] = lpPPS->dYmin;
      GrYmax[PLOTNITRODT] = lpPPS->dYmax;
      GrYdiv[PLOTNITRODT] = (double)lpPPS->iYdiv;
      GrYdec[PLOTNITRODT] = lpPPS->iYdec;

      hDC = BeginPaint(hWndDlg, &ps);
      GetClientRect(hWndDlg,(LPRECT)&WinRect);

      SelectObject(hDC, GetStockObject(BLACK_PEN));

      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;

      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor < 5;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }


        // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_NO3_SCH0_TXT,lstrlen((LPSTR)GL_NO3_SCH0_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_NO3_SCH1_TXT,lstrlen((LPSTR)GL_NO3_SCH1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)GL_NO3_SCH2_TXT,lstrlen((LPSTR)GL_NO3_SCH2_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)GL_NO3_SCH3_TXT,lstrlen((LPSTR)GL_NO3_SCH3_TXT));
     /****************
      * cs / 31.03.94    ch, 11.6.97 ???? */
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_4,(LPSTR)GL_NO3_SCH4_TXT,lstrlen((LPSTR)GL_NO3_SCH4_TXT));
      /*
      *****************/
      SelectObject(hDC,hOldFont);

     // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTNITRODT, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTNITRODT, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
           case ID_PRINT:

               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PLOTNTRODT");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;

           case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;



           case IDOK:
           case IDCANCEL:   
          DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
              DestroyWindow(hWndDlg);
        eraseDlgPPS(hWndDlg);
       break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotNitroDTProc ===============================  */
/********************************************************************************************/
/*                                                                                          */
/* Plot Time Protocoll   Window Procedure                                                   */
/* time dependent  nitrogen  transformation/nitrogen flow */
/* autor : C.Sperr                                                                         */
/* date  : 01.03.93                                                                        */
/*******************************************************************************************/

extern INT_PTR CALLBACK PlotNitroTRProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT           WinRect;

 switch (Message)
 {
    case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_NITROTR;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
        lpPPS->dXmax = PlotDT1Xmax;
        lpPPS->iXdiv = (int)PlotDT1XDiv;
        lpPPS->iXdec = (int)PlotDT1XDec;

        lpPPS->dYmin =    0.0;
        lpPPS->dYmax =    1.0;
        lpPPS->iYdiv =    5;
        lpPPS->iYdec  =   2;
      }

      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON,(long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_NO3TRANS_SS_TXT);
    initPlotWndDim(hWndDlg);

      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */

      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);

      GrXmin[PLOTNITROTR] =lpPPS->dXmin; // ] = PlotDT1Xmin
      GrXmax[PLOTNITROTR] =lpPPS->dXmax; // ] = PlotDT1XMax
      GrXdiv[PLOTNITROTR] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
      GrXdec[PLOTNITROTR] = lpPPS->iXdec ;  //] = lpPPS->iXdec ;  //] = PlotDT1XDec;
      GrYmin[PLOTNITROTR] = lpPPS->dYmin;
      GrYmax[PLOTNITROTR] = lpPPS->dYmax;
      GrYdiv[PLOTNITROTR] = (double)lpPPS->iYdiv;
      GrYdec[PLOTNITROTR] = lpPPS->iYdec;

      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      hDC = BeginPaint(hWndDlg, &ps);
      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));

      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;

      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);
     /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <6;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }


        // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_HARNST_TRANS_TXT,lstrlen((LPSTR)GL_HARNST_TRANS_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_FREE_OS_TXT,  lstrlen((LPSTR)GL_FREE_OS_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)GL_FREE_HUM_TXT, lstrlen((LPSTR)GL_FREE_HUM_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)GL_NITR_TXT,     lstrlen((LPSTR)GL_NITR_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_4,(LPSTR)GL_DENITR_TXT,   lstrlen((LPSTR)GL_DENITR_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_5,(LPSTR)GL_IMMOB_TXT,    lstrlen((LPSTR)GL_IMMOB_TXT));

      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;


      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTNITROTR, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTNITROTR, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;


      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PLOTNITROTR");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;

           case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;


           case IDOK:
           case IDCANCEL:   DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
              DestroyWindow(hWndDlg);
        eraseDlgPPS(hWndDlg);
                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotNitroTRProc ===============================  */

/********************************************************************************************/
/*                                                                                          */
/* Plot Time Protocoll   Window Procedure                                                   */
/* time dependent graphic: nitrogen balance :   afNitroBalDT[]                       */
/* autor : C.Sperr                                                                         */
/* date  : 13.05.93                                                                        */
/*******************************************************************************************/

extern INT_PTR CALLBACK PlotNitroCumProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT           WinRect;

 switch (Message)
 {
    case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_NITROCUM;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
        lpPPS->dXmax = PlotDT1Xmax;
        lpPPS->iXdiv = (int)PlotDT1XDiv;
        lpPPS->iXdec = (int)PlotDT1XDec;

        lpPPS->dYmin =    0.0;
        lpPPS->dYmax =  150.0;
        lpPPS->iYdiv =    5;
    lpPPS->iXdec = (int)PlotDT1YDec;
      }

      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON,(long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_NBALANCE_SS_TXT);
    initPlotWndDim(hWndDlg);
      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */

      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
      GrXmin[PLOTNITROCUM] =lpPPS->dXmin; // ] = PlotDT1Xmin
      GrXmax[PLOTNITROCUM] =lpPPS->dXmax; // ] = PlotDT1XMax
      GrXdiv[PLOTNITROCUM] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
      GrXdec[PLOTNITROCUM] = lpPPS->iXdec ;  //] = lpPPS->iXdec ;  //] = PlotDT1XDec;
      GrYmin[PLOTNITROCUM] = lpPPS->dYmin;
      GrYmax[PLOTNITROCUM] = lpPPS->dYmax;
      GrYdiv[PLOTNITROCUM] = (double)lpPPS->iYdiv;
      GrYdec[PLOTNITROCUM] =     1;

      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      hDC = BeginPaint(hWndDlg, &ps);
      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));

      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;

      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);
    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <5;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }


        // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_NO3_AW_TXT, lstrlen((LPSTR)GL_NO3_AW_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_NO3_MIN_TXT,lstrlen((LPSTR)GL_NO3_MIN_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)GL_NO3_DEN_TXT,lstrlen((LPSTR)GL_NO3_DEN_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)GL_NO3_NIT_TXT,lstrlen((LPSTR)GL_NO3_NIT_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_4,(LPSTR)GL_NO3_IMM_TXT,lstrlen((LPSTR)GL_NO3_IMM_TXT));


      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTNITROCUM, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTNITROCUM, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;


      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PLOTNITROCUM");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;

           case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;



           case IDOK:
           case IDCANCEL:   DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
              DestroyWindow(hWndDlg);
        eraseDlgPPS(hWndDlg);

                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }

   return TRUE;
} /* End of PlotNitroCumProc ===============================  */


/********************************************************************************************/
/*                                                                                          */
/* Plot Time Protocoll   Window Procedure                                                   */
/* time dependent graphic: temperature     of different soil layers                         */
/* autor : C.Sperr                                                                         */
/* date  : 28.01.93                                                                        */
/*******************************************************************************************/

extern INT_PTR CALLBACK PlotSoilTempProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH         s_hGraph;
 RECT            WinRect;

   switch (Message)
   {
    case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_TEMPHT;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
        lpPPS->dXmax = PlotDT1Xmax;
        lpPPS->iXdiv = (int)PlotDT1XDiv;
        lpPPS->iXdec = (int)PlotDT1XDec;

        lpPPS->dYmin =  -10.0;
        lpPPS->dYmax =   40.0;
        lpPPS->iYdiv =    5;
    lpPPS->iYdec =  (int)PlotDT1YDec;
      }

      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON,(long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_SOILTEMPDT_SS_TXT);
    initPlotWndDim(hWndDlg);
      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */

      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);

      GrXmin[PLOTSOILTEMP] = lpPPS->dXmin ;  //] = PlotDT1Xmin;
      GrXmax[PLOTSOILTEMP] = lpPPS->dXmax ;  //] = PlotDT1Xmax;
      GrXdiv[PLOTSOILTEMP] = (double)lpPPS->iXdiv ;  //] = PlotDT1XDiv;
      GrXdec[PLOTSOILTEMP] =  lpPPS->iXdec ;  //PlotDT1XDec;
      GrYmin[PLOTSOILTEMP]   = lpPPS->dYmin;
      GrYmax[PLOTSOILTEMP]   = lpPPS->dYmax;
      GrYdiv[PLOTSOILTEMP]   = (double)lpPPS->iYdiv;
      GrYdec[PLOTSOILTEMP]   =   0;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */

      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn
      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;

      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);


    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor < 4;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }


        // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_SOILTEMPDT1_TXT,lstrlen((LPSTR)GL_SOILTEMPDT1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_SOILTEMPDT2_TXT,lstrlen((LPSTR)GL_SOILTEMPDT2_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)GL_SOILTEMPDT3_TXT,lstrlen((LPSTR)GL_SOILTEMPDT3_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)GL_SOILTEMPDT4_TXT,lstrlen((LPSTR)GL_SOILTEMPDT4_TXT));

      SelectObject(hDC,hOldFont);
      // Screen font

     // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTSOILTEMP, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTSOILTEMP, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;


      EndPaint(hWndDlg, &ps);




      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
           case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PLOTSoilTemp");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;


           case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;



           case IDOK:
           case IDCANCEL:   DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
              DestroyWindow(hWndDlg);
        eraseDlgPPS(hWndDlg);

                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotSoilTemp ===============================  */


/********************************************************************************************/
/*                                                                                          */
/* Plot Time Protocoll   Window Procedure                                                   */
/* time dependent graphic                                                                   */
/* autor : C.Sperr                                                                         */
/* date  : 01.11.92                                                                        */
/*******************************************************************************************/

extern INT_PTR CALLBACK PlotMsgProc22( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH         s_hGraph;
 RECT            WinRect;

   switch (Message)
   {
    case WM_ERASEBKGND:

       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:

      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_THT;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
        lpPPS->dXmax = PlotDT1Xmax;
        lpPPS->iXdiv = (int)PlotDT1XDiv;
        lpPPS->iXdec = (int)PlotDT1XDec;

        lpPPS->dYmin =    10.0;
        lpPPS->dYmax =    60.0;
        lpPPS->iYdiv =    5;
        lpPPS->iYdec = (int)PlotDT1YDec;
      }
    
      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON,(long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_H2ODT_SS_TXT);
    initPlotWndDim(hWndDlg);
      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */

      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
      GrXmin[PLOT22] = lpPPS->dXmin ;  //] = PlotDT1Xmin;
      GrXmax[PLOT22] = lpPPS->dXmax ;  //] = PlotDT1Xmax;
      GrXdiv[PLOT22] = (double)lpPPS->iXdiv ;  //] = PlotDT1XDiv;
      GrXdec[PLOT22] = lpPPS->iXdec;  //] = PlotDT1XDec;
      GrYmin[PLOT22] =  lpPPS->dYmin;
      GrYmax[PLOT22] =  lpPPS->dYmax;
      GrYdiv[PLOT22] =  (double)lpPPS->iYdiv;
      GrYdec[PLOT22] =  2;



      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */

      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn
      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;

      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

    /****************************************
     * paint color lines for legend
     */
      for (iColor=0;iColor < 4;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }


        // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_H2ODT1_TXT,lstrlen((LPSTR)GL_H2ODT1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_H2ODT2_TXT,lstrlen((LPSTR)GL_H2ODT2_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)GL_H2ODT3_TXT,lstrlen((LPSTR)GL_H2ODT3_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)GL_H2ODT4_TXT,lstrlen((LPSTR)GL_H2ODT4_TXT));


      SelectObject(hDC,hOldFont);

           // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOT22, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOT22, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);




      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
          case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString = TRUE;
               PrintObject((LPSTR)"PLOT22");
               bPrnDateString = FALSE;
               //--------------------------------------
               break;

           case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;



           case IDOK:
           case IDCANCEL:   DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
              DestroyWindow(hWndDlg);
        eraseDlgPPS(hWndDlg);

                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotMsgProc22 ===============================  */


/************************************************************************/
/*                                                                      */
/* Plot Time Protocoll   Window Procedure                          */
/* time dependent graphic    irrigation                             */
/* autor : C.Sperr                                                                         */
/* date  : 01.11.92                                                                        */
/*******************************************************************************************/

/************************************************************************/

extern INT_PTR CALLBACK PlotMsgProc55( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
  static HGRAPH  s_hGraph;
  HDC            hDC;
  PAINTSTRUCT    ps;
  HPEN           hOldPen;
  HFONT          hOldFont;
  RECT           WinRect;

  switch (Message)
  {
    case WM_ERASEBKGND:
      s_hGraph.bRedraw = TRUE;
      return FALSE;

    case WM_INITDIALOG:
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_NDT;
        lpPPS->bXTimeScale = TRUE;
        lpPPS->dXmin = PlotDT1Xmin;
        lpPPS->dXmax = PlotDT1Xmax;
        lpPPS->iXdiv = (int)PlotDT1XDiv;
        lpPPS->iXdec = (int)PlotDT1XDec;
        lpPPS->dYmin = -10.0;
        lpPPS->dYmax = 40.0;
        lpPPS->iYdiv = 5;
        lpPPS->iYdec = (int)PlotDT1YDec;
      }
      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON,(long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
      SetWindowText(hWndDlg,PRECIPIT_TXT);
      initPlotWndDim(hWndDlg);
      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */
      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
      GrXmin[PLOT55] = lpPPS->dXmin;  //] =   PlotDT1Xmin;
      GrXmax[PLOT55] = lpPPS->dXmax ;  //] = PlotDT1Xmax;
      GrXdiv[PLOT55] = (double)lpPPS->iXdiv;  // = (int)PlotDT1XDiv;
      GrXdec[PLOT55] = lpPPS->iXdec; // PlotDT1XDec;
      GrYmin[PLOT55] = lpPPS->dYmin;
      GrYmax[PLOT55] = lpPPS->dYmax;
      GrYdiv[PLOT55] = (double)lpPPS->iYdiv;
      GrYdec[PLOT55] = 1;

      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */

      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
      // reposition legend and buttons    
      resetLegendAndButtons(hWndDlg,2); 

      // range where coordinate system is drawn
      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;

      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      /****************************************
      * paint color lines for legend
      */

      for (iColor=0;iColor <2;iColor++)
      {
        hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
        MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
        LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
        SelectObject(hDC, hOldPen);
      }

      // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_H2OBAL1_TXT,lstrlen((LPSTR)GL_H2OBAL1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_H2OBAL2_TXT,lstrlen((LPSTR)GL_H2OBAL2_TXT));

      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
      //      if (!gbVersionSelect)  DrawAll(PLOT55, (LPHGRAPH) &s_hGraph, WinRect);
      //      else               
      XDrawAll(PLOT55, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
      InvalidateRect(hWndDlg, NULL,TRUE);
      break;

    case WM_CLOSE:
      /*
      * force execution of IDCANCEL - Codesection  below!
      */
      PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
      break;

    case WM_HSCROLL:
      break;

    case WM_COMMAND:
      switch(wParam)
      {
        case ID_PRINT:
          //-------<Printer Output PRINT.C>-------
          bPrnDateString=TRUE;
          PrintObject((LPSTR)"PLOT55");
          bPrnDateString=FALSE;
          //--------------------------------------
          break;
        case ID_Y_SCALE:
          doYScaleDlg(hWndDlg);
          break;
        case ID_X_SCALE:
          doXScaleDlg(hWndDlg);
          break;
        case IDOK:
        case IDCANCEL:
          DestroyHydrIcon();
          lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
           if (lpPPS != NULL)
           {
             SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
           }
           DestroyWindow(hWndDlg);
           eraseDlgPPS(hWndDlg);
           break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
      return FALSE;
  }
  return TRUE;

} // PlotMsgProc55

/************************************************************************/
/*                                                                      */
/* Plot Time Protocoll   Window Procedure                          */
/* time dependent graphic    runoff                            */
/* autor : C.Sperr                                                                         */
/* date  : 01.11.92                                                                        */
/*******************************************************************************************/


/************************************************************************/

extern INT_PTR CALLBACK PlotMsgProc66( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
HDC            hDC;
PAINTSTRUCT    ps;
HPEN           hOldPen;
HFONT          hOldFont;
static HGRAPH         s_hGraph;
RECT            WinRect;

   switch (Message)
   {
    case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_ADT;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
        lpPPS->dXmax = PlotDT1Xmax;
        lpPPS->iXdiv = (int)PlotDT1XDiv;
        lpPPS->iXdec = (int)PlotDT1XDec;

        lpPPS->dYmin =    0.0;
        lpPPS->dYmax =   40.0;
        lpPPS->iYdiv =    4;
        lpPPS->iYdec = (int)PlotDT1YDec;
      }
      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON,(long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_H2OINFIL_SS_TXT);
    initPlotWndDim(hWndDlg);
      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */

      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
      GrXmin[PLOT66] = lpPPS->dXmin;  //] =   PlotDT1Xmin;
      GrXmax[PLOT66] = lpPPS->dXmax ;  //] = PlotDT1Xmax;
      GrXdiv[PLOT66] = (double)lpPPS->iXdiv; // = (int)PlotDT1XDiv;
      GrXdec[PLOT66] =  lpPPS->iXdec;//  PlotDT1XDec;
      GrYmin[PLOT66] =   lpPPS->dYmin;
      GrYmax[PLOT66] =   lpPPS->dYmax;
      GrYdiv[PLOT66] =   (double)lpPPS->iYdiv;
      GrYdec[PLOT66] =    1;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */

      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn
      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;

      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);
    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <2;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }


        // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_H2OINFIL1_TXT,lstrlen((LPSTR)GL_H2OINFIL1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_H2OINFIL2_TXT,lstrlen((LPSTR)GL_H2OINFIL2_TXT));

      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOT66, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOT66, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);




      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
           case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PLOT66");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;

           case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;


           case IDOK:
           case IDCANCEL:   DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
              DestroyWindow(hWndDlg);
        eraseDlgPPS(hWndDlg);

                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotMsgProc66 ===============================  */


/************************************************************************/
/*                                                                      */
/* Plot Time Protocoll   Window Procedure                          */
/* time dependent graphic    evaporation                              */
/* autor : C.Sperr                                                                         */
/* date  : 01.11.92                                                                        */
/*******************************************************************************************/


/************************************************************************/

extern INT_PTR CALLBACK PlotMsgProc77( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
HDC            hDC;
PAINTSTRUCT    ps;
HPEN           hOldPen;
HFONT          hOldFont;
static HGRAPH         s_hGraph;
RECT            WinRect;

   switch (Message)
   {
    case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_EDT;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
        lpPPS->dXmax = PlotDT1Xmax;
        lpPPS->iXdiv = (int)PlotDT1XDiv;
        lpPPS->iXdec = (int)PlotDT1XDec;

        lpPPS->dYmin =    0.0;
        lpPPS->dYmax =  800.0;
        lpPPS->iYdiv =    8;
        lpPPS->iYdec = (int)PlotDT1YDec;
      }

      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON,(long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_H2OCUMBAL_SS_TXT);
    initPlotWndDim(hWndDlg);
      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */

      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
      GrXmin[PLOT77] = lpPPS->dXmin;  //] =   PlotDT1Xmin;
      GrXmax[PLOT77] = lpPPS->dXmax ;  //] = PlotDT1Xmax;
      GrXdiv[PLOT77] = (double)lpPPS->iXdiv;// = (int)PlotDT1XDiv;
      GrXdec[PLOT77] =   lpPPS->iXdec;
      GrYmin[PLOT77] =   lpPPS->dYmin;
      GrYmax[PLOT77] =   lpPPS->dYmax;
      GrYdiv[PLOT77] =   (double)lpPPS->iYdiv;
      GrYdec[PLOT77] =    lpPPS->iYdec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */

      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

    WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;

      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor < 6;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }

        // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_H2OCUMBAL1_TXT,lstrlen((LPSTR)GL_H2OCUMBAL1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_H2OCUMBAL2_TXT,lstrlen((LPSTR)GL_H2OCUMBAL2_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)GL_H2OCUMBAL3_TXT,lstrlen((LPSTR)GL_H2OCUMBAL3_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)GL_H2OCUMBAL4_TXT,lstrlen((LPSTR)GL_H2OCUMBAL4_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_4,(LPSTR)GL_H2OCUMBAL5_TXT,lstrlen((LPSTR)GL_H2OCUMBAL5_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_5,(LPSTR)GL_H2OCUMBAL6_TXT,lstrlen((LPSTR)GL_H2OCUMBAL6_TXT));


      SelectObject(hDC,hOldFont);

     // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOT77, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOT77, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);




      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
           case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PLOT77");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;

           case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;



           case IDOK:
           case IDCANCEL:   DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);
                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotMsgProc77 ===============================  */


/************************************************************************/
/*                                                                      */
/* Plot Window Procedure                                                */
/*              water content dependent on depth increments             */
/* autor : C.Sperr                                                                         */
/* date  : 01.11.92                                                                        */
/*******************************************************************************************/

/************************************************************************/

extern INT_PTR CALLBACK PlotMsgProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT           WinRect;

   switch (Message)
   {
    case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;

   case WM_INITDIALOG:

       lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
       if (lpPPS !=NULL)
       {
         lpPPS->iIDMenu = IDM_G_THZ;
    lpPPS->bYDepthScale = TRUE;

         lpPPS->dXmin = 10.0;  //PlotDZ1Xmin;
         lpPPS->dXmax = 50.0;  //PlotDZ1Xmax;
         lpPPS->iXdiv = 4;    //(int)PlotDZ1XDiv;
         lpPPS->iXdec = 1;  //(int)PlotDZ1XDec;
         lpPPS->dYmin =  PlotDZ1Ymin;
         lpPPS->dYmax =  PlotDZ1Ymax;
         lpPPS->iYdiv = (int) PlotDZ1YDiv;
         lpPPS->iYdec =  PlotDZ1YDec;

       }



      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON,(long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_H2ODZ_SS_TXT);
    initPlotWndDim(hWndDlg);
      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */

      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);

      /*  resize
       */
/*
      lpPPS->dYmin =  PlotDZ1Ymin;
      lpPPS->dYmax =  PlotDZ1Ymax;
      lpPPS->iYdiv = (int) PlotDZ1YDiv;
      lpPPS->iYdec =  PlotDZ1YDec;
*/
      GrXmin[PLOTMSG] =  lpPPS->dXmin;
      GrXmax[PLOTMSG] =  lpPPS->dXmax;
      GrXdiv[PLOTMSG] =  (double)lpPPS->iXdiv;
      GrXdec[PLOTMSG] =  lpPPS->iXdec;
      GrYmin[PLOTMSG] =  lpPPS->dYmin;
      GrYmax[PLOTMSG] =  lpPPS->dYmax;
      GrYdiv[PLOTMSG] =  (double)lpPPS->iYdiv;
      GrYdec[PLOTMSG] =  lpPPS->iYdec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */

      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;

      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor < 2;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }


      for (iColor=1;iColor < 2;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + TXT_DY_1 + iColor),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + TXT_DY_1 + iColor));
          SelectObject(hDC, hOldPen);
      }

     // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_H2ODZ1_TXT,lstrlen((LPSTR)GL_H2ODZ1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_H2ODZ2_TXT,lstrlen((LPSTR)GL_H2ODZ2_TXT));

      SelectObject(hDC,hOldFont);

     // open graph, and plot the grid
      s_hGraph.hDC  = hDC;
      bDateString = FALSE;
//      if (!gbVersionSelect)  DrawAll(PLOTMSG, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTMSG, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString = FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
          case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               PrintObject((LPSTR)"PLOTMsg");
               //--------------------------------------
             break;
           case ID_X_SCALE:
                doXScaleDlg(hWndDlg);
             break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;



           case IDOK:
           case IDCANCEL:   DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);

             break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotMsgProc                                      */

/*******************************************************************************************
 *
 *   Plot Window Procedure  to show  temperature distribution over the  soil profile
 *
 * autor : C.Sperr
 * date  : 22.01.93
 *******************************************************************************************
 */

extern INT_PTR CALLBACK PlotSoilMsgProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
HDC            hDC;
PAINTSTRUCT    ps;
HPEN           hOldPen;
HFONT          hOldFont;
static HGRAPH         s_hGraph;
RECT            WinRect;


   switch (Message)
   {
    case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:

       lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
       if (lpPPS !=NULL)
       {
          lpPPS->iIDMenu = IDM_G_TEMPHZ;
    lpPPS->bYDepthScale = TRUE;

          lpPPS->dXmin          = -10.0;
          lpPPS->dXmax          =  40.0;
          lpPPS->iXdiv          =   5;
          lpPPS->iXdec          =   1;
          lpPPS->dYmin          =       PlotDZ1Ymin;
          lpPPS->dYmax          =       PlotDZ1Ymax;
          lpPPS->iYdiv          =  (int)PlotDZ1YDiv;
          lpPPS->iYdec          =       PlotDZ1YDec;
       }
       else   MessageBox(NULL,"AddPPSMember failed",NULL,MB_ICONSTOP);

      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON,(long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_SOILTEMPDZ_SS_TXT);
    initPlotWndDim(hWndDlg);

      break;      /*  End of WM_INITDIALOG */

   case WM_PAINT: /* code for the window's client area */

      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
      /*
       * necessary if layer No in datafile was changed during life cycle of ExpertN
       *
      lpPPS->dYmin          =       PlotDZ1Ymin;
      lpPPS->dYmax          =       PlotDZ1Ymax;
      lpPPS->iYdiv          =  (int)PlotDZ1YDiv;
      lpPPS->iYdec          =       PlotDZ1YDec;

*/
      GrXmin[PLOTSOILMSG] =  lpPPS->dXmin;
      GrXmax[PLOTSOILMSG] =  lpPPS->dXmax;
      GrXdiv[PLOTSOILMSG] =  (double)lpPPS->iXdiv;
      GrXdec[PLOTSOILMSG] =  lpPPS->iXdec;
      GrYmin[PLOTSOILMSG] =  lpPPS->dYmin;
      GrYmax[PLOTSOILMSG] =  lpPPS->dYmax;
      GrYdiv[PLOTSOILMSG] =  (double)lpPPS->iYdiv;
      GrYdec[PLOTSOILMSG] =  lpPPS->iYdec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */

      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;

      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);
    /****************************************
     * paint color lines for legend
     */
      for (iColor=0;iColor <2;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }



      for (iColor=1;iColor < 2;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + TXT_DY_1+ iColor),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + TXT_DY_1 + iColor));
          SelectObject(hDC, hOldPen);
      }

        // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_SOILTEMPDZ1_TXT,lstrlen((LPSTR)GL_SOILTEMPDZ1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_SOILTEMPDZ2_TXT,lstrlen((LPSTR)GL_SOILTEMPDZ2_TXT));


      SelectObject(hDC,hOldFont);

     // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

//      if (!gbVersionSelect)  DrawAll(PLOTSOILMSG, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTSOILMSG, (LPHGRAPH) &s_hGraph, WinRect);

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
          case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               PrintObject((LPSTR)"PLOTSoilMsg");
               //--------------------------------------
               break;
           case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;


           case IDOK:
           case IDCANCEL:   DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);

                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotMsgProc                                      */

/************************************************************************/
/*                                                                      */
/* Plot Window Procedure      Potential logarithmisch !!!!!!!!!!!*/
/*                                                                      */
/* autor : C.Sperr                                                                         */
/* date  : 01.11.92                                                                        */
/*******************************************************************************************/

/************************************************************************/

extern INT_PTR CALLBACK PlotLogHydProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
HDC            hDC;
PAINTSTRUCT    ps;
HPEN           hOldPen;
HFONT          hOldFont;
static HGRAPH         s_hGraph;
RECT            WinRect;

   switch (Message)
   {
    case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:

       lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
       if (lpPPS !=NULL)
       {  
      lpPPS->iIDMenu = IDM_G_THPLOG;
          
          lpPPS->dXmin         =   0.0;
          lpPPS->dXmax         =  10.0;
          lpPPS->iXdiv         =   5;
          GrXdec[PLOTLOGHYD]   =   1;
          lpPPS->dYmin         =   0.0;
          lpPPS->dYmax         =   0.6;
          lpPPS->iYdiv         =   4;
          GrYdec[PLOTLOGHYD]   =   3;
       }
       else   MessageBox(NULL,"AddPPSMember failed",NULL,MB_ICONSTOP);

       s_hGraph.bRedraw = TRUE;
       SetClassLong(hWndDlg,GCL_HICON,(long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_PFTHETA_SS_TXT);
    initPlotWndDim(hWndDlg);
      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */

      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
      GrXmin[PLOTLOGHYD] = lpPPS->dXmin;
      GrXmax[PLOTLOGHYD] = lpPPS->dXmax;
      GrXdiv[PLOTLOGHYD] = (double)lpPPS->iXdiv;
      GrXdec[PLOTLOGHYD] = 2;
      GrYmin[PLOTLOGHYD] = lpPPS->dYmin;
      GrYmax[PLOTLOGHYD] = lpPPS->dYmax;
      GrYdiv[PLOTLOGHYD] = (double)lpPPS->iYdiv;
      GrYdec[PLOTLOGHYD] =  3;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */

      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;

      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <6;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }


        // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)M_H_C_TXT,lstrlen((LPSTR)M_H_C_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)M_H_W_TXT,lstrlen((LPSTR)M_H_W_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)M_B_C_TXT,lstrlen((LPSTR)M_B_C_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)M_C_H_TXT,lstrlen((LPSTR)M_C_H_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_4,(LPSTR)M_M_H_TXT,lstrlen((LPSTR)M_M_H_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_5,(LPSTR)M_VG_TXT,lstrlen((LPSTR)M_VG_TXT));

      SelectObject(hDC,hOldFont);

     // open graph, and plot the grid
      s_hGraph.hDC  = hDC;


//      if (!gbVersionSelect)  DrawAll(PLOTLOGHYD, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTLOGHYD, (LPHGRAPH) &s_hGraph, WinRect);

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
          case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               PrintObject((LPSTR)"PLOTLH");
               //--------------------------------------
               break;
          case ID_X_SCALE:
                doXScaleDlg(hWndDlg);
               break;
          case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
          case IDOK:
          case IDCANCEL:   DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);
                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotLogHydProc                                 */
/************************************************************************/
/*                                                                      */
/* Plot Window Procedure      conductivity logarithmic  curve           */
/*                                                                      */
/* autor : C.Sperr                                                                         */
/* date  : 01.11.92                                                                        */
/*******************************************************************************************/

/************************************************************************/

extern INT_PTR CALLBACK PlotLogHydLeitProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{

HDC            hDC;
PAINTSTRUCT    ps;
HPEN           hOldPen;
HFONT          hOldFont;
static HGRAPH         s_hGraph;
RECT            WinRect;

   switch (Message)
   {
    case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
         lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
         if (lpPPS !=NULL)
         {
          lpPPS->iIDMenu = IDM_G_THPLOG;  // second dialog !
      
      lpPPS->dXmin         =   0.0;
          lpPPS->dXmax         =   0.6;
          lpPPS->iXdiv         =   4;
          GrXdec[PLOTLOGHYDLEIT]   =   1;
          lpPPS->dYmin         =   -100.0;
          lpPPS->dYmax         =   0.0;
          lpPPS->iYdiv         =   4;
          GrYdec[PLOTLOGHYDLEIT]   =   3;
         }
         else   MessageBox(NULL,"AddPPSMember failed",NULL,MB_ICONSTOP);

       s_hGraph.bRedraw = TRUE;
       SetClassLong(hWndDlg,GCL_HICON,(long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_THETAKREL_SS_TXT);
    initPlotWndDim(hWndDlg);
      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */

      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
      GrXmin[PLOTLOGHYDLEIT] = lpPPS->dXmin;
      GrXmax[PLOTLOGHYDLEIT] = lpPPS->dXmax;
      GrXdiv[PLOTLOGHYDLEIT] = (double)lpPPS->iXdiv;
      GrXdec[PLOTLOGHYDLEIT] = 2;
      GrYmin[PLOTLOGHYDLEIT] = lpPPS->dYmin;
      GrYmax[PLOTLOGHYDLEIT] = lpPPS->dYmax;
      GrYdiv[PLOTLOGHYDLEIT] = (double)lpPPS->iYdiv;
      GrYdec[PLOTLOGHYDLEIT] =  1;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */

      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
 // range where coordinate system is drawn
WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;

      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <6;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }


        // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)M_H_C_TXT,lstrlen((LPSTR)M_H_C_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)M_H_W_TXT,lstrlen((LPSTR)M_H_W_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)M_B_C_TXT,lstrlen((LPSTR)M_B_C_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)M_C_H_TXT,lstrlen((LPSTR)M_C_H_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_4,(LPSTR)M_M_H_TXT,lstrlen((LPSTR)M_M_H_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_5,(LPSTR)M_VG_TXT,lstrlen((LPSTR)M_VG_TXT));

      SelectObject(hDC,hOldFont);

     // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

//      if (!gbVersionSelect)  DrawAll(PLOTLOGHYDLEIT, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
     XDrawAll(PLOTLOGHYDLEIT, (LPHGRAPH) &s_hGraph, WinRect);


       EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
          case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               PrintObject((LPSTR)"PLOTLHL");
               //--------------------------------------
               break;
           case ID_X_SCALE:
                doXScaleDlg(hWndDlg);
               break;
           case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
           case IDOK:
           case IDCANCEL:   DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);
                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotLogHydProc                                 */

/************************************************************************/
/*                                                                      */
/* Plot Window Procedure: conductivity through potential                */
/*                        logarithmic curve                             */
/* autor : C.Sperr                                                                         */
/* date  : 01.11.92                                                                        */
/*******************************************************************************************/
/************************************************************************/

extern INT_PTR CALLBACK PlotHydLogLeitPotProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH         s_hGraph;
 RECT            WinRect;

   switch (Message)

   {
    case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
         if (lpPPS !=NULL)
         {
      lpPPS->iIDMenu = IDM_G_THPLOG; // third dialog :  one ID
    
      lpPPS->dXmin                =   0.0;
          lpPPS->dXmax                =  12.0;
          lpPPS->iXdiv                =   4;
          GrXdec[PLOTLOGHYDLEITPOT]   =   2;
          lpPPS->dYmin                =   -12.0;
          lpPPS->dYmax                =     1.0;
          lpPPS->iYdiv                =   4;
          GrYdec[PLOTLOGHYDLEITPOT]   =   1;
         }
         else   MessageBox(NULL,"AddPPSMember failed",NULL,MB_ICONSTOP);

       s_hGraph.bRedraw = TRUE;
       SetClassLong(hWndDlg,GCL_HICON,(long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_PFKREL_SS_TXT);
    initPlotWndDim(hWndDlg);
      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */
      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
      GrXmin[PLOTLOGHYDLEITPOT] = lpPPS->dXmin;
      GrXmax[PLOTLOGHYDLEITPOT] = lpPPS->dXmax;
      GrXdiv[PLOTLOGHYDLEITPOT] = (double)lpPPS->iXdiv;
      GrXdec[PLOTLOGHYDLEITPOT] = 2;
      GrYmin[PLOTLOGHYDLEITPOT] = lpPPS->dYmin;
      GrYmax[PLOTLOGHYDLEITPOT] = lpPPS->dYmax;
      GrYdiv[PLOTLOGHYDLEITPOT] = (double)lpPPS->iYdiv;
      GrYdec[PLOTLOGHYDLEITPOT] =  1;



      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */

      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
 // range where coordinate system is drawn
WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;

      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <6;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }


        // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)M_H_C_TXT,lstrlen((LPSTR)M_H_C_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)M_H_W_TXT,lstrlen((LPSTR)M_H_W_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)M_B_C_TXT,lstrlen((LPSTR)M_B_C_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)M_C_H_TXT,lstrlen((LPSTR)M_C_H_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_4,(LPSTR)M_M_H_TXT,lstrlen((LPSTR)M_M_H_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_5,(LPSTR)M_VG_TXT,lstrlen((LPSTR)M_VG_TXT));

      SelectObject(hDC,hOldFont);

     // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

//      if (!gbVersionSelect)  DrawAll(PLOTLOGHYDLEITPOT, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTLOGHYDLEITPOT, (LPHGRAPH) &s_hGraph, WinRect);

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
          case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               PrintObject((LPSTR)"PLOTLHLP");
               //--------------------------------------
               break;
           case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;
           case IDOK:
           case IDCANCEL:   DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);

                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of  log. curve                                 */

/************************************************************************/
/*                                                                      */
/* Plot Window Procedure: differential water capacity                   */
/*                                    */
/* autor : C.Sperr                                                                         */
/* date  : 01.11.92                                                                        */
/*******************************************************************************************/
/************************************************************************/

extern INT_PTR CALLBACK PlotDWCProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;

   switch (Message)

   {
    case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
         lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
         if (lpPPS !=NULL)
         {
          lpPPS->iIDMenu = IDM_G_DWC;
    
      lpPPS->dXmin                =   0.0;
          lpPPS->dXmax                =   0.0005;
          lpPPS->iXdiv                =   4;
          GrXdec[PLOTDWC]   =   4;
          lpPPS->dYmin                =   0.3;
          lpPPS->dYmax                =   0.6;
          lpPPS->iYdiv                =   3;
          GrYdec[PLOTDWC]   =   1;
         }
         else   MessageBox(NULL,"AddPPSMember failed",NULL,MB_ICONSTOP);

      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON,(long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_DWC_SS_TXT);
    initPlotWndDim(hWndDlg);
      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */

      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
      GrXmin[PLOTDWC] = lpPPS->dXmin;
      GrXmax[PLOTDWC] = lpPPS->dXmax;
      GrXdiv[PLOTDWC] = (double)lpPPS->iXdiv;
      GrXdec[PLOTDWC] = 4;
      GrYmin[PLOTDWC] = lpPPS->dYmin;
      GrYmax[PLOTDWC] = lpPPS->dYmax;
      GrYdiv[PLOTDWC] = (double)lpPPS->iYdiv;
      GrYdec[PLOTDWC] =  1;

      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */

      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn
WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;

      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <6;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }


        // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)M_H_C_TXT,lstrlen((LPSTR)M_H_C_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)M_H_W_TXT,lstrlen((LPSTR)M_H_W_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)M_B_C_TXT,lstrlen((LPSTR)M_B_C_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)M_C_H_TXT,lstrlen((LPSTR)M_C_H_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_4,(LPSTR)M_M_H_TXT,lstrlen((LPSTR)M_M_H_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_5,(LPSTR)M_VG_TXT,lstrlen((LPSTR)M_VG_TXT));

      SelectObject(hDC,hOldFont);

     // open graph, and plot the grid
      s_hGraph.hDC  = hDC;


//      if (!gbVersionSelect)  DrawAll(PLOTDWC,(LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTDWC,(LPHGRAPH) &s_hGraph, WinRect);


      EndPaint(hWndDlg, &ps);

      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
         case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               PrintObject((LPSTR)"PLOTDWC");
               //--------------------------------------
               break;

         case ID_X_SCALE:
              doXScaleDlg(hWndDlg);
             break;

         case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
           case IDOK:
           case IDCANCEL:   DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);

                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of  DWC -  curve                                 */


/*************************************************************************/
/*                                                                       */
/* Plot Window Procedure      Potential �ber Wassergehalt skalare Darstellung. */
/*                                                                        */
/* autor : C.Sperr                                                                         */
/* date  : 01.11.92                                                                        */
/*******************************************************************************************/
/************************************************************************/

extern INT_PTR CALLBACK PlotMsgProc33( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH         s_hGraph;
 RECT            WinRect;

   switch (Message)
   {
    case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
         lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
         if (lpPPS !=NULL)
         {
          lpPPS->iIDMenu = IDM_G_THP;
      
      lpPPS->dXmin                =  -200000.0;
          lpPPS->dXmax                =        0.0;
          lpPPS->iXdiv                =        4;
          GrXdec[PLOT33]   =   0;
          lpPPS->dYmin                =        0.0;
          lpPPS->dYmax                =        0.60;
          lpPPS->iYdiv                =        4;
          GrYdec[PLOT33]   =   2;
         }
         else   MessageBox(NULL,"AddPPSMember failed",NULL,MB_ICONSTOP);


       s_hGraph.bRedraw = TRUE;
       SetClassLong(hWndDlg,GCL_HICON,(long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_POTENTIAL_SS_TXT);
    initPlotWndDim(hWndDlg);
      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */

      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
      GrXmin[PLOT33] = lpPPS->dXmin;
      GrXmax[PLOT33] = lpPPS->dXmax;
      GrXdiv[PLOT33] = (double)lpPPS->iXdiv;
      GrXdec[PLOT33] = 0;
      GrYmin[PLOT33] = lpPPS->dYmin;
      GrYmax[PLOT33] = lpPPS->dYmax;
      GrYdiv[PLOT33] = (double)lpPPS->iYdiv;
      GrYdec[PLOT33] =  2;

      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */

      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn
WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;

      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <6;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }


        // Set text style
      hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)M_H_C_TXT,lstrlen((LPSTR)M_H_C_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)M_H_W_TXT,lstrlen((LPSTR)M_H_W_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)M_B_C_TXT,lstrlen((LPSTR)M_B_C_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)M_C_H_TXT,lstrlen((LPSTR)M_C_H_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_4,(LPSTR)M_M_H_TXT,lstrlen((LPSTR)M_M_H_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_5,(LPSTR)M_VG_TXT,lstrlen((LPSTR)M_VG_TXT));

      SelectObject(hDC,hOldFont);

     // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

//      if (!gbVersionSelect)  DrawAll(PLOT33, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
     XDrawAll(PLOT33, (LPHGRAPH) &s_hGraph, WinRect);




      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
          case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               PrintObject((LPSTR)"PLOT33");
               //--------------------------------------
               break;

           case ID_X_SCALE:
                doXScaleDlg(hWndDlg);
               break;

           case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
           case IDOK:
           case IDCANCEL:   DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);

                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotMsgProc33                                      */

/************************************************************************/
/*                                                                      */
/* Plot Window Procedure: Leitf�higkeit �ber Wassergehalt und Schicht   */
/*                        skalare Darstellung           */
/* autor : C.Sperr                                                                         */
/* date  : 01.11.92                                                                        */
/*******************************************************************************************/
/************************************************************************/

extern INT_PTR CALLBACK PlotMsgProc44( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH         s_hGraph;
 RECT            WinRect;

   switch (Message)
   {
    case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
         lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
         if (lpPPS !=NULL)
         {
       lpPPS->iIDMenu = IDM_G_THP;  // second dialog one ID : unused 
    
      lpPPS->dXmin                =  0.0;
          lpPPS->dXmax                =  0.05;
          lpPPS->iXdiv                =  4;
          GrXdec[PLOT44]   =   3;
          lpPPS->dYmin                =  0.0;
          lpPPS->dYmax                =  0.6;
          lpPPS->iYdiv                =    4;
          GrYdec[PLOT44]   =   2;
         }
         else   MessageBox(NULL,"AddPPSMember failed",NULL,MB_ICONSTOP);

       s_hGraph.bRedraw = TRUE;
       SetClassLong(hWndDlg,GCL_HICON,(long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_CONDUCTIVITY_SS_TXT);
    initPlotWndDim(hWndDlg);
      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */

      lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
      GrXmin[PLOT44] = lpPPS->dXmin;
      GrXmax[PLOT44] = lpPPS->dXmax;
      GrXdiv[PLOT44] = (double)lpPPS->iXdiv;
      GrXdec[PLOT44] = 3;
      GrYmin[PLOT44] = lpPPS->dYmin;
      GrYmax[PLOT44] = lpPPS->dYmax;
      GrYdiv[PLOT44] = (double)lpPPS->iYdiv;
      GrYdec[PLOT44] = 2;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */

      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
          GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
 // range where coordinate system is drawn
WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;

      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);
    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <6;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }


        // Set text style
      hOldFont=   SelectObject(hDC,lpahExpFonts[0]);

      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)M_H_C_TXT,lstrlen((LPSTR)M_H_C_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)M_H_W_TXT,lstrlen((LPSTR)M_H_W_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)M_B_C_TXT,lstrlen((LPSTR)M_B_C_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)M_C_H_TXT,lstrlen((LPSTR)M_C_H_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_4,(LPSTR)M_M_H_TXT,lstrlen((LPSTR)M_M_H_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_5,(LPSTR)M_VG_TXT,lstrlen((LPSTR)M_VG_TXT));

      SelectObject(hDC,hOldFont);

     // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

//      if (!gbVersionSelect)  DrawAll(PLOT44, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOT44, (LPHGRAPH) &s_hGraph, WinRect);

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
          case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               PrintObject((LPSTR)"PLOT44");
               //--------------------------------------
               break;
           case ID_X_SCALE:
                doXScaleDlg(hWndDlg);
               break;

           case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
           case IDOK:
           case IDCANCEL:   DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);

                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotMsgProc44                                      */


/********************************************************************************************/
/*                                                                                          */
/* Plot Time Protocoll   Window Procedure                                                   */
/* time dependent graphic: H2OET - Array  afH2OET[]                       */
/* autor : C.Sperr                                                                         */
/* date  : 22.05.97                                                                        */
/*******************************************************************************************/

extern INT_PTR CALLBACK PlotH2OETProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;

 switch (Message)
 {
   case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
     /*
      * adjust coordinate system
      */
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_H2OET;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
    lpPPS->dXmax = PlotDT1Xmax;
    lpPPS->iXdiv = (int)PlotDT1XDiv;
    lpPPS->iXdec = PlotDT1XDec;
        lpPPS->dYmin = 0;
        lpPPS->dYmax = 500;
        lpPPS->iYdiv = 5;
        lpPPS->iYdec = 0;
      }
      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON, (long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_H2OET_SS_TXT);
    initPlotWndDim(hWndDlg);

      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */


     lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
     GrXmin[PLOTH2OET] =lpPPS->dXmin; // ] = PlotDT1Xmin
     GrXmax[PLOTH2OET] =lpPPS->dXmax; // ] = PlotDT1XMax
     GrXdiv[PLOTH2OET] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
     GrXdec[PLOTH2OET] = lpPPS->iXdec ;  //] = lpPPS->iXdec ;  //] = PlotDT1XDec;
     GrYmin[PLOTH2OET] =  lpPPS->dYmin;
     GrYmax[PLOTH2OET] =  lpPPS->dYmax;
     GrYdiv[PLOTH2OET] =  (double)lpPPS->iYdiv;
     GrYdec[PLOTH2OET] = lpPPS->iYdec ;  //]PlotDT1YDec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;
    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <6;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }

        // Set text style
        hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      /**************************************
       * Legend text
       */
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_H2OET1_TXT,lstrlen((LPSTR)GL_H2OET1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_H2OET2_TXT,lstrlen((LPSTR)GL_H2OET2_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)GL_H2OET3_TXT,lstrlen((LPSTR)GL_H2OET3_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)GL_H2OET4_TXT,lstrlen((LPSTR)GL_H2OET4_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_4,(LPSTR)GL_H2OET5_TXT,lstrlen((LPSTR)GL_H2OET5_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_5,(LPSTR)GL_H2OET6_TXT,lstrlen((LPSTR)GL_H2OET6_TXT));

      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTH2OET, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTH2OET, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PLOTH2OET");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;


           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);
                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotH2OETProc ===============================  */   


/********************************************************************************************/
/*                                                                                          */
/* Plot Time Protocoll   Window Procedure                                                   */
/* time dependent graphic: H2O_Bal - Array  afH2OBal[]                       */
/* autor : C.Sperr                                                                         */
/* date  : 22.05.97                                                                        */
/*******************************************************************************************/

extern INT_PTR CALLBACK PlotH2OBalProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;

 switch (Message)
 {
   case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
     /* REGISTER plotmember 
      * adjust coordinate system
      */
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu     = IDM_G_H2OBAL;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
    lpPPS->dXmax = PlotDT1Xmax;
    lpPPS->iXdiv = (int)PlotDT1XDiv;
    lpPPS->iXdec = PlotDT1XDec;
        lpPPS->dYmin = -100;
        lpPPS->dYmax = 400;
        lpPPS->iYdiv = 5;
        lpPPS->iYdec = 0;
      }

      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON, (long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_H2OBAL_SS_TXT);
    initPlotWndDim(hWndDlg);

      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */

     lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
     GrXmin[PLOTH2OBAL] = lpPPS->dXmin; // ] = PlotDT1Xmin
     GrXmax[PLOTH2OBAL] = lpPPS->dXmax; // ] = PlotDT1XMax
     GrXdiv[PLOTH2OBAL] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
     GrXdec[PLOTH2OBAL] = lpPPS->iXdec ;  //] = lpPPS->iXdec ;  //] = PlotDT1XDec;
     GrYmin[PLOTH2OBAL] = lpPPS->dYmin;
     GrYmax[PLOTH2OBAL] = lpPPS->dYmax;
     GrYdiv[PLOTH2OBAL] = (double)lpPPS->iYdiv;
     GrYdec[PLOTH2OBAL] = lpPPS->iYdec ;  //]PlotDT1YDec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;
    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <6;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }

        // Set text style
        hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      /**************************************
       * Legend text
       */
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_H2O_BAL1_TXT,lstrlen((LPSTR)GL_H2O_BAL1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_H2O_BAL2_TXT,lstrlen((LPSTR)GL_H2O_BAL2_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)GL_H2O_BAL3_TXT,lstrlen((LPSTR)GL_H2O_BAL3_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)GL_H2O_BAL4_TXT,lstrlen((LPSTR)GL_H2O_BAL4_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_4,(LPSTR)GL_H2O_BAL5_TXT,lstrlen((LPSTR)GL_H2O_BAL5_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_5,(LPSTR)GL_H2O_BAL6_TXT,lstrlen((LPSTR)GL_H2O_BAL6_TXT));
      
      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
    XDrawAll(PLOTH2OBAL, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PLOTH2OBAL");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;


           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);
        break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotH2OBALProc ===============================  */


/********************************************************************************************/
/*                                                                                          */
/* Plot Time Protocoll   Window Procedure                                                   */
/* time dependent graphic: H2O_Pot - Array  afH2OPot[]                       */
/* autor : C.Sperr                                                                         */
/* date  : 22.05.97                                                                        */
/*******************************************************************************************/

extern INT_PTR CALLBACK PlotH2OPotProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;

 switch (Message)
 {
   case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
     /*
      * adjust coordinate system
      */
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_H2OPOT;
    lpPPS->bXTimeScale = TRUE;

    lpPPS->dXmin = PlotDT1Xmin;
    lpPPS->dXmax = PlotDT1Xmax;
    lpPPS->iXdiv = (int)PlotDT1XDiv;
    lpPPS->iXdec = PlotDT1XDec;
        
    lpPPS->dYmin = -2000;
        lpPPS->dYmax = 0;
        lpPPS->iYdiv = 4;
        lpPPS->iYdec = 0;
      }

      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON, (long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    SetWindowText(hWndDlg,G_H2O_POT_SS_TXT);
    initPlotWndDim(hWndDlg);

      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */


     lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
     GrXmin[PLOTH2OPOT] =lpPPS->dXmin; // ] = PlotDT1Xmin
     GrXmax[PLOTH2OPOT] =lpPPS->dXmax; // ] = PlotDT1XMax
     GrXdiv[PLOTH2OPOT] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
     GrXdec[PLOTH2OPOT] = lpPPS->iXdec ;  //] = lpPPS->iXdec ;  //] = PlotDT1XDec;
     GrYmin[PLOTH2OPOT] =  lpPPS->dYmin;
     GrYmax[PLOTH2OPOT] =  lpPPS->dYmax;
     GrYdiv[PLOTH2OPOT] =  (double)lpPPS->iYdiv;
     GrYdec[PLOTH2OPOT] = lpPPS->iYdec ;  //]PlotDT1YDec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;
    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <4;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }

        // Set text style
        hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      /**************************************
       * Legend text
       */
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_H2O_POT1_TXT,lstrlen((LPSTR)GL_H2O_POT1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_H2O_POT2_TXT,lstrlen((LPSTR)GL_H2O_POT2_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)GL_H2O_POT3_TXT,lstrlen((LPSTR)GL_H2O_POT3_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)GL_H2O_POT4_TXT,lstrlen((LPSTR)GL_H2O_POT4_TXT));
      
      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTH2OPOT, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTH2OPOT, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PLOTH2OPOT");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;


           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);

                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotH2OPOTProc ===============================  */


/********************************************************************************************/
/*                                                                                          */
/* Plot Time Protocoll   Window Procedure                                                   */
/* time dependent graphic: H2O_Flux - Array  afH2OFlux[]                       */
/* autor : C.Sperr                                                                         */
/* date  : 22.05.97                                                                        */
/*******************************************************************************************/

extern INT_PTR CALLBACK PlotH2OFluxProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;

 switch (Message)
 {
   case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
     /*
      * adjust coordinate system
      */
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_H2OFLUX;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
    lpPPS->dXmax = PlotDT1Xmax;
    lpPPS->iXdiv = (int)PlotDT1XDiv;
    lpPPS->iXdec = PlotDT1XDec;
        lpPPS->dYmin = -10;
        lpPPS->dYmax = 40;
        lpPPS->iYdiv = 5;
        lpPPS->iYdec = 0;
      }
      SetWindowText(hWndDlg,G_H2O_FLUX_SS_TXT);
      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON, (long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    initPlotWndDim(hWndDlg);
    break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */


     lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
     GrXmin[PLOTH2OFLUX] =  lpPPS->dXmin; // ] = PlotDT1Xmin
     GrXmax[PLOTH2OFLUX] =  lpPPS->dXmax; // ] = PlotDT1XMax
     GrXdiv[PLOTH2OFLUX] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
     GrXdec[PLOTH2OFLUX] = lpPPS->iXdec ;  //] = lpPPS->iXdec ;  //] = PlotDT1XDec;
     GrYmin[PLOTH2OFLUX] =  lpPPS->dYmin;
     GrYmax[PLOTH2OFLUX] =  lpPPS->dYmax;
     GrYdiv[PLOTH2OFLUX] =  (double)lpPPS->iYdiv;
     GrYdec[PLOTH2OFLUX] = lpPPS->iYdec ;  //PlotDT1YDec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
 // reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;
    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <4;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }

        // Set text style
        hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      /**************************************
       * Legend text
       */
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_H2O_FLUX1_TXT,lstrlen((LPSTR)GL_H2O_FLUX1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_H2O_FLUX2_TXT,lstrlen((LPSTR)GL_H2O_FLUX2_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)GL_H2O_FLUX3_TXT,lstrlen((LPSTR)GL_H2O_FLUX3_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)GL_H2O_FLUX4_TXT,lstrlen((LPSTR)GL_H2O_FLUX4_TXT));
      
      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTH2OFLUX, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTH2OFLUX, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PLOTH2OFLUX");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;


           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }

                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);

                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotH2OFLUXProc ===============================  */

/********************************************************************************************/
/*                                                                                          */
/* Plot Time Protocoll   Window Procedure                                                   */
/* time dependent graphic: H2O_Cond - Array  afH2OCond[]                       */
/* autor : C.Sperr                                                                         */
/* date  : 22.05.97                                                                        */
/*******************************************************************************************/

extern INT_PTR CALLBACK PlotH2OCondProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;

 switch (Message)
 {
   case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
     /*
      * adjust coordinate system
      */
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_H2OCOND;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
    lpPPS->dXmax = PlotDT1Xmax;
    lpPPS->iXdiv = (int)PlotDT1XDiv;
    lpPPS->iXdec = PlotDT1XDec;
        lpPPS->dYmin = 0;
        lpPPS->dYmax = 400;
        lpPPS->iYdiv = 4;
        lpPPS->iYdec = 0;
      }

      SetWindowText(hWndDlg,G_H2O_COND_SS_TXT);
    s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON, (long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    initPlotWndDim(hWndDlg);

      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */


     lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
     GrXmin[PLOTH2OCOND] =lpPPS->dXmin; // ] = PlotDT1Xmin
     GrXmax[PLOTH2OCOND] =lpPPS->dXmax; // ] = PlotDT1XMax
     GrXdiv[PLOTH2OCOND] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
     GrXdec[PLOTH2OCOND] = lpPPS->iXdec ;  //] = lpPPS->iXdec ;  //] = PlotDT1XDec;
     GrYmin[PLOTH2OCOND] =  lpPPS->dYmin;
     GrYmax[PLOTH2OCOND] =  lpPPS->dYmax;
     GrYdiv[PLOTH2OCOND] =  (double)lpPPS->iYdiv;
     GrYdec[PLOTH2OCOND] = lpPPS->iYdec ;  //PlotDT1YDec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;
    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <4;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }

        // Set text style
        hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      /**************************************
       * Legend text
       */
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_H2O_COND1_TXT,lstrlen((LPSTR)GL_H2O_COND1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_H2O_COND2_TXT,lstrlen((LPSTR)GL_H2O_COND2_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)GL_H2O_COND3_TXT,lstrlen((LPSTR)GL_H2O_COND3_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)GL_H2O_COND4_TXT,lstrlen((LPSTR)GL_H2O_COND4_TXT));
      
      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTH2OCOND, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTH2OCOND, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PLOTH2OCOND");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;


           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);

                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotH2OCONDProc ===============================  */


/********************************************************************************************/
/*                                                                                          */
/* Plot Time Protocoll   Window Procedure                                                   */
/* time dependent graphic: NITROBAL - Array  afNBal[]                       */
/* autor : C.Sperr                                                                         */
/* date  : 22.05.97                                                                        */
/*******************************************************************************************/

extern INT_PTR CALLBACK PlotNitroBalProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;

 switch (Message)
 {
   case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
     /*
      * adjust coordinate system
      */
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_NITROBAL;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
    lpPPS->dXmax = PlotDT1Xmax;
    lpPPS->iXdiv = (int)PlotDT1XDiv;
    lpPPS->iXdec = PlotDT1XDec;
        lpPPS->dYmin = -100;
        lpPPS->dYmax = 300;
        lpPPS->iYdiv = 4;
        lpPPS->iYdec = 0;
      }
      SetWindowText(hWndDlg,G_NITRO_BAL_SS_TXT);
      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON, (long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    initPlotWndDim(hWndDlg);

      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */


     lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
     GrXmin[PLOTNITROBAL] =lpPPS->dXmin; // ] = PlotDT1Xmin
     GrXmax[PLOTNITROBAL] =lpPPS->dXmax; // ] = PlotDT1XMax
     GrXdiv[PLOTNITROBAL] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
     GrXdec[PLOTNITROBAL] = lpPPS->iXdec ;  //] = lpPPS->iXdec ;  //] = PlotDT1XDec;
     GrYmin[PLOTNITROBAL] =  lpPPS->dYmin;
     GrYmax[PLOTNITROBAL] =  lpPPS->dYmax;
     GrYdiv[PLOTNITROBAL] =  (double)lpPPS->iYdiv;
     GrYdec[PLOTNITROBAL] = lpPPS->iYdec ;  //PlotDT1YDec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;
    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <6;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }

        // Set text style
        hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      /**************************************
       * Legend text
       */
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_NITRO_BAL1_TXT,lstrlen((LPSTR)GL_NITRO_BAL1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_NITRO_BAL2_TXT,lstrlen((LPSTR)GL_NITRO_BAL2_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)GL_NITRO_BAL3_TXT,lstrlen((LPSTR)GL_NITRO_BAL3_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)GL_NITRO_BAL4_TXT,lstrlen((LPSTR)GL_NITRO_BAL4_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_4,(LPSTR)GL_NITRO_BAL5_TXT,lstrlen((LPSTR)GL_NITRO_BAL5_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_5,(LPSTR)GL_NITRO_BAL6_TXT,lstrlen((LPSTR)GL_NITRO_BAL6_TXT));
      
      
      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTNITROBAL, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTNITROBAL, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PLOTNITROBAL");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;


           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);
                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotNITROBALProc ===============================  */


/********************************************************************************************/
/*                                                                                          */
/* Plot Time Protocoll   Window Procedure                                                   */
/* time dependent graphic: NITROGas - Array  afNGas[]                       */
/* autor : C.Sperr                                                                         */
/* date  : 22.05.97                                                                        */
/*******************************************************************************************/

extern INT_PTR CALLBACK PlotNitroGasProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;

 switch (Message)
 {
   case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
     /*
      * adjust coordinate system
      */
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_NITROGAS;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
    lpPPS->dXmax = PlotDT1Xmax;
    lpPPS->iXdiv = (int)PlotDT1XDiv;
    lpPPS->iXdec = PlotDT1XDec;
        lpPPS->dYmin = -10.0;
        lpPPS->dYmax = 100.0;
        lpPPS->iYdiv = 11;
        lpPPS->iYdec = 1;
      }
      SetWindowText(hWndDlg,G_NITROGAS_SS_TXT);
      
      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON, (long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    initPlotWndDim(hWndDlg);

      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */


     lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
     GrXmin[PLOTNITROGAS] =lpPPS->dXmin; // ] = PlotDT1Xmin
     GrXmax[PLOTNITROGAS] =lpPPS->dXmax; // ] = PlotDT1XMax
     GrXdiv[PLOTNITROGAS] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
     GrXdec[PLOTNITROGAS] = lpPPS->iXdec ;  //] = PlotDT1XDec;
     GrYmin[PLOTNITROGAS] =  lpPPS->dYmin;
     GrYmax[PLOTNITROGAS] =  lpPPS->dYmax;
     GrYdiv[PLOTNITROGAS] =  (double)lpPPS->iYdiv;
     GrYdec[PLOTNITROGAS] = lpPPS->iYdec ;  //PlotDT1YDec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;
    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <5;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }

        // Set text style
        hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      /**************************************
       * Legend text
       */
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_NITRO_GAS1_TXT,lstrlen((LPSTR)GL_NITRO_GAS1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_NITRO_GAS2_TXT,lstrlen((LPSTR)GL_NITRO_GAS2_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)GL_NITRO_GAS3_TXT,lstrlen((LPSTR)GL_NITRO_GAS3_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)GL_NITRO_GAS4_TXT,lstrlen((LPSTR)GL_NITRO_GAS4_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_4,(LPSTR)GL_NITRO_GAS5_TXT,lstrlen((LPSTR)GL_NITRO_GAS5_TXT));
      
            
      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTNITROGAS, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTNITROGAS, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PLOTNITROGAS");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;


           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);

                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotNITROGASProc ===============================  */

/********************************************************************************************/
/*                                                                                          */
/* Plot Time Protocoll   Window Procedure                                                   */
/* time dependent graphic: NITROCumGas - Array  afNCumGas[]                       */
/* autor : C.Sperr                                                                         */
/* date  : 22.05.97                                                                        */
/*******************************************************************************************/

extern INT_PTR CALLBACK PlotNitroCumGasProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;

 switch (Message)
 {
   case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
     /*
      * adjust coordinate system
      */
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_NITROCUMGAS;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
    lpPPS->dXmax = PlotDT1Xmax;
    lpPPS->iXdiv = (int)PlotDT1XDiv;
    lpPPS->iXdec = PlotDT1XDec;
        lpPPS->dYmin = -1;
        lpPPS->dYmax = 10;
        lpPPS->iYdiv = 11;
        lpPPS->iYdec = 1;
      }
      SetWindowText(hWndDlg,G_NITROCUMGAS_SS_TXT);
      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON, (long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    initPlotWndDim(hWndDlg);

      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */


     lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
     GrXmin[PLOTNITROCUMGAS] =lpPPS->dXmin; // ] = PlotDT1Xmin
     GrXmax[PLOTNITROCUMGAS] =lpPPS->dXmax; // ] = PlotDT1XMax
     GrXdiv[PLOTNITROCUMGAS] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
     GrXdec[PLOTNITROCUMGAS] = lpPPS->iXdec ;  //] = PlotDT1XDec;
     GrYmin[PLOTNITROCUMGAS] =  lpPPS->dYmin;
     GrYmax[PLOTNITROCUMGAS] =  lpPPS->dYmax;
     GrYdiv[PLOTNITROCUMGAS] =  (double)lpPPS->iYdiv;
     GrYdec[PLOTNITROCUMGAS] = lpPPS->iYdec ;  //PlotDT1YDec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;
    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <5;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }

        // Set text style
        hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      /**************************************
       * Legend text
       */
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_NITRO_CUMGAS1_TXT,lstrlen((LPSTR)GL_NITRO_CUMGAS1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_NITRO_CUMGAS2_TXT,lstrlen((LPSTR)GL_NITRO_CUMGAS2_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)GL_NITRO_CUMGAS3_TXT,lstrlen((LPSTR)GL_NITRO_CUMGAS3_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)GL_NITRO_CUMGAS4_TXT,lstrlen((LPSTR)GL_NITRO_CUMGAS4_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_4,(LPSTR)GL_NITRO_CUMGAS5_TXT,lstrlen((LPSTR)GL_NITRO_CUMGAS5_TXT));
      
            
      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTNITROCUMGAS, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTNITROCUMGAS, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PLOTNITROCUMGAS");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;


           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);

                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotNITROCUMGASProc ===============================  */

/********************************************************************************************/
/*                                                                                          */
/* Plot Time Protocoll   Window Procedure                                                   */
/* time dependent graphic: NPools - Array  afNPools[]                       */
/* autor : C.Sperr                                                                         */
/* date  : 22.05.97                                                                        */
/*******************************************************************************************/

extern INT_PTR CALLBACK PlotNPoolsProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;

 switch (Message)
 {
   case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
     /*
      * adjust coordinate system
      */
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_NITROPOOLS;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
    lpPPS->dXmax = PlotDT1Xmax;
    lpPPS->iXdiv = (int)PlotDT1XDiv;
    lpPPS->iXdec = PlotDT1XDec;
        lpPPS->dYmin = 0;
        lpPPS->dYmax = 3000;
        lpPPS->iYdiv = 6;
        lpPPS->iYdec = 0;
      }
      SetWindowText(hWndDlg,G_NITROPOOLS_SS_TXT);
      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON, (long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    initPlotWndDim(hWndDlg);

      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */


     lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
     GrXmin[PLOTNITROPOOLS] =lpPPS->dXmin; // ] = PlotDT1Xmin
     GrXmax[PLOTNITROPOOLS] =lpPPS->dXmax; // ] = PlotDT1XMax
     GrXdiv[PLOTNITROPOOLS] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
     GrXdec[PLOTNITROPOOLS] = lpPPS->iXdec ;  //] = PlotDT1XDec;
     GrYmin[PLOTNITROPOOLS] =  lpPPS->dYmin;
     GrYmax[PLOTNITROPOOLS] =  lpPPS->dYmax;
     GrYdiv[PLOTNITROPOOLS] =  (double)lpPPS->iYdiv;
     GrYdec[PLOTNITROPOOLS] = lpPPS->iYdec ;  //PlotDT1YDec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;
    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <6;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }

        // Set text style
        hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      /**************************************
       * Legend text
       */
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_NITRO_POOLS1_TXT,lstrlen((LPSTR)GL_NITRO_POOLS1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_NITRO_POOLS2_TXT,lstrlen((LPSTR)GL_NITRO_POOLS2_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)GL_NITRO_POOLS3_TXT,lstrlen((LPSTR)GL_NITRO_POOLS3_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)GL_NITRO_POOLS4_TXT,lstrlen((LPSTR)GL_NITRO_POOLS4_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_4,(LPSTR)GL_NITRO_POOLS5_TXT,lstrlen((LPSTR)GL_NITRO_POOLS5_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_5,(LPSTR)GL_NITRO_POOLS6_TXT,lstrlen((LPSTR)GL_NITRO_POOLS6_TXT));
            
      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTNITROPOOLS, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTNITROPOOLS, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PLOTNITROPOOLS");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;


           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);

                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotNPoolsProc ===============================  */


/********************************************************************************************/
/*                                                                                          */
/* Plot Time Protocoll   Window Procedure                                                   */
/* time dependent graphic: NCN - Array  */
/* autor : C.Sperr                                                                         */
/* date  : 22.05.97                                                                        */
/*******************************************************************************************/

extern INT_PTR CALLBACK PlotNCNProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;

 switch (Message)
 {
   case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
     /*
      * adjust coordinate system
      */
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_NITROCN;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
    lpPPS->dXmax = PlotDT1Xmax;
    lpPPS->iXdiv = (int)PlotDT1XDiv;
    lpPPS->iXdec = PlotDT1XDec;
        lpPPS->dYmin = 0;
        lpPPS->dYmax = 100;
        lpPPS->iYdiv = 5;
        lpPPS->iYdec = 1;
      }
      SetWindowText(hWndDlg,G_NITROCN_SS_TXT);
      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON, (long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    initPlotWndDim(hWndDlg);

      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */


     lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
     GrXmin[PLOTNITROCN] =lpPPS->dXmin; // ] = PlotDT1Xmin
     GrXmax[PLOTNITROCN] =lpPPS->dXmax; // ] = PlotDT1XMax
     GrXdiv[PLOTNITROCN] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
     GrXdec[PLOTNITROCN] = lpPPS->iXdec ;  //] = PlotDT1XDec;
     GrYmin[PLOTNITROCN] =  lpPPS->dYmin;
     GrYmax[PLOTNITROCN] =  lpPPS->dYmax;
     GrYdiv[PLOTNITROCN] =  (double)lpPPS->iYdiv;
     GrYdec[PLOTNITROCN] = lpPPS->iYdec ;  //PlotDT1YDec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;
    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <3;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }

        // Set text style
        hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      /**************************************
       * Legend text
       */
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_NITRO_CN1_TXT,lstrlen((LPSTR)GL_NITRO_CN1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_NITRO_CN2_TXT,lstrlen((LPSTR)GL_NITRO_CN2_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)GL_NITRO_CN3_TXT,lstrlen((LPSTR)GL_NITRO_CN3_TXT));
      
                  
      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTNITROCN, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTNITROCN, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PLOTNITROCN");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;


           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }

                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);


                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotNPoolsProc ===============================  */


/********************************************************************************************/
/*                                                                                          */
/* Plot Time Protocoll   Window Procedure                                                   */
/* time dependent graphic: NMiner - Array  */
/* autor : C.Sperr                                                                         */
/* date  : 22.05.97                                                                        */
/*******************************************************************************************/

extern INT_PTR CALLBACK PlotNMinerProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;

 switch (Message)
 {
   case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
     /*
      * adjust coordinate system
      */
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_NITROMINER;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
    lpPPS->dXmax = PlotDT1Xmax;
    lpPPS->iXdiv = (int)PlotDT1XDiv;
    lpPPS->iXdec = PlotDT1XDec;
        lpPPS->dYmin = 0;
        lpPPS->dYmax = 1;
        lpPPS->iYdiv = 5;
        lpPPS->iYdec = 2;
      }
      SetWindowText(hWndDlg,G_NITROMINER_SS_TXT);
      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON, (long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    initPlotWndDim(hWndDlg);

      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */


     lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
     GrXmin[PLOTNITROMINER] =lpPPS->dXmin; // ] = PlotDT1Xmin
     GrXmax[PLOTNITROMINER] =lpPPS->dXmax; // ] = PlotDT1XMax
     GrXdiv[PLOTNITROMINER] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
     GrXdec[PLOTNITROMINER] = lpPPS->iXdec ;  //] = PlotDT1XDec;
     GrYmin[PLOTNITROMINER] =  lpPPS->dYmin;
     GrYmax[PLOTNITROMINER] =  lpPPS->dYmax;
     GrYdiv[PLOTNITROMINER] =  (double)lpPPS->iYdiv;
     GrYdec[PLOTNITROMINER] = lpPPS->iYdec ;  //PlotDT1YDec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;
    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <6;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }

        // Set text style
        hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      /**************************************
       * Legend text
       */
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_NITRO_MINER1_TXT,lstrlen((LPSTR)GL_NITRO_MINER1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_NITRO_MINER2_TXT,lstrlen((LPSTR)GL_NITRO_MINER2_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)GL_NITRO_MINER3_TXT,lstrlen((LPSTR)GL_NITRO_MINER3_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)GL_NITRO_MINER4_TXT,lstrlen((LPSTR)GL_NITRO_MINER4_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_4,(LPSTR)GL_NITRO_MINER5_TXT,lstrlen((LPSTR)GL_NITRO_MINER5_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_5,(LPSTR)GL_NITRO_MINER6_TXT,lstrlen((LPSTR)GL_NITRO_MINER6_TXT));
      
                  
      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTNITROMINER, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTNITROMINER, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PLOTNITROMINER");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;


           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);
                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotNMinerProc ===============================  */


/********************************************************************************************/
/*                                                                                          */
/* Plot Time Protocoll   Window Procedure                                                   */
/* time dependent graphic: TempIce - Array  */
/* autor : C.Sperr                                                                         */
/* date  : 22.05.97                                                                        */
/*******************************************************************************************/

extern INT_PTR CALLBACK PlotTempIceProc( HWND hWndDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
 HDC            hDC;
 PAINTSTRUCT    ps;
 HPEN           hOldPen;
 HFONT          hOldFont;
 static HGRAPH  s_hGraph;
 RECT            WinRect;

 switch (Message)
 {
   case WM_ERASEBKGND:
       s_hGraph.bRedraw = TRUE;
       return FALSE;


   case WM_INITDIALOG:
     /*
      * adjust coordinate system
      */
      lpPPS = AddPPSMember(getRootPPS(),hWndDlg);
      if (lpPPS !=NULL)
      {
        lpPPS->iIDMenu = IDM_G_TEMPICE;
    lpPPS->bXTimeScale = TRUE;

        lpPPS->dXmin = PlotDT1Xmin;
        lpPPS->dXmax = PlotDT1Xmax;
        lpPPS->iXdiv = (int)PlotDT1XDiv;
        lpPPS->iXdec= (int) PlotDT1XDec;

        lpPPS->dYmin = 0;
        lpPPS->dYmax = 1;
        lpPPS->iYdiv = 5;
        lpPPS->iYdec = 2;
      }
      SetWindowText(hWndDlg,G_TEMP_ICE_SS_TXT);
      s_hGraph.bRedraw = TRUE;
      SetClassLong(hWndDlg,GCL_HICON, (long) HydrIcon((HINSTANCE)GetWindowLong(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),GWL_HINSTANCE)));
    initPlotWndDim(hWndDlg);

      break;      /*  End of WM_CREATE */

   case WM_PAINT: /* code for the window's client area */


     lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
     GrXmin[PLOTTEMP_ICE] =lpPPS->dXmin; // ] = PlotDT1Xmin
     GrXmax[PLOTTEMP_ICE] =lpPPS->dXmax; // ] = PlotDT1XMax
     GrXdiv[PLOTTEMP_ICE] = (double)lpPPS->iXdiv; //] = PlotDT1XDiv;
     GrXdec[PLOTTEMP_ICE] = lpPPS->iXdec ;  //] = PlotDT1XDec;
     GrYmin[PLOTTEMP_ICE] =  lpPPS->dYmin;
     GrYmax[PLOTTEMP_ICE] =  lpPPS->dYmax;
     GrYdiv[PLOTTEMP_ICE] =  (double)lpPPS->iYdiv;
     GrYdec[PLOTTEMP_ICE] = lpPPS->iYdec ;  //PlotDT1YDec;


      /* Obtain a handle to the device context                       */
      /* BeginPaint will sends WM_ERASEBKGND if appropriate          */
      memset(&ps, 0x00, sizeof(PAINTSTRUCT));
      hDC = BeginPaint(hWndDlg, &ps);
      /* Included in case the background is not a pure color  */
      SetBkMode(hDC, TRANSPARENT);

      GetClientRect(hWndDlg,(LPRECT)&WinRect);
      SelectObject(hDC, GetStockObject(BLACK_PEN));
      MoveToEx(hDC,WinRect.left+10,WinRect.top+10,lpPoint);
      LineTo(hDC,WinRect.right-10,WinRect.top+10);
      LineTo(hDC,WinRect.right-10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.bottom-130);
      LineTo(hDC,WinRect.left+10,WinRect.top+10);
// reposition legend and buttons    
    resetLegendAndButtons(hWndDlg,2); 
  
 // range where coordinate system is drawn

      WinRect.left   +=  60;
      WinRect.top    +=  40;
      WinRect.right  -=  40;
      WinRect.bottom -= 180;
    /****************************************
     * paint color lines for legend
     */

      for (iColor=0;iColor <4;iColor++)
      {
          hOldPen = SelectObject(hDC,lpahGrafPens[iColor]);
          MoveToEx(hDC, LEGEND_X0,(LEGEND_Y0 + iColor*15),lpPoint);
          LineTo(hDC,LEGEND_LINE_DX,(LEGEND_Y0 + iColor*15));
          SelectObject(hDC, hOldPen);
      }

        // Set text style
        hOldFont=SelectObject(hDC,lpahExpFonts[0]);

      /**************************************
       * Legend text
       */
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0,(LPSTR)GL_TEMP_ICE1_TXT,lstrlen((LPSTR)GL_TEMP_ICE1_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_1,(LPSTR)GL_TEMP_ICE2_TXT,lstrlen((LPSTR)GL_TEMP_ICE2_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_2,(LPSTR)GL_TEMP_ICE3_TXT,lstrlen((LPSTR)GL_TEMP_ICE3_TXT));
      TextOut(hDC,LEGEND_TEXT_X0,LEGEND_TEXT_Y0 + TXT_DY_3,(LPSTR)GL_TEMP_ICE4_TXT,lstrlen((LPSTR)GL_TEMP_ICE4_TXT));
            
                  
      SelectObject(hDC,hOldFont);

      // open graph, and plot the grid
      s_hGraph.hDC  = hDC;

      bDateString=TRUE;
//      if (!gbVersionSelect)  DrawAll(PLOTTEMP_ICE, (LPHGRAPH) &s_hGraph, WinRect);
//      else               
    XDrawAll(PLOTTEMP_ICE, (LPHGRAPH) &s_hGraph, WinRect);
      bDateString=FALSE;

      EndPaint(hWndDlg, &ps);
      break;       /*  End of WM_PAINT  */

    case WM_SIZE:     /*  code for moving the window */
          InvalidateRect(hWndDlg, NULL,TRUE);
          break;
    

    case WM_CLOSE:
    /*
     * force execution of IDCANCEL - Codesection  below!
     */
       PostMessage(hWndDlg, WM_COMMAND, IDCANCEL, 0L);
       break;

    case WM_HSCROLL:
            break;

   case WM_COMMAND:
         switch(wParam)
         {
            case ID_PRINT:
               //-------<Printer Output PRINT.C>-------
               bPrnDateString=TRUE;
               PrintObject((LPSTR)"PLOTTEMP_ICE");
               bPrnDateString=FALSE;
               //--------------------------------------
               break;
            case ID_Y_SCALE:
                 doYScaleDlg(hWndDlg);
               break;
            case ID_X_SCALE:
                 doXScaleDlg(hWndDlg);
               break;


           case IDOK:
           case IDCANCEL:
                DestroyHydrIcon();
                lpPPS = SearchPPSMember(getRootPPS(),hWndDlg);
            if (lpPPS != NULL) {
            SendMessage(FindWindow(g_szEXPERTN_APPCLASSNAME,g_szExpertNWndTitle),WM_USER,(WORD)lpPPS->iIDMenu,USER_PLOT_LPARAM);
                }
                DestroyWindow(hWndDlg);
                eraseDlgPPS(hWndDlg);
                break;
         }
         break;    /* End of WM_COMMAND                                 */

    default:
        return FALSE;
   }
   return TRUE;
} /* End of PlotTempIceProc ===============================  */

/*******************************************************************************
** EOF */
